#include <bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int32_t n, q; cin >> n >> q;
    vector<int64_t> v(n);
    vector<int64_t> p(n);
    vector<int64_t> ans(n);
    for (int32_t i = 0; i < n; i++) {
        cin >> v[i];
    }
    for (int32_t i = 0; i < q; i++) {
        int64_t l, x; cin >> l >> x;
        p[0] += x;
        if (l < n) p[l] -= x;
    }
    int64_t acc = 0;
    for (int32_t i = 0; i < n; i++) {
        acc += p[i];
        v[i] += acc;
    }
    multiset<int64_t> mst; mst.insert(v.front());
    for (int32_t i = 1; i < n; i++) {
        ans[i] = mst.size();
        while (*mst.begin() <= v[i] && mst.begin() != mst.end()) {
            mst.erase(mst.begin());
        }
        mst.insert(v[i]);
    }
    for (int32_t i = 1; i < n; i++) {
        cout << ans[i] << '\n';
    }
    return 0;
}