#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n;
    vector<int> path = {1};
    int ans;

    int i = 2, level = 0;
    while(level<n){
        cout<<"? "<<i<<endl;
        cin>>ans;
        if(!ans){
            path.push_back(i+1);
            i = i+1+(level+++2);
        }
        else{
            path.clear();
            path.push_back(i);
            i = i+level+++2;
        }
    }
    if(ans==1) {
        cout << "! " << i-1-level << '\n';
        return 0;
    }
    auto check = [&](int qry){
        cout<<"? "<<qry<<endl;
        int ans;
        cin>>ans;
        return ans;
    };

    int l = 1, r = path.size();
    int mid = i-level-1;
    while(l<r){
        mid = (l+r)>>1;
        ans = check(path[mid]);
        if(ans){
            l = mid+1;
        }
        else{
            r = mid;
        }
    }
    if(ans) {
        cout << "! " << path[mid] << '\n';
    } else {
        cout << "! " << path[mid-1] << '\n';
    }

}