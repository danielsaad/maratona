#include <bits/stdc++.h>
using namespace std;

string whilepy(const string& str) {
    string ret = "ENQUANTO ";
    string cond = str.substr(6);
    cond.pop_back();
    ret += cond;
    return ret;
}

string ifpy(const string& str) {
    string ret = "SE ";
    string cond = str.substr(3);
    cond.pop_back();
    ret += cond;
    ret += " ENTAO";
    return ret;
}

string printpy(const string& str) {
    string ret = "APRESENTE ";
    string print = str.substr(6);
    print.pop_back();
    ret += print;
    return ret;
}

string inputpy(const string& str) {
    string ret = "LEIA ";
    string input = str.substr(0,str.find_first_of(' '));
    ret += input;
    return ret;
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    string str;
    string ans;
    getline(cin,str);
    
    bool ok = false;
    
    if(str.substr(0,5)=="while") {
        ans += whilepy(str) + ' ';
        ok = true;
    } else if(str.substr(0,2)=="if") {
        ans += ifpy(str) + ' ';
        ok = true;
    } else if(str.substr(0,5)=="print") {
        ans += printpy(str);
    } else {
        ans += inputpy(str);
    }
    if(ok) {
        int32_t tab;
        getline(cin,str);
        stringstream a{str};
        str = "";
        string ttr;
        while(a >> ttr) {
            str += ttr + ' ';
        }
        str.pop_back();
        if(str.substr(0,5)=="print") {
            ans += printpy(str);
        } else {
            ans += inputpy(str);
        }
    }
    cout << ans;
}