#include <bits/stdc++.h>
using namespace std;

string whilepy(const string& str) {
    string ret = "ENQUANTO ";
    string cond = str.substr(6);
    cond.pop_back();
    ret += cond;
    return ret;
}

string ifpy(const string& str) {
    string ret = "SE ";
    string cond = str.substr(3);
    cond.pop_back();
    ret += cond;
    ret += " ENTAO";
    return ret;
}

string printpy(const string& str) {
    string ret = "APRESENTE ";
    string print = str.substr(6);
    print.pop_back();
    ret += print;
    return ret;
}

string inputpy(const string& str) {
    string ret = "LEIA ";
    string input = str.substr(0,str.find_first_of(' '));
    ret += input;
    return ret;
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    string str;
    string ans;
    while(getline(cin,str) and !cin.eof()) {
        int32_t tab;
        for(tab = 0; tab<str.size(); tab++) {
            if(str.at(tab)!=' ') break;
        }
        str = str.substr(tab);
        if(str.substr(0,5)=="while") {
            ans += whilepy(str);
        } else if(str.substr(0,2)=="if") {
            ans += ifpy(str);
        } else if(str.substr(0,5)=="print") {
            ans += printpy(str);
        } else {
            ans += inputpy(str);
        }
        ans += ' ';
    }
    ans.pop_back();
    cout << ans << '\n';
}