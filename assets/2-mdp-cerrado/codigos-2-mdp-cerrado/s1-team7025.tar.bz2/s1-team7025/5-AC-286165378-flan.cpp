#include <bits/stdc++.h>
using namespace std;

vector<int32_t> sieve(int32_t n) {
    n++;
    vector<int32_t> ret;
    vector<bool> ok(n,true);
    for(int64_t i=2; i<n; i++) {
        if(!ok.at(i)) continue;
        ret.push_back(i);
        for(int64_t j=i*i; j<n; j+=i) {
            ok.at(j) = false;
        }
    }
    return ret;
}

int main() {
    auto p = sieve(sqrt(1e7+10));
    int32_t n;
    cin >> n;
    vector<int32_t> v(n);
    unordered_map<int64_t,int64_t> fact(n); // factorisation of all nums;
    for(int32_t i=0;i<n;i++) {
        cin >> v.at(i);
        for(int32_t j=0; j<p.size(); j++) {
            while(v.at(i)%p.at(j)==0) {
                fact[p.at(j)]++;
                v.at(i) /= p.at(j);
            }
        }
        if(v.at(i)>1) fact[v.at(i)]++;
    }
    vector<int64_t> ans;
    for(auto[k,v] : fact) {
        ans.push_back(k*v);
    }
    sort(ans.rbegin(),ans.rend());
    int64_t s = 0;
    for(int32_t i=0; i<ans.size(); i++) {
        if(i%2==0) s += ans.at(i);
    }
    cout << s << '\n';

}