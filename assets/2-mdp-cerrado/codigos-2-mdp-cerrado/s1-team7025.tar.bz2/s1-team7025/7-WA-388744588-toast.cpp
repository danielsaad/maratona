#include <bits/stdc++.h>
using namespace std;

string func_while(string s) {
    s = s.substr(6, s.size() - 6);
    return s.substr(0, s.size() - 1);
}

string func_print(string s) {
    s = s.substr(6, s.size() - 7);
    return s;
}

string func_if(string s) {
    s = s.substr(3, s.size() - 3);
    return s.substr(0, s.size() - 1);
}

int main() {
    string s;
    getline(cin, s);
    stringstream ss(s);
    string start; ss >> start;
    string ans1;
    bool ok = false;
    if (start == "if") {
        ans1 = func_if(s);
        cout << "SE " << ans1 << " ENTAO";
        ok = true;
    } else if (start == "while") {
        ans1 = func_while(s);
        cout << "ENQUANTO " << ans1;
        ok = true;
    } else if (start.substr(0, 5) == "print") {
        ans1 = func_print(s);
        cout << "APRESENTE " << ans1;
    } else {
        cout << "LEIA " << start;
    }
    getline(cin, s);
    if (s.size()) {
        cout<<' ';
        ss = stringstream(s);
        ss >> start;
        if (start.substr(0, 5) == "print") {
            ans1 = func_print(s);
            cout << "APRESENTE " << ans1;
        } else {
            cout << "LEIA " << start;
        }
    }
    cout << '\n';
    return 0;
}