#include <bits/stdc++.h>
using namespace std;

int main() {
    int32_t h,m;
    scanf("%d:%d",&h,&m);
    int32_t hf,mf;
    scanf("%d:%d",&hf,&mf);
    m -= mf;
    h -= hf;
    if(m<0) {
        m += 60;
        h--;
    }
    printf("%02d:%02d\n",h,m);
}