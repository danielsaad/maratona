#include <bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(0)->sync_with_stdio(0);

    int n, m; cin>>n>>m;
    string s; cin>>s;

    while(m--){
        string t; cin>>t;
        int32_t i=0;
        if(s[0]==t[0]) {
            for(i=1;i<min(s.size(),t.size());i++) {
                if(s[i]!=s[i-1] or t[i]!=t[i-1] or s[i]!=t[i]) break;
            }
        }
        cout << n+t.size()-i << '\n';
    }
}