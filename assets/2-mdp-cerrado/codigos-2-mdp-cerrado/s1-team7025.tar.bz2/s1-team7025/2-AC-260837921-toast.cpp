#include <bits/stdc++.h>
using namespace std;

int main() {
    int32_t a;
    cin >> a;
    if(a<45) cout << "Costa\n";
    else if(a>45) cout << "Saad\n";
    else cout << "Ambos\n";
}