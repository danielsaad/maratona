#include <bits/stdc++.h>
using namespace std;

int main() {
    int32_t n;
    cin >> n;
    string str;
    cin >> str;
    int32_t pos = 1;
    int32_t ans = 0;
    map<char,int> mp = {{'E',0},{'C',1},{'D',2}};
    for(int32_t i=0; i<n; i++) {
        if(abs(mp[str.at(i)]-pos)<=1) ans++, pos = mp[str.at(i)];
        else {
            pos = 1; 
        }
    }
    cout << ans << '\n';
}