#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string f,i;
    int a,b,c,d;
    a= b = c =d = 0;
    int foi = 0;

    cin >> f >> i;

    for(int j = 0; j < 5;j++){
        if(i[j] == ':'){
            foi = 1;
            continue;
        }
        if(foi){
            d = d*10 + ('0'- f[j]); 
        }else{
            c = c*10 + ('0'- f[j]); 
        }
    }

    foi= 0;

    for(int j = 0; j < 5;j++){
        if(i[j] == ':'){
            foi = 1;
            continue;
        }
        if(foi){
            b = b*10 + ('0'- i[j]); 
        }else{
            a = a*10 + ('0'- i[j]); 
        }
    }

    int min =(a*60+b);
    int minf = (c*60+d);
    int resp = abs(minf - min);
    int resph = (resp/60);
    int respm = max(0,(resp - 60*resph));

    if(resph < 10) cout << "0";

    cout << resph << ":";

    if(respm < 10) cout << "0";

    cout << respm;


    return 0;
}