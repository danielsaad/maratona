#include<bits/stdc++.h>
using namespace std;

typedef long long ll;  
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll pre,cons,aux,atual,antigo,maior =0;

    cin>>pre>>cons;

    vector<ll>v(pre);
    vector<ll>c(pre,0);
    pair<ll,ll> aa = {0,1};

    for(int i=0;i<pre;i++)
    {
        cin>>v[i];
    }

    for(int i=0;i<cons;i++)
    {   
        cin >>aux;
        cin>>c[aux-1];
    }

    for(int i=0;i<pre;i++)
    {   
        atual = v[i] + c[i]; 
        v[i] = atual;
        if(i == 0){
            continue;
        }
        antigo = v[i-1] + c[i];
        if(atual  >= antigo){
            maior = 1;
        }else{
            maior = 0;
        }
        if(aa.second){
            aa = {1,maior};
        }else{
            aa = {aa.first+1,maior};
        }

        cout << aa.first <<"\n";
    }




    return 0;
}