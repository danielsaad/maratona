#include<bits/stdc++.h>
#include<math.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    double n;
    cin>>n;
    if(cos(n)>sin(n))
    {
        cout<<"Costa"<<"\n";
    }
    else if(cos(n)<sin(n))
    {
        cout<<"Saad"<<"\n";
    }
    else
    {
        cout<<"Ambos"<<"\n";
    }
    return 0;
}