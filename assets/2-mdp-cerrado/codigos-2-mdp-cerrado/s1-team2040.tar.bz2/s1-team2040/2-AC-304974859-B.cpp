#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin>>n;
    if(n<45)
    {
        cout<<"Costa"<<"\n";
    }
    else if(n>45)
    {
        cout<<"Saad"<<"\n";
    }
    else
    {
        cout<<"Ambos"<<"\n";
    }
    return 0;
}