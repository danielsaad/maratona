#include<bits/stdc++.h>
using namespace std;

char posicao(char atual, char prox){
    if(atual == 'E' && prox == 'C'){
        return 'C';
    }
    if(atual == 'E' && prox == 'D'){
        return 'C';
    }
    if(atual == 'E' && prox == 'E'){
        return 'E';
    }
    if(atual == 'D' && prox == 'C'){
        return 'C';
    }
    if(atual == 'D' && prox == 'D'){
        return 'D';
    }
    if(atual == 'D' && prox == 'E'){
        return 'C';
    }
    if(atual == 'C' && prox == 'C'){
        return 'C';
    }
    if(atual == 'C' && prox == 'E'){
        return 'E';
    }
    if(atual == 'C' && prox == 'D'){
        return 'D';
    }
    return 'C';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string a;
    int q;

    int resp =0;
    int aux = 1;
    char atual = 'C';
    
    cin >> q;
    cin >> a;

    atual = posicao(atual,a[0]);
    for(int i = 0; i <= a.size();i++){
        if(atual == a[i]){
            resp++;
        }
        atual = posicao(atual,a[i+1]);

    }

    cout << resp;

    return 0;
}