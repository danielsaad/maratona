#include <bits/stdc++.h>
#include <math.h>
#define pb push_back
#define int long long

using namespace std;



int32_t main(){

    ios_base :: sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    string s;
    getline(cin, s);

    string pri = "print(";
    int p = 1;
    for(int i = 0; i < 6; i++){

        if(s[i] != pri[i]){
            p = 0;
            break;
        }
    }

    int a = s.size();
    if(s[a-1] == ')' && s[a-2] == '('){
        cout << "LEIA ";
        for(int i = 0; i < s.size(); i++){
            if(s[i] == ' '){
                break;
            }
            cout << s[i];
        }
        cout << endl;
    }
    else if(p){
        cout << "APRESENTE ";
        for(int i = 6; i < a-1; i++){
            cout << s[i];
        }
        cout << endl;
    }
    else if(s[0] == 'i' && s[1] == 'f'){
        string b;
        getline(cin, b);
        cout << "SE ";
        int aux = 0;
        for(int i = 3; i < s.size(); i++){
            if(s[i] == ' '){
                aux = i;
                break;
            }
            cout << s[i];
        }
        cout << " ";
        for(int i = aux+1; i <= aux+2; i++){
            
            cout << s[i];
        }

        aux += 3;
        for(int i = aux; i < s.size()-1; i++){
            cout << s[i];
        }
        cout << " ENTAO ";
        int c = b.size();
        c+= 4;
        if(b[b.size()-1] == ')' && b[b.size()-2] == '('){
            cout << "LEIA ";
            for(int i = 4; i < b.size(); i++){
                if(b[i] == ' '){
                    break;
                }
            cout << b[i];
        }
        cout << endl;
        }
        else if(b[4] == 'p'){
            cout << "APRESENTE ";
            for(int i = 10; i < b.size()-1; i++){
                cout << b[i];
            }
            cout << endl;
        }

    }
    else{
        string b;
        getline(cin, b);
        cout << "ENQUANTO ";
        int aux = 0;
        for(int i = 6; i < s.size(); i++){
            if(s[i] == ' '){
                aux = i;
                break;
            }
            cout << s[i];
        }
        cout << " ";
        for(int i = aux+1; i <= aux+2; i++){
            if(s[i] == ' '){
                break;
            }
            cout << s[i];
        }
        cout << " ";
        aux += 4;
        for(int i = aux;  i< s.size()-1; i++){
            cout << s[i];
        }
        cout<< " ";

        
        int c = b.size();
        c+= 4;
        if(b[b.size()-1] == ')' && b[b.size()-2] == '('){
            cout << "LEIA ";
            for(int i = 4; i < b.size(); i++){
                if(b[i] == ' '){
                    break;
                }
            cout << b[i];
        }
        cout << endl;
    }
        else if(b[4] == 'p'){
            cout << "APRESENTE ";
            for(int i = 10; i < b.size()-1; i++){
                cout << b[i];
            }
            cout << endl;
        }


    }


}