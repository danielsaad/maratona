#include <bits/stdc++.h>
#include <math.h>

using namespace std;

int main(){

    int n, pos = 0; cin >> n;
    char ant;

    int cont = n, pode = 1;

    for(int i = 0; i < n; i++){

        char c; cin >> c;

        if(!i)ant = c;
        else{

            if(c == 'E' && ant == 'D' && pode){
                pode = 0;
                cont--;
            }
            else if(ant == 'E' && c == 'D' && pode){
                
                pode = 0;
                cont--;
            }
            else {
                
                pode = 1;
                ant = c;
            }
        }
    }

    cout << cont << endl;

}