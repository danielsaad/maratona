#include <bits/stdc++.h>
#include <math.h>

using namespace std;

int main(){

    float n1; 
    cin >> n1;

    n1 = n1*M_PI /180;

    //cout << sin(n1) << cos(n1) << endl;
    if(sin(n1) > cos(n1)){
        cout << "Saad" << endl;
    }
    else if(sin(n1) < cos(n1)){
        cout << "Costa" << endl;
    }
    else{
        cout <<"Ambos" << endl;
    }
}