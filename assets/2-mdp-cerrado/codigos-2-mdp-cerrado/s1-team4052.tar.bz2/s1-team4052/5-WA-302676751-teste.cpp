#include <bits/stdc++.h>
#include <math.h>
#define pb push_back
#define int long long

using namespace std;

int n, z, u;
map<int, int>c, resp;
vector<int>primo, ord;

void crivo(int a){

    c[1] = 1;

    for(int i = 2; i <= a; i++){

        //cout << i << "!" << endl;

        if(!c[i]){

            primo.pb(i);

            for(int j = 2; j*i <= a; j++){

                c[i*j] = 1;
            }
        }
    }

    return;
}

int32_t main(){

    crivo(4000);
    cin >> n;

    for(int i = 0; i < n; i++){

        int num; cin >> num;

        for(int j = 0; j < primo.size(); j++){

            int p = primo[j];
            int origem = num;

            while(origem % p == 0){

                resp[p]++;
                origem /= p;
            }
        }
    }

    for(auto x : resp){

        ord.pb(x.first*x.second);
    }

    sort(ord.begin(), ord.end());

    for(int i = 0; i < ord.size(); i++){

        if(i % 2)u += ord[i];
        else z += ord[i];
    }

    cout << max(z, u) << endl;

    return 0;

}