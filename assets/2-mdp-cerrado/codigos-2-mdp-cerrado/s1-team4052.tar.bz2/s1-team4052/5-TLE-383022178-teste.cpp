#include <bits/stdc++.h>
#include <math.h>
#define pb push_back
#define int long long

using namespace std;

int n, z, u;
int c[10000005];
map<int, int>resp;
vector<int>primo, ord;

void crivo(int a){

    c[1] = 1;

    for(int i = 2; i <= a; i++){

        //cout << i << "!" << endl;

        if(!c[i]){

            primo.pb(i);

            //cout << primo.size() << " i = " << i << endl;

            for(int j = 2; j*i <= a; j++){

                c[i*j] = 1;
            }
        }
    }

    return;
}

int32_t main(){

    ios_base :: sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    crivo(10000001);
    cin >> n;

    for(int i = 0; i < n; i++){

        int num; cin >> num;

        if(!c[num]){
            
            resp[num]++;
            continue;
        }

        for(int j = 0; j < primo.size(); j++){

            int p = primo[j];

            int origem = num;

            while(origem % p == 0){

                resp[p]++;
                origem /= p;

                //cout << "or = " << origem << " p = " << p << endl;
            }
        }
    }

    for(auto x : resp){

        ord.pb(x.first*x.second);
    }

    sort(ord.begin(), ord.end());

    for(int i = 0; i < ord.size(); i++){

        if(i % 2)u += ord[i];
        else z += ord[i];
    }

    cout << max(z, u) << endl;

    return 0;

}