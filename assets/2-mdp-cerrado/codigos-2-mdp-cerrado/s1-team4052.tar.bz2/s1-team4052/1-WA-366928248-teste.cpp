#include <bits/stdc++.h>
#include <math.h>
#define pb push_back
#define int long long

using namespace std;



int32_t main(){

    ios_base :: sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    int n, c;
    cin>>n>>c;
    vector<int>p(n+2), add(n+2);
    map<int,int>m;
    for(int i=1; i<=n; i++){
        cin>>p[i];
        add[i] = 0;
    }
    p[n+1] = 0;
    for(int i=0, a, b; i<c; i++){
        
        cin>>a>>b;
        add[1] += b;
        add[a+1] -= b;
        //cout << "add " << b << " no 1 = " << p[1] << endl;
        //cout << "dimin " << b << " no a+1 = " << p[a+1] << endl;
    }

    p[1] += add[1];
    //cout << p[1] << " ";
    for(int i=2; i<=n; i++){
        add[i] += add[i-1];

        p[i] += add[i];

        //cout << p[i] << " ";
    }

    //cout << endl;
    int cont=1;
    for(int i=2; i<n+1; i++){
        cout<<cont<<endl;
        if(p[i]<p[i-1]) cont++;
        else cont=1;
    }


}