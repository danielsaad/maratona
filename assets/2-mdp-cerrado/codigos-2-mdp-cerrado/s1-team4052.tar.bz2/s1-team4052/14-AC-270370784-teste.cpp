#include <bits/stdc++.h>
#include <math.h>

using namespace std;

int main(){

    int fh, fm, ah, am;
    string f, a;
    cin>>f>>a;
    fh = stoi(f.substr(0,2));
    fm = stoi(f.substr(3,2));
    ah = stoi(a.substr(0,2));
    am = stoi(a.substr(3,2));
    int fmin = fh*60+fm;
    int amin = ah*60+am;
    int resp = fmin-amin;
    if(resp/60<10) cout<<"0";
    cout<<resp/60<<":";
    if(resp%60<10) cout<<"0";
    cout<<resp%60<<endl;


}