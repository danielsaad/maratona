#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    string s;
    cin >> s;
    int x{};

    if (n == 1){
        cout << 1 << endl; 
        return 0;
    }
    for (int i = 0; i < n - 1; i++)
    {
        if (s[i] != s[i + 1]){
            x++;
        }
    }

    cout << x << endl;
    

    return 0;
}