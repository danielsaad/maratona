#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    string s;
    cin >> s;
    int cont = n;

    for (int i = 0; i < n - 1; i++)
    {
        if (s[i] == 'E' && s[i + 1] == 'D') {
            cont--;
        } else if (s[i] == 'D' && s[i + 1] == 'E') {
        cont--;
        }
    }

    cout << cont << endl;
    

    return 0;
}