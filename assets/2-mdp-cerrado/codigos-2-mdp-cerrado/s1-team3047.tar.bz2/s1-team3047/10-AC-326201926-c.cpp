#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    int pos = 0, cont = n;
    
    string j;
    cin >> j;

    for (int i = 0; i < n; i++){
        if(pos==0){         
            if(j[i]=='E'){
                pos--;
            }
            else if(j[i]=='D'){
                pos++;
            }
        }
        if (pos==-1){
            if(j[i]=='C'){
                pos++;
            }
            else if(j[i]=='D'){
                pos++;
                cont--;
            }
        }
        if (pos==1){
            if(j[i]=='C'){
                pos--;
            }
            else if(j[i]=='E'){
                pos--;
                cont--;
            }
        }
    }

    cout << cont << endl;

    return 0;
}