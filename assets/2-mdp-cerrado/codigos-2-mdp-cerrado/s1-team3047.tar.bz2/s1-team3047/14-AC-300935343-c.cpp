#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string c;
    cin >> c;
    int h1 = (c[0] - 48) * 10 + (c[1] - 48);
    int m1 = (c[3] - 48) * 10 + (c[4] - 48);

    string d;
    cin >> d;
    int h2 = (d[0] - 48) * 10 + (d[1] - 48);
    int m2 = (d[3] - 48) * 10 + (d[4] - 48);

    int mt;
    if (m2 > m1){
        mt = 60 - (m2 - m1);
        h1--;
    }
    else{
        mt = m1 - m2;
    }
    int ht = h1 - h2;
        

    if (ht < 10) cout << "0" << ht << ":";
    else cout << ht << ":";

    if (mt < 10) cout << "0" << mt << endl;
    else cout << mt << endl;

    return 0;
}