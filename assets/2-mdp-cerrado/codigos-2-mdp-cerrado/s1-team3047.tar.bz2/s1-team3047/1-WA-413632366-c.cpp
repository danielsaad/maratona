#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int qp, qalt;
    cin >> qp >> qalt;

    vector<int>pre;

    int n = qp;
    while(qp--){
        int x;
        cin >> x;
        pre.push_back(x);
    }
    while(qalt--){
        int m, f;
        cin >> m >> f;
        for (int i=0; i<m; i++){
            pre[i]+=f;
        }
    }
    reverse(pre.begin(),pre.end());

    vector<int> ans;
    for (int i = 1; i < n - 1; i++)
    {
        if (n % 2 == 0){
            if (i == n/2) {
                reverse(pre.begin(), pre.end());
            }
        } else {
            if (i == n/2 + 1) {
                reverse(pre.begin(), pre.end());
            }
        }
        int cont = 0;
        int ant = 0;
        for (int j = i + 1 ; j < n; j++)
        {
            if (pre[j] > ant){
                cont++;
                ant = pre[j];
            }       
        }
        ans.push_back(cont);
    }

    reverse(ans.begin(),ans.end());
    for (int x : ans){
        cout << x << '\n';
    }

    reverse(pre.begin(),pre.end());
    
    int cont = 0;
    int ant = 0;
    for (int j = 1; j < n; j++){
        if (pre[j] > ant){
            cont++;
            ant = pre[j];
        }  
    }
    cout << cont << endl;

    return 0;
}