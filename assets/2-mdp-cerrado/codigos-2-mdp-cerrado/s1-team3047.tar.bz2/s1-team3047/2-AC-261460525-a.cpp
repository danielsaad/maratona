#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int a;
    cin >> a;
    //0 cos; 30 cos; 45 ambos; 60 sen; 90 sen

    if (a<45){
        cout << "Costa" << endl;
    }
    else if (a>45){
        cout << "Saad" << endl;
    }
    else{
        cout << "Ambos" << endl;
    }
    
    return 0;
}