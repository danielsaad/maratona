#include <bits/stdc++.h>
#define speedBoost ios::sync_with_stdio(0); cin.tie(0);
#define int long long

using namespace std;


int32_t main(){

  speedBoost;  
  
  string line; cin >> line;
  string data;
  int hf, mf;
  stringstream ss(line);
  int ctt = 0;
  while(getline(ss, data, ':')){
    if(ctt == 0) hf = stoi(data, nullptr, 10);
    else         mf = stoi(data, nullptr, 10);
    ctt++;
  }

  int hi, mi; 
  cin >> line;
  stringstream ss2(line);
  ctt = 0;
  while(getline(ss2, data, ':')){
    if(ctt == 0) hi = stoi(data, nullptr, 10);
    else         mi = stoi(data, nullptr, 10);
    ctt++;  
  }

  int total_1 = hf * 60 + mf;
  int total_2 = hi * 60 + mi; 

  int total_acc = total_1 - total_2;
  int hours = total_acc / 60;
  if(hours < 10) cout << "0" << hours;
  else           cout << hours;
  
  cout << ":";
  int minutes = total_acc % 60;
  if(minutes < 10) cout << "0" << minutes << endl;
  else             cout << minutes << endl;
  return 0;

}