#include <bits/stdc++.h>
#define speedBoost ios::sync_with_stdio(0); cin.tie(0);
#define int long long;

typedef long long ll;


using namespace std;


int32_t main(){

  speedBoost;     



  ll n;
  cin >> n;
  string s;
  cin >> s;
  ll esq=-1,cent=0,dir=1;
  ll cont = 0;
  ll gol = cent;
  for (ll i=0;i<s.size();i++){
    ll aux;
      if (s[i]=='C') aux = 0;
      else if (s[i]=='E') aux = -1;
      else aux = 1;
      if (gol==aux||(gol-aux!=2&&gol-aux!=-2)){
        cont++;
      }
      gol = aux;
  }

  cout << cont << "\n";
  
  return 0;
}
