#include <bits/stdc++.h>
#define speedBoost ios::sync_with_stdio(0); cin.tie(0);
#define int long long

using namespace std;


int32_t main(){

  speedBoost; 
  double a; cin >> a;
  double costa, saad;

  saad = sin(a * M_PI / 180.0);
  costa = cos(a * M_PI / 180.0);

  if(saad > costa)
    cout << "Saad\n";
  else if(costa > saad)
    cout << "Costa\n"; 
  else
    cout << "Ambos\n";
  
  return 0;

}