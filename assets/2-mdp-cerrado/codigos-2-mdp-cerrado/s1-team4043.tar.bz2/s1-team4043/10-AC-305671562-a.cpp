#include <bits/stdc++.h>
#define speedBoost ios::sync_with_stdio(0); cin.tie(0);

using namespace std;


int32_t main(){

  speedBoost;     
  int n; cin >> n;

  int left = 1, center = 2, right = 3;
  int cur = center;
  string line; cin >> line;

  int ans = 0;
  for(auto c : line){

    if(c == 'C'){
      cur = center; 
      ans++;
    }
    else if(c == 'E'){
      if(cur == right){
        cur = center;
        continue;
      }
      else{
        cur = left; 
        ans++;
      }
    }
    else{
      if(cur == left){
        cur = center;
        continue;
      }
      else{
        cur = right;
        ans++;
      }
    }
  }

  cout << ans << endl;

  return 0;
}
