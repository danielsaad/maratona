#include <bits/stdc++.h>
#define speedBoost ios::sync_with_stdio(0); cin.tie(0);
#define int long long

const double EPS = 1e-9;

using namespace std;


int32_t main(){

  speedBoost; 
  double a; cin >> a;
  if(a == 45) cout << "Ambos" << endl;
  else if(a > 45) cout << "Saad" << endl;
  else if(a < 45) cout << "Costa" << endl;
  
  return 0;

}