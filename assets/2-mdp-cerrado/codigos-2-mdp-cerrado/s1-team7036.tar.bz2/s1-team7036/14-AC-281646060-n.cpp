#include <bits/stdc++.h>
using namespace std;
#define int long long

signed main(){
    int x,y;
    char a;
    cin >> x >> a >> y;
    int h,k;
    cin >> h >> a >> k;
    y += x * 60;
    k += h * 60;
    int total = abs(y-k);
    int inteiro = total/60, minutos = total %60;
    if (inteiro < 10){
        cout << 0;
    }
    cout << inteiro << a;
    if (minutos < 10){
        cout << 0;
    }
    cout << minutos << endl;
}
