#include<bits/stdc++.h>
using namespace std;
#define int long long

signed main()
{
    int n;
    cin >> n;
    string s;
    cin >> s;

    int gol=0, count=0;
    for(int i=0; i<n; i++)
    {
        if(s[i]=='C' && gol!=0) gol=0;
        else if(s[i]=='D' && gol!=1) gol+=1;
        else if(s[i]=='E' && gol!=-1) gol-=1;
        if(s[i]=='C' && gol==0) count++;
        else if(s[i]=='E' && gol==-1) count++;
        else if(s[i]=='D' && gol==1) count++;
    }
    cout << count << "\n";
}
