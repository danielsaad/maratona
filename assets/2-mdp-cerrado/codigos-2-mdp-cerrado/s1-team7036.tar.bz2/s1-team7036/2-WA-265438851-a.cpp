#include<bits/stdc++.h>
using namespace std;
#define int long long

signed main()
{
    int n;
    cin >> n;
    double x=n*3.14159/180;
    if(sin(x)<cos(x)) cout << "Costa\n";
    else if(sin(x)>cos(x)) cout << "Saad\n";
    else cout << "Ambos\n";
}
