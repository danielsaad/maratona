#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	vector<string> a;
	string tmp;
	while (getline(cin, tmp)) {
		a.emplace_back(tmp);
	}

	for (int i = 0; i < a.size(); i++) {
		string &now = a[i];
		int cur = 0;
		while (isspace(now[cur])) {
			cur++;
		}

		if (now.substr(cur, 2) == "if") {
			cout << "SE ";
			for (int j = cur + 2; now[j] != ':'; j++) {
				cout << now[j];
			}
			cout << " ENTAO ";
			continue;
		}

		if (now.substr(cur, 5) == "while") {
			cout << "ENQUANTO ";
			for (int j = cur + 5; now[j] != ':'; j++) {
				cout << now[j];
			}
			cout << ' ';
			continue;
		}

		if (now.substr(cur, 5) == "print") {
			cout << "APRESENTE ";
			for (int j = cur + 6; now[j] != ')'; j++) {
				cout << now[j];
			}
			cout << '\n';
			return 0;
		}

		cout << "LEIA ";
		for (int j = cur; !isspace(now[j]); j++) {
			cout << now[j];
		}
		cout << '\n';
		break;
	}
}
