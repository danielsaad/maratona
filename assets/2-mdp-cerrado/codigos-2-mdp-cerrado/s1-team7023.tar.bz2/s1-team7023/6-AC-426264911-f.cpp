#include <bits/stdc++.h>
using namespace std;

#define int long long

using matrix = array<array<int, 2>, 2>;

const int MOD = 998244353;

matrix I = {1, 0, 0, 1};
matrix Z = {0, 0, 0, 0};

matrix mult(matrix &a, matrix &b) {
	matrix ret = Z;
	for(int i = 0; i < 2; i++) {
		for(int j = 0; j < 2; j++) {
			for(int k = 0; k < 2; k++) {
				ret[i][j] += a[i][k] * b[k][j];
				ret[i][j] %= MOD;
			}
		}
	}
	return ret;
}

matrix fexpm(matrix base, int e) {
	matrix ret = I;
	while(e) {
		if(e & 1) ret = mult(ret, base);
		base = mult(base, base);
		e >>= 1;
	}
	return ret;
}

int fexp(int base, int e) {
	int ret = 1;
	while(e) {
		if(e & 1) ret = ret * base % MOD;
		base = base * base % MOD;
		e >>= 1;
	}
	return ret;
}

void print(matrix x) {
	for(int i = 0; i < 2; i++)
		for(int j = 0; j < 2; j++)
			cout << x[i][j] << " \n"[j == 1];
}

signed main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int tt;
	cin >> tt;
	while(tt--) {
		int A, B, n, m, a[2];
		cin >> A >> B >> n >> m >> a[0] >> a[1];

		matrix X = {0, 1, B, A};

		matrix f = fexpm(X, n);
		matrix s = fexpm(X, m);

		vector<int> c = {f[0][0], f[0][1], s[0][0], s[0][1]};

		int top = ((((c[0] * a[1]) % MOD) - ((c[2] * a[0]) % MOD) + MOD) % MOD);
		int bot = ((c[0] * c[3] % MOD) - (c[2] * c[1] % MOD) + MOD) % MOD;

		int y = top * fexp(bot, MOD - 2) % MOD;
		int x = ((a[0] - (c[1] * y % MOD) + MOD) % MOD) * fexp(c[0], MOD - 2) % MOD;

		cout << x << " " << y << "\n";

	}
	return 0;
}
