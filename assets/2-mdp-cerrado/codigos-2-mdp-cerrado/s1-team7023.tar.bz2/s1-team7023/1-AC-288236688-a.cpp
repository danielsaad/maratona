#include <bits/stdc++.h>

using namespace std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int n, q;
    cin >> n >> q;
    vector<int> a(n);
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    vector<int> b(n + 1);
    while(q--) {
        int i, j;
        cin >> i >> j;
        b[0] += j;
        b[i] -= j;
    }
    for(int i = 1; i < n; i++) {
        b[i] += b[i - 1];
    }
    for(int i = 0; i < n; i++) {
        a[i] += b[i];
    }
    multiset<int> s;
    vector<int> ans(n);
    for(int i = 0; i < n; i++) {
        ans[i] = (int) s.size();
        while(!s.empty() && *s.begin() <= a[i]) {
            s.erase(s.begin());
        }
        s.insert(a[i]);
    }
    for(int i = 1; i < n; i++) {
        cout << ans[i] << '\n';
    }
    return 0;
}