#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	ll h, m;
	scanf("%lld:%lld", &h, &m);
	ll ed = h * 60 + m;
	scanf("%lld:%lld", &h, &m);
	ll st = h * 60 + m;
	ll hor = ed - st;

	if (hor < 0) {
		hor += 24 * 60;
	}

	printf("%02lld:%02lld\n", hor / 60, hor % 60);
}
