#include <bits/stdc++.h>

using namespace std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    auto IO = [&](string s) -> string {
	    string ans;
			bool le = 0;

			string e = s;
	    if(s.size() > 6 and s.substr(0, 6) == "print(") {
				while(cin >> s) {
					e += " ";
					e += s;
					if(s.back() == ')') {
						break;
					}
				}
				if(e.back() != ')') le = 1;
	    }
	    else {
				le = 1;
	    }

			if(le) {
				ans += "LEIA ";
				ans += e;
			}
			else {
				ans += "APRESENTE ";
				ans += e.substr(6, (int)e.size() - 7);
			}

			return ans;
    };

		auto IF = [&]() -> string {
			string ans = "SE";
			string s;
			while(cin >> s) {
				ans += " ";
				ans += s;
				if(s.back() == ':') {
					ans.pop_back();
					break;
				}
			}
			ans += " ENTAO ";
			cin >> s;
			ans += IO(s);
			return ans;
		};

		auto WH = [&]() -> string {
			string ans = "ENQUANTO";
			string s;
			while(cin >> s) {
				ans += " ";
				ans += s;
				if(s.back() == ':') {
					ans.pop_back();
					break;
				}
			}
			ans += " ";
			cin >> s;
			ans += IO(s);
			return ans;
		};

    string s;

		cin >> s;

		string ans;

    if(s == "if") {
	    ans += IF();
    }
    else if(s == "while") {
	    ans += WH();
    }
    else {
	    ans += IO(s);
    }

		cout << ans << "\n";

    return 0;
}
