#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n;
	cin >> n;
	string a;
	cin >> a;

	ll OO = INT64_MAX >> 1;

	vector<vector<ll>> dp(n, vector<ll>(3));
	dp[0][0] = a[0] == 'D';
	dp[0][1] = a[0] == 'C';
	dp[0][2] = a[0] == 'E';

	for (int i = 1; i < n; i++) {
		dp[i][0] = max(dp[i - 1][1], dp[i - 1][0]) + (a[i] == 'D');
		dp[i][1] = max({dp[i - 1][1], dp[i - 1][0], dp[i - 1][2]}) + (a[i] == 'C');
		dp[i][2] = max(dp[i - 1][1], dp[i - 1][2]) + (a[i] == 'E');
	}

	cout << *max_element(dp[n - 1].begin(), dp[n - 1].end()) << '\n';
}
