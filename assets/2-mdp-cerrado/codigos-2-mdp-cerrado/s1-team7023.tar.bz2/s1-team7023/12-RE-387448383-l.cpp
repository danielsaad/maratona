#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n;
	cin >> n;

	n += 2;

	vector<int> val(n * 2, -1);
	val[1] = 1;
	vector<int> path;

	int ch = 0;

	function<void(int, int)> func = [&](int i, int d) {
		path.push_back(i);
		if (d == n - 1) {
			return;
		}
		int l = i + d;
		cout << "? " << l << endl;
		int ans;
		cin >> ans;

		if (ans == 1) {
			val[l] = 1;
			ch = path.size();
			func(l, d + 1);
			return;
		}

		func(i + d + 1, d + 1);
	};

	func(1, 1);

	int low = ch;
	int high = path.size() - 1;
	while (low < high) {
		int mid = (low + high + 1) >> 1;

		int ans;
		if (val[path[mid]] != -1) {
			ans = val[path[mid]];
		} else {
			cout << "? " << path[mid] << endl;
			cin >> ans;
			val[path[mid]] = ans;
		}

		if (ans == 0) {
			high = mid - 1;
			continue;
		}

		low = mid;
	}

	cout << "! " << path[low] << endl;
}
