#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	vector<string> a;
	string tmp;
	while (getline(cin, tmp)) {
		a.emplace_back(tmp);
	}

	for (int i = 0; i < a.size(); i++) {
		string &now = a[i];
		int cur = 0;
		while (isspace(now[cur])) {
			cur++;
		}

		while (cur < now.size()) {
			if (now.substr(cur, 2) == "if") {
				cout << "SE ";
				for (cur += 3; now[cur] != ':'; cur++) {
					cout << now[cur];
				}
				cout << " ENTAO ";
				cur += 2;
				continue;
			}

			if (now.substr(cur, 5) == "while") {
				cout << "ENQUANTO ";
				for (cur += 6; now[cur] != ':'; cur++) {
					cout << now[cur];
				}
				cout << ' ';
				cur += 2;
				continue;
			}

			if (now.substr(cur, 5) == "print") {
				cout << "APRESENTE ";
				for (cur += 6; now[cur] != ')'; cur++) {
					cout << now[cur];
				}
				cout << '\n';
				cur++;
				return 0;
			}

			cout << "LEIA ";
			for (; !isspace(now[cur]) && now[cur] != '='; cur++) {
				cout << now[cur];
			}
			cout << '\n';
			return 0;
		}
	}
}
