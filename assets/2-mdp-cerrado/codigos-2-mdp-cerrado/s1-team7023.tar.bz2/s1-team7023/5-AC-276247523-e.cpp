#include <bits/stdc++.h>

using namespace std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    const int maxn = 1e7 + 5;
    vector<int> p(maxn);
    iota(p.begin(), p.end(), 0);
    for(int i = 2; i < maxn; i++) {
        if(p[i] == i) {
            for(int j = 2 * i; j < maxn; j += i) {
                p[j] = i;
            }
        }
    }
    int n;
    cin >> n;
    vector<int> a(n);
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    vector<int> occ(maxn);
    for(int i = 0; i < n; i++) {
        int x = a[i];
        while(x != 1) {
            occ[p[x]]++;
            x /= p[x];
        }
    }
    vector<int> o;
    o.reserve(maxn);
    for(int i = 2; i < maxn; i++) {
        if(p[i] == i) {
            o.emplace_back(i);
        }
    }
    sort(o.begin(), o.end(), [&](int i, int j) {
        return occ[i] * i > occ[j] * j;
    });
    int ans = 0;
    for(int i = 0; i < (int) o.size(); i += 2) {
        ans += occ[o[i]] * o[i];
    }
    cout << ans << '\n';
    return 0;
}