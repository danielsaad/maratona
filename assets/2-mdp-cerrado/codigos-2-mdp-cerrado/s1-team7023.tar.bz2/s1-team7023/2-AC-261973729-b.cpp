#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

ld eps = 1e-9;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	ll a;
	cin >> a;

	ld deg = (a * acosl(-1)) / 180;

	if (abs(cos(deg) - sin(deg)) < eps) {
		cout << "Ambos\n";
		return 0;
	}

	if (cos(deg) > sin(deg)) {
		cout << "Costa\n";
		return 0;
	}

	cout << "Saad\n";
}
