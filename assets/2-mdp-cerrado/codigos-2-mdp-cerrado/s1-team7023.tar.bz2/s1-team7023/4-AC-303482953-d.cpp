#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n, q;
	cin >> n >> q;
	string a;
	cin >> a;

	vector<int> pos(26, n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < 26; j++) {
			if (j == a[i] - 'a') {
				continue;
			}
			pos[j] = min(pos[j], i);
		}
	}

	while (q--) {
		string b;
		cin >> b;

		size_t ans = max(a.size(), b.size());

		for (int i = 0; i < b.size(); i++) {
			ans = max(ans, a.size() + b.size() - pos[b[i] - 'a'] - i);
		}

		cout << ans << '\n';
	}
}
