#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	string a;
	string tmp;
	getline(cin, tmp);
	a += tmp;
	while (getline(cin, tmp)) {
		a.push_back(' ');
		int cur = 0;
		while (isspace(tmp[cur])) {
			cur++;
		}
		a += tmp.substr(cur);
	}

	int i = 0;
	while (i < a.size()) {
		if (a.substr(i, 2) == "if") {
			cout << "SE ";
			string tmp;
			i += 2;
			while (a[i] != ':') {
				tmp.push_back(a[i]);
				i++;
			}

			int j = 0;
			while (isspace(tmp[j])) {
				j++;
			}

			while (isspace(tmp.back())) {
				tmp.pop_back();
			}

			cout << tmp.substr(j);
			cout << " ENTAO ";
			i++;
			continue;
		}

		if (a.substr(i, 5) == "while") {
			cout << "ENQUANTO ";
			i += 5;
			while (a[i] != ':') {
				tmp.push_back(a[i]);
				i++;
			}

			int j = 0;
			while (isspace(tmp[j])) {
				j++;
			}

			while (isspace(tmp.back())) {
				tmp.pop_back();
			}

			cout << tmp.substr(j) << ' ';
			i++;
			continue;
		}

		if (a.substr(i, 5) == "print") {
			cout << "APRESENTE ";
			i += 6;
			while (a[i] != ')') {
				tmp.push_back(a[i]);
				i++;
			}

			int j = 0;
			while (isspace(tmp[j])) {
				j++;
			}

			while (isspace(tmp.back())) {
				tmp.pop_back();
			}

			cout << tmp.substr(j) << '\n';
			return 0;
		}

		cout << "LEIA ";
		while (isspace(a[i])) {
			i++;
		}
		while (!isspace(a[i]) && a[i] != '=') {
			cout << a[i];
			i++;
		}
		cout << '\n';
		return 0;
	}
}
