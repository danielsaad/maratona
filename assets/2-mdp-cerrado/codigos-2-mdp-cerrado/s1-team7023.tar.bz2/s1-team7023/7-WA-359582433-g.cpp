#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	string a;
	string tmp;
	getline(cin, tmp);
	a += tmp;
	while (getline(cin, tmp)) {
		a.push_back(' ');
		int cur = 0;
		while (isspace(tmp[cur])) {
			cur++;
		}
		a += tmp.substr(cur);
	}

	int i = 0;
	while (i < a.size()) {
		while (isspace(a[i])) {
			i++;
		}	
		if (a.substr(i, 3) == "if ") {
			cout << "SE ";
			string tmp;
			i += 3;
			while (a[i] != ':') {
				tmp.push_back(a[i]);
				if (a[i] == '"' || a[i] == '\'') {
					char opt = a[i];
					i++;
					while (a[i] != opt) {
						if (a[i] == '\\' && a[i + 1] == opt) {
							tmp.push_back('\\');
							tmp.push_back(opt);
							i += 2;
							continue;
						}
						tmp.push_back(a[i]);
						i++;
					}
					tmp.push_back(opt);
				}
				i++;
			}

			int j = 0;
			while (isspace(tmp[j])) {
				j++;
			}

			while (isspace(tmp.back())) {
				tmp.pop_back();
			}

			cout << tmp.substr(j);
			cout << " ENTAO ";
			i++;
			continue;
		}

		if (a.substr(i, 6) == "while ") {
			cout << "ENQUANTO ";
			i += 6;
			while (a[i] != ':') {
				tmp.push_back(a[i]);
				if (a[i] == '"' || a[i] == '\'') {
					char opt = a[i];
					i++;
					while (a[i] != opt) {
						if (a[i] == '\\' && a[i + 1] == opt) {
							tmp.push_back('\\');
							tmp.push_back(opt);
							i += 2;
							continue;
						}
						tmp.push_back(a[i]);
						i++;
					}
					tmp.push_back(opt);
				}
				i++;
			}

			int j = 0;
			while (isspace(tmp[j])) {
				j++;
			}

			while (isspace(tmp.back())) {
				tmp.pop_back();
			}

			cout << tmp.substr(j) << ' ';
			i++;
			continue;
		}

		if (a.substr(i, 6) == "print(") {
			cout << "APRESENTE ";
			i += 6;
			if (isspace(a[i])) {
				i++;
			}
			while (a[i] != ')') {
				tmp.push_back(a[i]);
				if (a[i] == '"' || a[i] == '\'') {
					char opt = a[i];
					i++;
					while (a[i] != opt) {
						if (a[i] == '\\' && a[i + 1] == opt) {
							tmp.push_back('\\');
							tmp.push_back(opt);
							i += 2;
							continue;
						}
						tmp.push_back(a[i]);
						i++;
					}
					tmp.push_back(opt);
				}
				i++;
			}

			int j = 0;
			while (isspace(tmp[j])) {
				j++;
			}

			while (isspace(tmp.back())) {
				tmp.pop_back();
			}

			cout << tmp.substr(j) << '\n';
			return 0;
		}

		cout << "LEIA ";
		while (isspace(a[i])) {
			i++;
		}
		while (!isspace(a[i]) && a[i] != '=') {
			cout << a[i];
			i++;
		}
		cout << '\n';
		return 0;
	}
}
