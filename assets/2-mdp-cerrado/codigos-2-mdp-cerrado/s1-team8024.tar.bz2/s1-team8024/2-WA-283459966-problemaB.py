from math import cos, sin

def main(a):
    if a < 0 or a > 90 : return 

    if cos(a) > sin(a):
        print("Costa")
    elif cos(a) < sin(a):
        print("Saad")
    elif cos(a) == sin(a):
        print("Ambos")
