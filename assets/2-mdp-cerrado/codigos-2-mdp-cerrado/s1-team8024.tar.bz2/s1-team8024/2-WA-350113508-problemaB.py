from math import cos, sin, degrees, radians

def main():
    a = int(input())

    if a < 0 or a > 90 : return 

    coss = cos(radians(a))
    sinn = sin(radians(a))

    if coss > sinn:
        print("Costa")
    elif coss < sinn:
        print("Saad")
    elif coss == sinn:
        print("Ambos")

main()