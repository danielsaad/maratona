from datetime import datetime
from datetime import date
from time import time

def main():
    dat_final = input()
    dat_atual = input()

    if dat_atual is None or dat_final is None:
        return

    final_obj = datetime.strptime(dat_final, "%H:%M")
    atual_obj = datetime.strptime(dat_atual, "%H:%M")

    if final_obj.hour > 20 or final_obj.hour < 8:
        return
    if atual_obj.hour > 20 or atual_obj.hour < 8:
        return
    
    restante = final_obj - atual_obj
    print(str(restante)[:-3])


main()