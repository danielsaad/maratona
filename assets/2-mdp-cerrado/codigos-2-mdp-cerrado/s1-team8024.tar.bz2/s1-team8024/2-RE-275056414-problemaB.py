from math import cos, sin
import os
a = os.sys.argv[1]

def main():
    if a == None:
        return
    b = int(a)
    
    if b < 0 or b > 90 : return 

    if cos(b) > sin(b):
        return "Costa"
    elif cos(b) < sin(b):
        return "Saad"
    else:
        return "Ambos"

main()