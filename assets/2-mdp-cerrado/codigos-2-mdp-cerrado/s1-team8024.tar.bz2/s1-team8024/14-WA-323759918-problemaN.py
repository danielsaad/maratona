from datetime import datetime
from datetime import date

def main():
    dat_final = input()
    dat_atual = input()

    if dat_atual is None or dat_final is None:
        return
    
    dat_atual = [int(x) for x in list(dat_atual.split(":"))]
    dat_final = [int(x) for x in list(dat_final.split(":"))]

    resultado: list = []
    resultado.append(dat_final[0] - dat_atual[0])
    resultado.append(dat_final[1] - dat_atual[1])

    return f"{str(resultado[0])}:{str(resultado[1])}"

main()