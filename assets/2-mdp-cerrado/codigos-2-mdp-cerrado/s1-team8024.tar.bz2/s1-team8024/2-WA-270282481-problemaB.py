from math import cos, sin

def main(a:int):
    if a < 0 or a > 90 : return 

    if cos(a) > sin(a):
        return "Costa"
    elif cos(a) < sin(a):
        return "Saad"
    else:
        return "Ambos"
