from math import cos, sin, degrees, radians

def main():
    a = int(input())

    coss = cos(radians(a))
    sinn = sin(radians(a))

    print

    if coss > sinn:
        print("Costa")
    elif coss < sinn:
        print("Saad")
    elif coss == sinn:
        print("Ambos")

main()