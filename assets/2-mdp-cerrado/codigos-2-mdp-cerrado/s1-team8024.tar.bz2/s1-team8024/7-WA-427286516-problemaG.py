def main():
    s = input()

    output = []
    expressions = s.split(': ')
    for ex in expressions:
        ex_splitted = ex.split(" ")
        for i, word in enumerate(ex_splitted):
            if "input" in word:
                output.append(f"LEIA {ex_splitted[i - 2]}")
                break
            elif "print" in word:
                first_splitted = ex.split("(")
                sec_splitted = first_splitted[1].split(")")

                output.append(f"APRESENTE {sec_splitted[i - 2]}")
                break
            elif "if" in word:
                sdp = [x for x in ex_splitted if x != ":" and x != "if"]
                output.append(f"SE")
                for i in sdp:
                        output.append(i)
                output.append("ENTAO")
                break
            elif "while" in word:
                sdp = [x for x in ex_splitted if x != ":" and x != "while"]
                output.append(f"ENQUANTO")
                for i in sdp:
                        output.append(i)
                break
    for i, word in enumerate(output):
        if i == len(output)-1:
            print(word)
            break
        
        print(word, end=" ")

main()