def main():
    n = int(input())
    d = [x.lower() for x in input()]
    g = "c"
    count = 0

    #print(d)
    #print(n)

    for movimento in d:
        if movimento not in ['c', 'd', 'e']: continue

        if movimento in ['d', 'e'] and g == 'c':
            g = movimento
            count += 1
        elif movimento == g:
            count += 1
        elif movimento in ['d', 'e'] and g != 'c' and g != movimento:
            g = 'c'
        elif g in ['d', 'e'] and movimento == 'c':
            g = 'c'
            count += 1
       
    print(count)


main()