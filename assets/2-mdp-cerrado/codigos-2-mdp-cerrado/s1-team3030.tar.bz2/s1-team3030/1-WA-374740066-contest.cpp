#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vll = vector<ll>;
#define endl '\n'

void dbg(const vll& v){
	for(auto x:v)
		cout << x << ' '; 
	cout << endl;
}

void solve(){
	ll n, c; cin >> n >> c;
	vll xs(n); for(auto&x:xs) cin >> x;
	while(c--){
		ll i, t; cin >> i >> t;
		xs[i-1] += t;
	}
	dbg(xs);
	ll comp = xs[0], cnt = 0;
	for(int i = 0; i < n-1; i++){
		cout << ++cnt << endl;
		if(comp <= xs[i+1]){
			comp = xs[i+1];
			cnt = 0;
		}
	}
}

int main(){
	cin.tie(0)->sync_with_stdio(0);
	solve();
}
