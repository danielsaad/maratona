#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define endl '\n'

void solve(){
	ll a; cin >> a;
	if(a == 45) cout << "Ambos\n";
	else cout << (a < 45 ? "Costa\n":"Saad\n");
}

int main(){
	cin.tie(0)->sync_with_stdio(0);
	ll t_ = 1;
	//cin >> t_;
	while(t_--) solve();
}
