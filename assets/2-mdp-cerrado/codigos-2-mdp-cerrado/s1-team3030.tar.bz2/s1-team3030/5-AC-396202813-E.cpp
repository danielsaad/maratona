#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vll = vector<ll>;
#define endl '\n'

void dbg(const vll& v){
	for(auto x:v)
		cout << x << ' '; 
	cout << endl;
}

void solve(){
	ll n; cin >> n;
	vll xs(n); for(auto&x:xs) cin >> x;
	ll MAX = 1e7+5;
	vll crivo(MAX);
	for(ll i = 2; i <= MAX; i++){
		if(crivo[i] == 0){
			crivo[i] = i;
			for(ll j = i*i; j <= MAX; j+=i)
				if(crivo[j] == 0)
					crivo[j] = i;
		}
	}

	map<ll, ll> factors;
	auto add_factors = [&](ll n){
		while(n > 1){
			factors[crivo[n]]++;
			n /= crivo[n]; 
		}
	};

	for(auto x:xs)
		add_factors(x);

	vll points;
	for(auto[p,e]:factors)
		points.emplace_back(p*e);
	sort(points.begin(), points.end());

	ll ans = 0;
	for(int i = points.size()-1; i >= 0; i -= 2)
		ans += points[i];

	cout << ans << endl;

}

int main(){
	cin.tie(0)->sync_with_stdio(0);
	solve();
}
