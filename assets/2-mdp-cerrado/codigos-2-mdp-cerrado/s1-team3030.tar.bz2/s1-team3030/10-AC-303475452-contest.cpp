#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define endl '\n'

void solve(){
	ll n; cin >> n;
	string s; cin >> s;
	ll cnt = 0;
	for(int i = 0; i < n-1; i++){
		if((s[i] == 'E' and s[i+1] == 'D') or (s[i] == 'D' and s[i+1] == 'E')){
			cnt++;
			i++;
		}
	}
	cout << n - cnt << endl;
}

int main(){
	cin.tie(0)->sync_with_stdio(0);
	ll t_ = 1;
	//cin >> t_;
	while(t_--) solve();
}
