#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define endl '\n'

void solve(){
	ll hf, mf, hi, mi;
	scanf("%lld:%lld %lld:%lld", &hf, &mf, &hi, &mi);
	ll tf = hf*60 + mf, ti = hi*60 + mi;
	ll ans = tf-ti;
	printf("%02lld:%02lld\n", ans/60, ans%60);
}

int main(){
	cin.tie(0)->sync_with_stdio(0);
	ll t_ = 1;
	//cin >> t_;
	while(t_--) solve();
}
