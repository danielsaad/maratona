#include <bits/stdc++.h>
using namespace std;

#define ll long long

vector<int> siege(int limit) {
    vector<bool> isPrime(limit + 1, true);
    isPrime[0] = isPrime[1] = false;

    for (int i = 2; i * i <= limit; i++) {
        if (isPrime[i]) {
            for (int j = i * i; j <= limit; j += i) {
                isPrime[j] = false;
            }
        }
    }

    vector<int> primes;
    for (int i = 2; i <= limit; i++) {
        if (isPrime[i]) {
            primes.push_back(i);
        }
    }

    return primes;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n, maxi=-1, tmp, idx = 0, fator = 0, pontos = 0;
    ll num = 1;
    cin >> n;

    vector<int> st;

    for (int i = 0; i < n; i++){
        cin >> tmp;
        num *= tmp;
        maxi = max(maxi, tmp);
    }
    vector<int> primos = siege(maxi);
    while(num!=1){
        //cout << "N " << num <<  " primo " << primos[idx] << '\n';
        if (num % primos[idx] == 0) {
            num /= primos[idx];
            fator += primos[idx];
        }
        else {
            idx++;
            //cout << fator << '\n';
            if (fator)  st.push_back(fator);
            fator = 0;
        }
    }

    st.push_back(fator);

    sort(st.begin(), st.end());

    for (int i = st.size() - 1; i >= 0; i -= 2) {
        pontos += st[i];
    }

    cout << pontos << '\n';

    return 0;
}