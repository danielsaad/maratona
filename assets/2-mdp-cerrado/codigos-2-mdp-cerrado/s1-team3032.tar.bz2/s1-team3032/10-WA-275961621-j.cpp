#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define endl '\n'

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n; cin >> n;
    string chutes; cin >> chutes;
    vector<int> v(n+1);
    int cont = 0;
    v[0] = 1;

    for (int i = 1; i <= n; ++i) {
        if (chutes[i-1] == 'E') v[i] = 0;
        else if (chutes[i-1] == 'C') v[i] = 1;
        else if (chutes[i-1] == 'D') v[i] = 2;

        if (abs(v[i]-v[i-1]) < 2) cont++;
    }

    cout << cont << endl;

    return 0;
}