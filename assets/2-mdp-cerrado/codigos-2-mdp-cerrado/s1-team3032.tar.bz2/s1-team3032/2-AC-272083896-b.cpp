#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    double a;
    float costa, saad;
    cin >> a;

    a = (a * acos(-1.0) / (180.0));

    costa = cos(a);
    saad = sin(a);

    // cout << costa << " " << saad << '\n';

    if (costa > saad)   cout << "Costa\n";
    else if (costa < saad)  cout << "Saad\n";
    else    cout << "Ambos\n";


    return 0;
}