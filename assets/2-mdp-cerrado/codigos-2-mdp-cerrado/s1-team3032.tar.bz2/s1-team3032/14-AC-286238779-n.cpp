#include <bits/stdc++.h>
using namespace std;

#define ll long long

int minutize(string s) {
    int minutes = ((s[0] -'0') * 10 + (s[1] - '0')) * 60;
    minutes += (s[3] -'0') * 10 + (s[4] - '0');
    return minutes;
}

void deminutize(int result) {
    int hours = result / 60;
    int minutes = result % 60;
    string final = "";
    cout << (hours / 10);
    cout << (hours % 10) << ":";
    cout << (minutes / 10);
    cout << (minutes % 10);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int beg_time, end_time;
    string begin, end;
    cin >> end >> begin;
    end_time = minutize(end);
    beg_time = minutize(begin);
    deminutize(end_time - beg_time);

    return 0;
}