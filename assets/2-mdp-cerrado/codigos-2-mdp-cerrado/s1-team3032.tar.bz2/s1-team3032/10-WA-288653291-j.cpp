#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define endl '\n'

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n, cont=1; cin >> n;
    string s; cin >> s;
    for(int i=1, l=s.length()-1; i<l; i++){
        if((s[i]=='E' && s[i-1]=='D') || (s[i]=='D' && s[i-1]=='E')) continue;
        cont++;
    }
    cout << cont << endl;
    return 0;
}