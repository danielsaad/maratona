#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define endl '\n'

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n, cont = 0; cin >> n;
    char cur = 'C';
    string s; cin >> s; 
    for(int i=0, l=s.length(); i<l; i++){
        //cout << "goleiro " << cur << " bola " << s[i] << '\n';
        if (cur == s[i]) cont++;   
        else if (cur == 'C' && (s[i] == 'D' || s[i] == 'E')) {
            if (s[i] == 'D')    cur = 'D';
            else    cur = 'E';    
            cont++;
        } 
        else {
            if (s[i] == 'C') {
                cont++;
            }
            cur = 'C';
        }
        //cout <<" pontos " << cont <<  '\n';
    }
        cout << cont << '\n';
    return 0;
}