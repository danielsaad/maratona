#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;

signed main(){
    amain
    string a, b;
    cin>>a>>b;
    int p, s, t, q;
    p=a[0]-'0';
    p=p*10;
    p+=a[1]-'0';
    s=a[3]-'0';
    s*=10;
    s+=a[4];
    p=p*60+s;
    t=b[0]-'0';
    t=t*10;
    t+=b[1]-'0';
    q=b[3]-'0';
    q*=10;
    q+=b[4];
    t=t*60+q;
    if((p-t)/60==0) cout<<0;
    cout<<(p-t)/60<<':'<<(p-t)%60;
    if((p-t)%60==0) cout<<0;
    cout<<endl;
}