#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;

signed main(){
    amain
    int n;
    cin>>n;
    string s;
    cin>>s;
    vector<vector<int>> dp(n+1, vector<int> (3, -1));
    auto fufu = [&] (auto &&fufu, int i, int p){
        if(i==n) return dp[i][p]=0;
        if(dp[i][p]!=-1) return dp[i][p];
        int e, d, c;
        e=d=c=0;
        if(p==0){
            e=fufu(fufu, i+1, 0);
            c=fufu(fufu, i+1, 1);
        }
        if(p==1){
            e=fufu(fufu, i+1, 0);
            c=fufu(fufu, i+1, 1);
            d=fufu(fufu, i+1, 2);
        }
        if(p==2){
            c=fufu(fufu, i+1, 1);
            d=fufu(fufu, i+1, 2);
        }
        return dp[i][p]=max({e, c, d})+((p==0 and s[i]=='E') or (p==1 and s[i]=='C') or (p==2 and s[i]=='D') ? 1 : 0);
    };
    int p, pao, t;
    p=fufu(fufu, 0, 0);
    dp=vector<vector<int>>(n+1, vector<int> (3, -1));
    pao=fufu(fufu, 0, 1);
    dp=vector<vector<int>>(n+1, vector<int> (3, -1));
    t=fufu(fufu, 0, 2);
    cout<<max({p, pao, t})<<endl;
}