#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;



signed main(){
    amain
    unordered_map<int,vector<int>> mem;
    unordered_map<int,int> acc;

    int n; cin>>n;
    vector<int> v(n);
    for(auto &it:v) cin>>it;

    int at=0;

    auto func=[&](auto&& ff,int num)->void {
        if(num<=1) return;
        int lim=sqrt(num)+1;
        bool   ver=true;
        for(int i=2;i<=lim;i++) {
            if(num%i==0) {
                ver=false;
                acc[i]++;
                mem[at].push_back(i);
                ff(ff,num/i);
                break;
            }
        }
        if(ver) {
            acc[num]++;
            mem[num].push_back(num);

            if(num!=at) {
                mem[num].push_back(num);
            }
        }
    };

    for(auto &it:v) {
        at=it;
        if(mem.count(at)) {
            for(auto &it1:mem[at]) {
                acc[it1]++;
            }
            continue;
        }
        func(func,at);
    }
    vector<int> ans;
    for(auto& [chave,valor]:acc) {
        ans.push_back(chave*valor);

        //cout<<chave<<" : "<<valor<<endl;
    }
    sort(ans.rbegin(),ans.rend());


    int alberto=0;
    for(int i=0;i<ans.size();i++) {
        if(!(i&1)) alberto+=ans[i];
    }
    //for(auto it:ans) cout<<it<<" ";

    cout<<alberto<<endl;


}