#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;

signed main(){
    amain
    int n, q;
    cin>>n>>q;
    vector<int> ve(n);
    map<int, int> mp;
    for(int &i: ve) cin>>i;
    for(int i=0 ; i<q ; i++){
        int a, b;
        cin>>a>>b;
        mp[a]=b;
    }
    if(q){
        int soma=0;
        for(int i=mp.rbegin()->first-1 ; i>=0 ; i--){
            soma+=mp[i+1];
            ve[i]+=soma;
        }
    }
    stack<int> st;
    st.push(ve[0]);
    for(int i=1 ; i<n ; i++){
        cout<<st.size()<<endl;
        while(st.size() and ve[i]>=st.top()){
            st.pop();
        }
        st.push(ve[i]);
    }
}