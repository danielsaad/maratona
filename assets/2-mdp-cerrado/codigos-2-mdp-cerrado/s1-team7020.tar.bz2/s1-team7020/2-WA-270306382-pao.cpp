#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;

signed main(){
    amain
    long double n;
    cin>>n;
    n=n*3.14159265/180;
    //cout << (sin(n)==cos(n)) << endl;
    //cout<<sin(n)<<' '<<cos(n)<<endl;
    if((float)sin(n)>(float)cos(n)){
        cout<<"Saad"<<endl;
    }
    else if((float)sin(n)<(float)cos(n)){
        cout<<"Costa"<<endl;
    }
    else cout<<"Empate"<<endl;
}