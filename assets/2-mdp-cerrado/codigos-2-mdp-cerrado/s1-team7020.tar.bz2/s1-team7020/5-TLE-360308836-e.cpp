#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;
vector<bool> fds(1e7+8, false);
vector<int> primes;

signed main(){
    int n;

    for(int i=2 ; i<1e7+8 ; i++){
        if(fds[i]) continue;
        primes.push_back(i);
        for(int j=i; j<1e7+8 ; j+=i){
            fds[j]=true;
        }
    }
    cin >> n;
    unordered_map<int,int> pt;

    
    for(int i=0;i<n;i++){
        int ai;
        cin >> ai;

        int j=0;
        int cont=0;
        int aii = ai;
        while(ai>1){
            if(ai%primes[j]==0) {
                pt[primes[j]]++;
                ai/=primes[j];
            }
            else {
                j++;
            }
        }
    }
    vector<int> total;

    for(auto &[chave,valor] : pt) {
        total.push_back(chave*valor);
    }
    sort(total.begin(),total.end(),greater<int>());

    int alberto=0;
    for(int i=0;i<total.size();i++){
        if(i%2==0) alberto+=total[i];
    }

    cout << alberto << endl;
}