#include <bits/stdc++.h>
using namespace std;
#define int long long
//#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;

signed main(){
    int t;
    cin >> t;

    int n=1;;
    for(int i=0;i<t;i++) {
        cout << "? " << n*2<< endl;

        int r0,r1=0;
        cin >> r0;
        if(!r0) {
            cout << "? " << n*2+1<<endl;
            cin >> r1;
            if(r1==1) n=n*2+1;
        }
        else n=n*2;
    }
    cout << "! " << n;
}