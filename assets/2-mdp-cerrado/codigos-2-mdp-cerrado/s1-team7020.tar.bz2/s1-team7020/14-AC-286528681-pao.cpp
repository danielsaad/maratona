#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define amain ios_base::sync_with_stdio(0);cin.tie(0);
const int inf = 1e18;

signed main(){
    amain
    int a, b;
    char fds;
    cin>>a>>fds>>b;
    int final=a*60+b;
    cin>>a>>fds>>b;
    int com=a*60+b;
    final=final-com;
    if(final/60<=9) cout<<0;
    cout<<final/60<<':';
    if(final%60<=9) cout<<0;
    cout<<final%60<<endl;
    
    cout<<endl;
}