#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

vector<int> primos;

void sieve(int X){
    vector<int> primo(X+100, 1);
    for(int i=2;i<X;i++){
        if(primo[i]){
            primos.push_back(i);
            for(int j=2*i;j<X;j+=i){
                primo[j]=0;
            }
        }
    }
}

void test(){
    sieve(int(1e6+5));

    int n;cin>>n;
    vector<int>v(n);for(int&x:v)cin>>x;

    map<int, ll> mp;
    for(int x:v){
        int t=x;
        for(int p: primos){
            if(1ll * p * p > t) break;
            if(t % p != 0) continue;

            int cnt=0;
            while(t % p == 0){
                t/=p;
                cnt++;
            }

            mp[p] += 1ll * p * cnt;
        }
        
        if(t > 1){
            mp[t] += t * 1;
        }
    }


    priority_queue<ll> pq;
    int turno=1;
    ll ans=0;

    for(auto [p, f]: mp){
        pq.push(f);
    }

    while(pq.size()){
        ll x = pq.top();
        pq.pop();

        if(turno&1) ans += x;
        turno^=1;
    }

    cout<<ans<<el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}