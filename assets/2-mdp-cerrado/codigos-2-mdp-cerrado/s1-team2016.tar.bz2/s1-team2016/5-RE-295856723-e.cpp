#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

const int X = 1e7+5;
vector<pair<int,int>> fat[X];
vector<int>primos;
int freq[X];
ll caras[X];

void sieve(){
    vector<int>primo(X+100,1);
    for(int i=2;i<X;i++){
        if(primo[i]){
            fat[i].emplace_back(i,1);

            caras[i] += 1ll * freq[i] * 1;

            primos.push_back(i);
            for(int j=2*i;j<X;j+=i){
                primo[j]=0;
                if(!freq[j]) continue;

                int t=j;
                int cnt=0;
                while(t%i==0){
                    t/=i;
                    cnt++;
                }

                caras[i] += 1ll * freq[j] * cnt;
                // fat[j].emplace_back(i,cnt);
            }
        }
    }
}


void test(){
    
    int n;cin>>n;
    vector<int>v(n);
    for(int&x:v){
        cin>>x;
        freq[x]++;
    }
    
    sieve();
    // for(int x:v){
    //     for(auto [p,f]: fat[x]){
    //         caras[p] += f;
    //     }
    // }

    priority_queue<ll> pq;
    for(int x:primos){
        if(!caras[x]) continue;
        pq.push(1ll * x * caras[x]);
    }

    int turno = 0;
    ll ans=0;
    while(pq.size()){
        ll x = pq.top();
        pq.pop();
        if(turno&1){

        }
        else{
            ans += x;
        }
        turno++;
    }

    cout<<ans<<el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}