#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

const ll mod=998244353;
struct mi{
    int v;
    explicit operator int() const{return v;}
    mi(ll vv=0) : v(vv%mod){v+=(v<0)*mod;}
    friend mi& operator+=(mi& a, mi b){if((a.v +=b.v) >= mod) a.v-=mod; return a;   }
    friend mi& operator-=(mi&a, mi b){if((a.v -= b.v) < 0) a.v += mod; return a;}


    friend mi& operator*=(mi&a, mi b){a.v = 1ll * a.v * b.v % mod; return a;}
    friend mi& operator/=(mi&a, mi b){a = a*inv(b); return a;}

    friend mi operator+(mi a, mi b){return a+=b;}
    friend mi operator-(mi a, mi b){return a-=b;}
    friend mi operator*(mi a, mi b){return a*=b;}
    friend mi operator/(mi a, mi b){return a/=b;}

    friend mi fexp(mi a, ll b){
        mi ans = 1;
        while(b){
            if(b&1)ans*=a;
            b>>=1;
            a*=a;
        }
        return ans;
    }

    friend mi inv(mi a){return fexp(a, mod-2);}
    friend ostream& operator<<(ostream& out, mi at){ return out << at.v; }
    friend istream& operator>>(istream& in, mi& at){ return in >> at.v; }
};

vvc<mi> tmp(2,vc<mi>(2));
void mult(vvc<mi>& c,vvc<mi>&a,vvc<mi>&b){
    int n = 2;
    for(int i=0; i<n; i++)for(int j=0; j<n; j++) tmp[i][j] =0;
    for(int i=0;i<n; i++) for(int j=0; j<n; j++) for(int k=0; k<n;k++)
        tmp[i][j] += a[i][k]*b[k][j];
    for(int i=0; i<n; i++)for(int j=0; j<n; j++) c[i][j] = tmp[i][j];
}

vvc<mi> res(2,vc<mi>(2)),aux(2,vc<mi>(2));
vvc<mi> calc(ll a, ll b, ll p){
    res[0][0]=1,res[0][1]=0;
    res[1][0]=0,res[1][1]=1;

    aux[0][0]=a,aux[0][1]=1;
    aux[1][0]=b,aux[1][1]=0;
    while(p){
        if(p&1) mult(res,res,aux);
        p>>=1;
        mult(aux,aux,aux);
    }
    return res;
}

void test(){
    ll A,B,n,m,vn,vm;
    cin >> A >>B>>n>>m>>vn>>vm;
    vvc<mi> mat1 = calc(A,B,n-1);
    vvc<mi> mat2 = calc(A,B,m-1);
    vc<mi> a = {mat1[0][0],mat1[1][0]};  
    // cout << a[0] << ' ' <<a[1] <<el;
    vc<mi> c = {mat2[0][0],mat2[1][0]};
    vc<mi> b = {vn,vm};     
    mi zero = (b[0] - (a[0]*b[1])/c[0]) / (a[1] - (a[0]*c[1])/c[0]);
    mi um = (b[0] - a[1] * zero)/a[0];
    cout <<  zero << ' ' << um << el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    cin>>t;
    while(t--){
        test();
    }

    return 0;
}