#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

const int MAX = 2e5+10;
const int inf = 1e9;

int a[MAX];
int b[MAX<<2];
int vis[MAX];
vvc<int> gp;
int c[MAX<<1],dp[MAX<<1];

void calc(string& t, string& s){
    string str = t + "#" + s;
    vc<int> z(str.size(),0);
    for(int l=-1,r=-1,i=1; i<str.size(); i++){
        int qt =0;
        if(r >= i) qt = min(r-i,z[i-l]);
        while(i+qt<str.size() && str[qt] == str[i+qt]) qt++;
        z[i] =qt;
        if(r<i+qt-1) l =i,r=i+qt-1;
    }
    int p = t.size()+1;
    for(int i=t.size()+1; i-p<s.size(); i++) b[i-p] = (z[i] >= t.size());
}
int calc(vc<int>& v){
    int n = v.size();
    bool dif = true;
    // for(auto x : v) cout << x << ' ';
    // cout << el;
    for(int i=0; i<n; i++) dif &= (b[v[i]] * a[v[i]] != 0);
    if(dif) return inf;
    // cout <<"foi" << el;
    for(int i=0; i<2*n; i++) c[i] = b[v[i%n]] * a[v[i%n]];
    dp[2*n-1] = c[2*n-1];
    int ans = dp[2*n-1];
    for(int i=2*n-2; i>=0; i--){
        dp[i] = (dp[i+1] == 0 ? c[i] : (c[i] == 0 ? 0 : dp[i+1]+c[i]));
        ans = max(ans, dp[i]);
    }
    return ans;
}

void test(){
    string s,t;
    cin >> s >> t;
    int n = s.size() , m =t.size();
    for(int i=0; i<n; i++) cin >> a[i];
    for(int i=0;s.size()<2*t.size(); i=(i+1)%n) s.push_back(s[i]);
    calc(t,s);
    vc<int> aux;
    for(int i=0; i<n; i++) if(!vis[i]){
        int j = i;
        while(!vis[j]){ 
            aux.push_back(j);
            vis[j] = 1;
            j = (j + t.size()) % n;
        }
        gp.push_back(aux);
        aux.clear();
    }
    // for(int i=0; i<n; i++) cout << b[i] << ' ';
    // cout << el;
    int ans = 0;
    for(auto& v : gp) ans = max(ans, calc(v));
    cout << (ans == inf ? -1 : ans) << el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}