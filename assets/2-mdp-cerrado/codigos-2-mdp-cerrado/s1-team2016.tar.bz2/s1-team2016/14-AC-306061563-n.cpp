#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
#define el '\n'
using ll = long long;
using ld = long double;

void test(){
    string a, b;
    cin >> a >> b;
    int xx = stoi(b.substr(3));
    int xy = stoi(a.substr(3));

    int v, vv;
    bool ok=false;
    if(xx<=xy){
        v = xy-xx;
    }
    else{
        v = 60-(xx-xy);
        ok=true;
    }

    // dbg(ok);

    xx = stoi(b.substr(0,2));
    xy = stoi(a.substr(0,2));

    if(xx<=xy) vv=((xy-xx)-ok+24)%24; 
    else vv=24-(xx-xy)-ok;
    if(vv<10)cout<<"0";
    cout<<vv<<":";
    if(v<10)cout<<0;
    cout<<v<<el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}