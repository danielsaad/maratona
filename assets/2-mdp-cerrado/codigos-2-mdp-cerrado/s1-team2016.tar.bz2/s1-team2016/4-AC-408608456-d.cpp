#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

const int inf = 1e7;

int n;
string s,t;
int poss[30],post[30];

int solve(string& str, int* pos, int tam){
    int ft = inf;
    for(int i=0; i<30; i++) if(i != str[0]-'a' && pos[i] != -1) ft = min(ft,pos[i]);
    return (ft == inf ? 0 : str.size() + tam-ft);
}

void test(){
    cin>>t;
    for(int i=0;i<30;i++)post[i]=-1;
    for(int i=0;i<t.size();i++) if(post[t[i]-'a']==-1)post[t[i]-'a']=i;
    int ans = max(t.size(),s.size());
    ans = max(ans,solve(s,post,t.size()));
    ans = max(ans,solve(t,poss,s.size()));
    cout << ans <<el;   
}   

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    cin>>n>>t;
    cin>>s;
    for(int i=0;i<30;i++)poss[i]=-1;
    for(int i=0;i<n;i++) if(poss[s[i]-'a']==-1)poss[s[i]-'a']=i;
    while(t--){
        test();
    }

    return 0;
}