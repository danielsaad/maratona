#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

int ask(int x){
    cout << "? " <<x<<endl;
    cin>>x;
    return x;
}
void say(int x){
    cout<<"! "<<x<<endl;
}

void test(){
    int n;
    cin >>n;
    ll dep = 1,at=1,pos=1;
    ll tot =0;
    vc<int> bag; 
    // n queries
    while(dep!=n+2){
        tot += dep;
        bag.push_back(at);
        ll lef = tot + pos, rig = tot+pos+1;
        int x = (dep+1==n+2 ? 0 : ask(lef));
        at=(x ? lef:rig);
        pos=(x ? pos:pos+1);
        dep++;
    }
    bag.push_back(at);
    int l=0,r=int(bag.size())-1,mid,ans=0;
    while(l <=r){
        mid=l+r;
        mid>>=1;
        if(ask(bag[mid]))ans=mid,l=mid+1;
        else r=mid-1;
    }
    say(bag[ans]);
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}