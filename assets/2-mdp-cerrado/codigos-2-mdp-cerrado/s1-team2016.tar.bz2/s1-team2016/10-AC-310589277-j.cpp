#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

const int N = 2e5+10;

// 0=esquerda, 1=centro,2=direita
int dp[N][3];
int v[N];
int n;

int solve(int id, int pos) {
    if(id == n) return 0;
    int &rs = dp[id][pos];
    if(rs!=-1) return rs;
    rs=0;
    if(pos-1>=0) rs=max<int>(rs,solve(id+1,pos-1)+(pos == v[id]));
    if(pos+1<3) rs=max<int>(rs,solve(id+1,pos+1)+(pos == v[id]));
    rs=max<int>(rs,solve(id+1,pos)+(pos==v[id]));

    return rs;
}

void test(){
    memset(dp,-1,sizeof dp);
    cin >> n;
    string s; cin >> s;
    for(int i=0; i<n; i++) {
        if(s[i]=='C') v[i]=1;
        if(s[i]=='D') v[i]=2;
        if(s[i]=='E') v[i]=0;
    }

    int rs = 0;
    for(int i=0; i<3; i++) rs=max<int>(rs,solve(0,i));
    cout<<rs<<el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}