#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

enum e {IF=0, WHILE, INPUT, PRINT};

int checa(string& linha){
    if(linha.back() == ':'){ //if ou while
        if(linha[0] == 'i'){ //if
            return IF;
        }
        else{ //while
            return WHILE;
        }
    }
    else{ //input ou print
        if(linha[linha.size()-2] == '('){ //input
            return INPUT;
        }
        else{ // print
            return PRINT;
        }
    }
}

string linha;
void solve_input(){
    string var="";
    for(char c:linha){
        if(c==' ')break;
        var.push_back(c);
    }
    cout<<"LEIA "<<var<<el;
}

void solve_print(){
    string cara;

    for(int i=6; i < linha.size() - 1 ; i++){
        cara.push_back(linha[i]);
    }

    cout<<"APRESENTE "<<cara<<el;
}   

void solve_if(){
    string prox;
    getline(cin, prox);

    string expr="";
    for(int i=3;i<linha.size()-1;i++){
        expr.push_back(linha[i]);
    }

    while(1){
        
        int ok = (prox[0] >= 'a' && prox[0] <= 'z');
        ok |= (prox[0] >= 'A' && prox[0] <= 'Z');
        if(ok) break;

        reverse(all(prox));
        prox.pop_back();
        reverse(all(prox));
    }

    cout<<"SE " << expr<<" ENTAO ";

    swap(linha,prox);
    int t = checa(linha);
    if(t == PRINT) solve_print();
    else solve_input();
    swap(linha,prox);
}

void solve_while(){
    string prox;
    getline(cin, prox);

    while(1){
        
        int ok = (prox[0] >= 'a' && prox[0] <= 'z');
        ok |= (prox[0] >= 'A' && prox[0] <= 'Z');
        if(ok) break;

        reverse(all(prox));
        prox.pop_back();
        reverse(all(prox));
    }

    string expr;
    for(int i=6; i < linha.size() - 1; i++){
        expr.push_back(linha[i]);
    }

    cout<<"ENQUANTO "<<expr<<" ";
    
    swap(linha,prox);   
    int t = checa(linha);
    if(t == PRINT) solve_print();
    else solve_input();
    swap(linha,prox);
}

void test(){
    while(getline(cin, linha)){
        int t = checa(linha);
        if(t == IF) solve_if();
        else if(t == WHILE) solve_while();
        else if(t == PRINT) solve_print();
        else solve_input();
    }
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}