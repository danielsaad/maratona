#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

void test(){
    int x;
    cin>>x;
    if(x == 45) cout <<"Ambos"  <<el;
    else if(x<45) cout << "Costa" <<el;
    else cout << "Saad" <<el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}