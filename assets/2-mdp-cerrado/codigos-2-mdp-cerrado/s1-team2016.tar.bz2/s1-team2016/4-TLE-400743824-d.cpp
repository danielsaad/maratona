#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

int n;
string s,t;

int solve(string s, string t){
    reverse(all(t));

    int aux = t.size();

    while(t.size()){
        if(s[0] != t.back()) break;
        t.pop_back();    
    }

    return s.size()+t.size();    
}

void test(){
    cin>>t;
    int ans=solve(s,t);
    swap(s,t);
    ans=max(ans,solve(s,t));
    swap(s,t);

    cout<<ans<<el;
}   

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    cin>>n>>t;
    cin>>s;

    while(t--){
        test();
    }

    return 0;
}