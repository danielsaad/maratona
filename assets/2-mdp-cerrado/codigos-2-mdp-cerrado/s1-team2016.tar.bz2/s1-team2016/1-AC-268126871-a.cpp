#include <bits/stdc++.h>
using namespace std;

#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define all(v) v.begin(), v.end()
using ll = long long;
using ld = long double;
template<class T> using vc = vector<T>;
template<class T> using vvc = vector<vc<T>>;

const char el ='\n';

const int MAX = 1e5 + 10;

ll a[MAX];
int dp[MAX];
int res[MAX];
vc<int> ev[MAX];

void test(){
    int n,c;
    cin >> n >> c;
    for(int i=1;i<=n;i++) cin >> a[i];
    for(int i=0;i<c; i++){
        int m,x;
        cin >>m >> x;
        ev[m].push_back(x);
    }
    vc<ll> st;
    ll p=0;
    for(int i=1; i<=n;i++){
        ll pant = p;
        while(!ev[i].empty()) p += ev[i].back(), ev[i].pop_back();
        while(!st.empty() && st.back()+p <= a[i]+p-pant) st.pop_back();
        res[i] = dp[i-1];
        st.emplace_back(a[i]-pant);
        dp[i] = st.size();
    }
    // for(int i=1;i<=n;i++) cout<< dp[i]<< ' ' <<res[i]<<el;
    for(int i=2;i<=n; i++) cout<< res[i] << el;
}

int32_t main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t=1;
    // cin>>t;
    while(t--){
        test();
    }

    return 0;
}