#include <bits/stdc++.h>
using namespace std;

#define ll long long 

int bb(vector<int> &vetor, int val){

    int left = 0, right = vetor.size()-1, ans = 0;

    while(left < right){
        int mid = left + (right - left + 1)/2;
        // cout << left << " " << mid << " " << right << endl;
        if(vetor[mid] > val) left = ans = mid;
        else right = mid - 1;
    }

    return ans;
}

signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);


    int n, q; cin >> n >> q;
    vector<int> vetor(n);
    for(auto &x: vetor)cin >> x;

    map<int,int> mp;
    for(int i = 0;i < q;i++){
        int a,b; cin >> a >> b;
        mp[a-1] += b;
    }

    int cont = -mp[0];
    vector<int> v = {(int)1e18,vetor[0]};

    for(int i = 1;i < n;i++){
        int val = vetor[i] + cont;
        int idc = bb(v, val);        
        
        cout << v.size()-1 << endl;

        v.resize(idc+1);
        v.push_back(val);

        cont -= mp[i];
    }       

}