#include <bits/stdc++.h>
using namespace std;

#define int long long 

const int N = 1e7 + 10;
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);
    
    int n; cin >> n;
    vector<int> vetor(n);
    for(auto &x: vetor) cin >> x;

    vector<int> pr(N, 1);

    for(int i = 2;i < N;i++){

        if(pr[i] == 1){
            pr[i] = i;
            for(int j = i*i; j < N; j += i){
                pr[j] = i;
            }
        }
    }

    priority_queue<int> pq;
    unordered_map<int,int>mp;
    for(auto x: vetor){ 

        while(x > 1){
            mp[pr[x]]++;
            x /= pr[x];
        }
    }
    for(auto [x,y]: mp) pq.push(x*y);

    int  ans = 0;
    while(!pq.empty()){
        ans += pq.top();
        pq.pop();
        if(!pq.empty()) pq.pop();
    }

    cout << ans << "\n";
}

