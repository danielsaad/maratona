#include <bits/stdc++.h>
using namespace std;

#define ll long long 
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    int n;
    cin >> n;
    string s; cin >> s;
    int ans = 1;
    for(int i = 1; i < n; i++) {
        if((s[i] == 'E' && s[i-1] == 'D') || (s[i] == 'D' && s[i-1] == 'E')) {
            continue;
        }
        ans++;
    }
    cout << ans << "\n";
}