#include <bits/stdc++.h>
using namespace std;

#define ll long long 
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    string c, f;
    cin >> f >> c;

    string tmp = {c[3], c[4]};
    string ftmp = {f[3], f[4]};

    int mins = stoi(ftmp) - stoi(tmp);
    tmp = {c[0], c[1]};
    ftmp = {f[0], f[1]};
    int hrs = stoi(ftmp) - stoi(tmp);
    if(mins < 0) {
        // cout << "aq\n";
        hrs--;
        mins += 60;
    }
    if(hrs < 10) {
        cout << "0" << hrs << ":";
    }
    else {
        cout << hrs << ":";
    }
    if(mins < 10) {
        cout << "0" << mins << "\n";
    }
    else {
        cout << mins << "\n";
    }
    // cout << hrs << ":" << mins << "\n";
}