#include <bits/stdc++.h>
using namespace std;

#define ll long long 
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    int n;
    cin >> n;
    string s; cin >> s;
    int ans = 1;
    char t = s[0];
    for(int i = 1; i < n; i++) {
        if(t == 'C') {
            t = s[i];
            ans++;
            continue;
        }
        if((s[i] == 'E' && t == 'D') || (s[i] == 'D' && t == 'E')) {
            t = 'C';
            continue;
        }
        
        ans++;
    }
    cout << ans << "\n";
}