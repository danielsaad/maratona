#include <bits/stdc++.h>
using namespace std;

#define ll long long 

signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    string s;
    cin  >> s;
    
    while(m--) {
        string a;
        cin >> a;

        int mai = s.size();
        mai = max(mai, (int)a.size());

        for(int i = 0; i < (int)a.size(); i++) {
            if(a[i] != s[0]) {
                mai = max(mai, (int)a.size() - i + (int)s.size());
                break;
            }
        }

        for(int i = 0; i < s.size(); i++) {
            if(s[i] != a[0]) {
                mai = max(mai, (int)s.size() - i + (int)a.size());
                break;
            }
        }
        cout << mai << "\n";
    }
    
}