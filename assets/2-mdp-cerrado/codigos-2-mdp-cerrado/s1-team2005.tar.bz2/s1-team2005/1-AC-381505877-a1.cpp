#include <bits/stdc++.h>
using namespace std;

#define ll long long 
#define int long long 

int bb(vector<int> &vetor, int val, int final){

    int left = 0, right = final-1, ans = 0;

    while(left < right){

        int mid = left + (right - left + 1)/2;
        if(vetor[mid] > val) left = ans = mid;
        else right = mid - 1;
    }

    return ans;
}

signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);


    int n, q; cin >> n >> q;
    vector<int> vetor(n);
    for(auto &x: vetor)cin >> x;

    map<int,int> mp;
    for(int i = 0;i < q;i++){
        int a,b; cin >> a >> b;
        mp[a-1] += b;
    }

    int cont = -mp[0];
    vector<int> v(5e5);
    v[0] = 1e17;
    v[1] = vetor[0];

    int idc = 2;
    for(int i = 1;i < n;i++){
        int val = vetor[i] + cont;
        cout << idc-1 << endl;
        idc = bb(v, val, idc);
        v[++idc] = val;
        idc++;

        cont -= mp[i];
    }       

}