#include <bits/stdc++.h>
using namespace std;

#define ll long long 
#define lef(x) (x<<1)
#define rig(x) (lef(x)|1)

int NEUTRO = 1e9;

int const N = 3e5 + 10;
int n, m;

int v[N];
int seg[N<<2], lazy[N<<2], segm[N<<2];
map<int, int> tempo;


void build(int node, int l, int r){
    if(l == r){
        seg[node] = v[l];
        segm[node] = v[l];
        return;
    }
    int m = (l + r) >> 1;

    build(lef(node), l, m); build(rig(node), m + 1, r);
    seg[node] = min(seg[lef(node)], seg[rig(node)]);
    segm[node] = max(segm[lef(node)], segm[rig(node)]);
}

void push(int node){
    if(!lazy[node]) return;

    // seg[node] = lazy[node];

    seg[lef(node)] += lazy[node];
    seg[rig(node)] += lazy[node];
    lazy[lef(node)] += lazy[node];
    lazy[rig(node)] += lazy[node];
    lazy[node] = 0;
}


int query(int node, int l, int r, int i, int j, int opr){
    if(l > j || r < i) {
        if(opr == 0) return NEUTRO;
        else return 0;
    }
    push(node);

    if(i <= l && r <= j) {
        // cout << seg[node] << ' ' << i << ' ' << j << endl;   
        if(opr == 0) return seg[node];
        else return segm[node];
    }
    int m = (l + r) >> 1;

    if(opr == 0) return min(query(lef(node), l, m, i, j, opr), query(rig(node), m + 1, r, i, j, opr));
    else return max(query(lef(node), l, m, i, j, opr), query(rig(node), m + 1, r, i, j, opr));
}

void update(int node, int l, int r, int i, int j, int x){
    if(l > j || r < i) {
        return;
    }
    
    push(node);
    if(i <= l && r <= j) {
        // if(x == 81) cout << "oi" <<i << ' ' << j << endl;
        lazy[node] += x;
        seg[node] += x;
        segm[node] += x;
        return;
    }

    int m = (l + r) >> 1;

    update(lef(node), l, m, i, j, x); 
    update(rig(node), m + 1, r, i, j, x);

    seg[node] = min(seg[lef(node)], seg[rig(node)]);
    segm[node] = max(segm[lef(node)], segm[rig(node)]);
}

// sinal[node] = 1;

signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    cin >> n >> m;

    for(int i = 1; i <= n; i++){
        cin >> v[i];
    }
    
    build(1, 1, n);
    for(int i = 0; i < m; i++){
        int a, b; cin >> a >> b;
        tempo[a] = b;
    }
    
    for(int i = 2; i <= n; i++){
        if(tempo[i - 1] != 0){
            update(1, 1, n, 1, i - 1, tempo[i - 1]);
        }
        // cout << endl;
        if(i == 2){
            cout << 1 << '\n';
            continue;
        }
        int l = 1, r = i - 2, ans = -1;
        int x =  query(1, 1, n, i - 1, i - 1, 0);
        // cout << x << '\n';

        while(l <= r){
            int m = (l + r) >> 1;
            int consulta = query(1, 1, n, m, i - 2, 0);
            if(i == n - 1){
                // cout << l << ' ' << r << ' ' << m << "  " << consulta << endl;
                
            }

            if(consulta <= x){
                l = m + 1;
            }else{
                // checar maximo
                if(query(1, 1, n, m + 1, i - 1, 1) < query(1, 1, n, m, m, 0)){
                    ans = m;
                    r = m - 1;
                }else{
                    l = m + 1;
                }
            }
        }

        if(ans == -1){
            cout << 1 << endl;
            continue;
        }
        cout << i - ans << endl;
    }
}