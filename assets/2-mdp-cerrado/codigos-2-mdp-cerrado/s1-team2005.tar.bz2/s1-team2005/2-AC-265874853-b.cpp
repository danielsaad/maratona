#include <bits/stdc++.h>
using namespace std;

#define ll long long 
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    int n; cin >> n;
    if(n == 45)cout << "Ambos\n";
    else if(n < 45)cout << "Costa\n";
    else cout << "Saad\n";
}