#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

const int MAXN = 1e7+2;
int spf[MAXN];
vector<int> primos;

void crivo() {
    for (int i = 0; i < MAXN; i++) spf[i] = i;
    for (int i = 2; i * i < MAXN; i++) {
        if (spf[i] == i) {
            for (int j = i * i; j < MAXN; j += i) {
                if (spf[j] == j) {
                    spf[j] = i;
                }
            }
        }
    }
    for (int i = 2; i < MAXN; i++) {
        if (spf[i] == i) {
            primos.push_back(i);
        }
    }
} 

map<int, int> fatora(int n) {
    map<int, int> fatores;
    while (n > 1) {
        fatores[spf[n]]++;
        n /= spf[n];
    }
    return fatores;
}

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    crivo();
    while (tt--)[&] {
        int n;
        cin >> n;
        vector<int> a(n);
        for (int & x : a) cin >> x;
        map<int, int> glob;
        for (int x : a) {
            map<int, int> F = fatora(x);
            for (auto & [p, expo] : F) {
                glob[p] += expo;
            }
        }
        vector<int> v;
        for (auto & [x, y] : glob) {
            v.push_back(x * y);
        }
        sort(all(v));
        int vez = 1;
        int ans = 0;
        while (v.size()) {
            int x = v.back();
            v.pop_back();
            if (vez) {
                ans += x;
            } 
            vez ^= 1;
        }
        cout << ans << '\n';
    }();
}   