#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

void solve(){
    string a, b;
    cin >> a >> b;

    int A = ((a[0]-'0')*10 + (a[1]-'0'))*60 + (a[3]-'0')*10 + (a[4]-'0');
    int B = ((b[0]-'0')*10 + (b[1]-'0'))*60 + (b[3]-'0')*10 + (b[4]-'0');

    int r = A-B;

    int h = r/60;
    int m = r%60;

    if (h < 10) cout << "0" << h;
    else cout << h;

    cout << ":";

    if (m < 10) cout << 0 << m;
    else cout << m;

    cout << endl;
}

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        solve();
    }();
}   