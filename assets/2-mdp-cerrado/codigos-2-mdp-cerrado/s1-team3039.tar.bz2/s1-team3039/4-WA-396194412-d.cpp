#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

mt19937 rng(time(nullptr));

struct Hash {
    const int X = rng();
    const int MOD = 1e9 + 7;
    int n; string s;
    vector<int>h,hi, p;
    Hash() {}
    Hash(string s) : s(s), n(s.size()), h(n), hi(n), p(n) {
        for (int i = 0; i < n; i++) p[i] = (i ? X * p[i - 1] : 1) % MOD;
        for (int i = 0; i < n; i++) {
            h[i] = (s[i] + (i ? h[i - 1] : 0) * X) % MOD;
        }
        for (int i = n - 1; i >= 0; i--) {
            hi[i] = (s[i] + (i + 1 < n ? hi[i + 1] : 0) * X) % MOD;
        }
    };
    int query(int l, int r) {
        int hash = (h[r] - (l ? h[l - 1] * p[r - l + 1] : 0)) % MOD;
        return hash < 0 ? hash + MOD : hash;
    }
    int query_inv(int l, int r) {
        int hash = (hi[l] - (r + 1 < n ? hi[r + 1] * p[r - l + 1] % MOD : 0));
        return hash < 0 ? hash + MOD : hash;
    }
};

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        int n, m;
        cin >> n >> m;

        string s; cin >> s;

        while (m--){
            string t; cin >> t;
            int sz = t.size();

            int mcp = 0;

            for (int i=0; i<min(n, sz); i++){
                if (s[i] == t[i]) mcp++;
                else break;
            }

            cout << n+sz-mcp << endl;
        }
    }();
}   