#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

template<typename T>
struct SegTree {
    int n;
    vector<T> tree;
    T neutral_value = -1e9;
    T combine(T a, T b) {
        return max(a, b);
    }
    SegTree(const vector<T> &data) {
        n = data.size();
        tree.resize(2 * n, neutral_value);
        for (int i = 0; i < n; i++) {
            tree[n + i] = data[i];
        }
        for (int i = n - 1; i > 0; --i) {
            tree[i] = combine(tree[i * 2], tree[i * 2 + 1]);
        }
    }
    T query(int l, int r) {
        T res_l = neutral_value, res_r = neutral_value;
        for (l += n, r += n + 1; l < r; l >>= 1, r >>= 1) {
            if (l & 1) res_l = combine(res_l, tree[l++]);
            if (r & 1) res_r = combine(tree[--r], res_r);
        }
        return combine(res_l, res_r);
    }
    void update(int pos, T new_val) {
        tree[pos += n] = new_val;
        for (pos >>= 1; pos > 0; pos >>= 1) {
            tree[pos] = combine(tree[2 * pos], tree[2 * pos + 1]);
        }
    }
};

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        int n, m;
        cin >> n >> m;
        vector<int> a(n), d(n+5,0);
        for (int & x : a) cin >> x;

        while (m--) {
            int pos, val;
            cin >> pos >> val;
            
            d[0] += val;
            d[pos] -= val;
        }

        for (int i=1; i<=n; i++){
            d[i] += d[i-1];
        }

        for (int i=0; i<n; i++){
            a[i] += d[i];
        }
        // cout << "v = ";
        // for (int x : a) cout << x << ' ';
        // cout << '\n';

        vector<int> p;
        
        for (int i=1; i<n; i++){
            while (!p.empty() && p.back() <= a[i-1]) p.pop_back();
            p.push_back(a[i-1]);

            cout << p.size() << endl;
        }

        // vector<int> vals = a;
        // sort(all(vals));
        // auto id = [&](int x) -> int {
        //     return lower_bound(all(vals), x) - begin(vals);
        // };
        // for (int &x : a) x = id(x);
        // cout << "comprimido = ";
        // for (int x : a) cout << x << ' ';
        // cout << '\n';
        
        // int k = vals.size();
        // vector<int> v(k, 0ll);
        // SegTree<int> seg(v);
        // vector<int> dp(n, 1ll);
        // auto rec = [&](auto && rec, int i) -> int {
        //     int ans = 1;
        //     for (int j = i - 1; j >= 0; j--) {
        //         if (a[j] > a[i]) {
        //             ans = max(ans, rec(rec, j) + 1);
        //         }
        //     }
        //     return ans;
        // };
        // for (int i = 1; i < n; i++) {
        //     cout << rec(rec, i - 1) << '\n';
        // }
        // cout << '\n';


    }();
}   