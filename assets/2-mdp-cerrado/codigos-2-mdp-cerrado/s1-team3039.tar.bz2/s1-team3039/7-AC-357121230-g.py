lista = []

try:
    while True:
        a = input()
        lista.append(a.strip())
except:
    exit


for a in lista:
    b = a
    a = a.split()
    if a[-1] == 'input()':
        print(f"LEIA {a[0]}", end=' ') 
    elif a[0] == 'while':
        cond = ' '.join(a[1:])
        print(f"ENQUANTO {cond[:-1]}", end=' ')
    elif a[0] == 'if':
        cond = ' '.join(a[1:])
        print(f"SE {cond[:-1]} ENTAO", end=' ')
    else:
        res = b[6:-1]
        print(f'APRESENTE {res}', end=' ')

print()