#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        int n, m;
        cin >> n >> m;
        vector<int> a(n);
        for (int & x : a) cin >> x;
        while (m--) {
            int pos, val;
            cin >> pos >> val;
            --pos;
            a[pos] += val;
        }
        int cur = 1;
        for (int i = 1; i < n; i++) {
            cout << cur << '\n';
            if (a[i] < a[i - 1]) {
                cur++;
            } else {
                cur = 1;
            }
        }
    }();
}   