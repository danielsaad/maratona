#include <bits/stdc++.h>
using namespace std;

#define int long long
#define double long double
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        int n;
        cin >> n;
        double N = ((double)acos(-1) / 180.0) * n;
        double S = sin(N);
        double C = cos(N);
        if (n == 45) {
            cout << "Ambos\n";
            return;
        }
        if (S > C) {
            cout << "Saad\n";
        } else if (C > S) {
            cout << "Costa\n";
        } else {
            cout << "Ambos\n";
        }
    }();
}   