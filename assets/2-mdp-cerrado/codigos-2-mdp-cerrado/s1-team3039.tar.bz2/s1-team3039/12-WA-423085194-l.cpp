#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

signed main(){
    // cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        int n;
        cin >> n;
        int id = 1;
        auto ask = [&](int x) -> int {
            cout << "? " << x << endl;
            int val;
            cin >> val;
            return val;
        };
        while (true) {
            int L = ask(id * 2);
            if (L == 1) {
                id = id * 2;
                continue;
            } 
            int R = ask(id * 2 + 1);
            if (R == 1) {
                id = id * 2 + 1;
                continue;
            }
            cout << "! " << id << endl;
            break;
        }
    }();
}   