#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(x) (int)x.size()

signed main(){
    cin.tie(0)->sync_with_stdio(0);
    int tt = 1;
    // cin >> tt;
    while (tt--)[&] {
        int n;
        cin >> n;
        string s;
        cin >> s;
        int ans = 0;
        for (int i = 0; i < n; i++) {
            if (i < n - 1) {
                string sub = s.substr(i, 2);
                if (sub == "ED" || sub == "DE") {
                    i++;
                    ans++;
                    continue;
                }
            } 
            ans++;
        }
        cout << ans << '\n';
    }();
}   