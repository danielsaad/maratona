#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef pair<ll, ll> pll;

int main(){
    int predios, construcao;
    cin >> predios;
    cin >> construcao;

    int cidade[predios+2];
    for (int i = 1; i<=predios; i++){
        int valor;
        cin >> valor;
        cidade[i] = valor;
    }

    for (int i= 0;i<construcao;i++){
        int endereco, andar;
        cin >> endereco;
        cin >> andar;
        cidade[endereco] = cidade[endereco] + andar;
    }

    int contador = 1, maior= 0;

    for(int i = 2; i<=predios; i++){
        maior = cidade[i-1];
        for(int j = i; j> 0; j--){
            if(cidade[j]>maior){
                contador++;
                maior = cidade[j];
            }
        }
        cout << contador << "\n";
        contador = 1;
        // cout << "predio: " << i << " | Andar: " << cidade[i] << "\n";
    }

    return 0;
}
