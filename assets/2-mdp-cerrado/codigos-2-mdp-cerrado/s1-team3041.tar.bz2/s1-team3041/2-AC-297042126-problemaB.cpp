#include <bits/stdc++.h>
using namespace std;

int main(){
    float num;    
    cin >> num;
    float radian = (num*M_PI)/180;
    float seno = sin(radian);
    float coss = cos(radian);

    
    // cout << num << "| seno: " << seno << " | cos:" << coss << "\n";
    if (seno < coss) printf("Costa\n");
    else if (seno == coss) printf("Ambos\n");
    else printf("Saad\n");
    return 0;
}
