#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef pair<ll, ll> pll;

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int num;    
    cin >> num;
    double seno = sin(num);
    double coss = cos(num);
    if (seno < coss) printf("Costa\n");
    else if (seno == coss) printf("Ambos\n");
    else printf("Saad\n");
    return 0;
}
