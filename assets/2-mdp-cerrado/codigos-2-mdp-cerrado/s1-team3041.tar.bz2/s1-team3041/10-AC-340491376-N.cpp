#include <bits/stdc++.h>
using namespace std;


int main(){
    int fim;
    cin >> fim;
    int contador = 1;
    char antigo;
    char atual;
    cin >> antigo;
    for(int i = 1; i<fim; i++){
        cin >> atual;
        if(antigo == 'E' && atual == 'D'){
            antigo = 'C';
            continue;
        }
        if(antigo == 'D' && atual == 'E'){
            antigo = 'C';
            continue;
        }
        antigo = atual;
        contador++;
    }
    
    cout << contador << "\n";

    return 0;
}
