h1, m1 = map(int, input().split(':'))
h2, m2 = map(int, input().split(':'))

temp1 = h1*60 + m1
temp2 = h2*60 + m2

if (temp1 < temp2):
    result = temp2 - temp1

else:
    result = (1440 - temp1)+temp2   

hora = result//60 
minuto = result%60

result_hora = f'{result//60}'
result_min = f'{result%60}'
if(hora < 10 ):
    result_hora = f'0{result//60}'
if ((result%60 < 10)):
    result_min = f'0{result%60}'

print(f'{result_hora}:{result_min}')