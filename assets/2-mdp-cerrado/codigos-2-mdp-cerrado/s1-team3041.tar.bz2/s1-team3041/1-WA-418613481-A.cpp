#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef pair<ll, ll> pll;

int main(){
    int predios, construcao;
    cin >> predios;
    cin >> construcao;

    int cidade[predios+2];
    for (int i = 1; i<=predios; i++){
        int valor;
        cin >> valor;
        cidade[i] = valor;
    }

    for (int i= 0;i<construcao;i++){
        int endereco, andar;
        cin >> endereco;
        cin >> andar;
        cidade[endereco] = cidade[endereco] + andar;
    }

    int contador = 0, anterior= 0, maior = 0, menor = 0;

    for(int i = 2; i<=predios; i++){
        anterior = cidade[i-1];
        int atual = cidade[i];

        if(anterior <= atual){
            menor = anterior;
            // cout << "Estamos em " << atual << " do esquerda é MENOR: " << anterior << "\n"; 
            contador++;
            for (int j = i-1; j> 0; j--){
                if(cidade[j] < menor){
                    // cout << "Estamos em " << atual << " do esquerda é MENOR: " << anterior << "\n";
                    contador++;  
                    menor = cidade[j];
                }
            }

            maior = anterior;
            // cout << "Estamos em " << atual << " do esquerda é MAIOR :" << anterior << "\n"; 
            // contador++;
            for(int j = i-1; j> 0; j--){
                if(cidade[j]>maior){
                    // cout << "Estamos em " << maior << " do esquerda é MAIOR :" << cidade[j] << "\n"; 
                    contador++;
                    maior = cidade[j];
                }
            }
        }
        if(anterior > atual){
            maior = anterior;
            // cout << "Estamos em " << atual << " do esquerda é MAIOR :" << anterior << "\n"; 
            contador++;
            for(int j = i-1; j> 0; j--){
                if(cidade[j]>maior){
                    // cout << "Estamos em " << maior << " do esquerda é MAIOR :" << cidade[j] << "\n"; 
                    contador++;
                    maior = cidade[j];
                }
            }
        } 
        cout << contador << "\n";
        contador = 0;
    }

    return 0;
}
