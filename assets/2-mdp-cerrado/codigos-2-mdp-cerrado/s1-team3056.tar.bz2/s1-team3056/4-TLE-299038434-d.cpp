#include <bits/stdc++.h>
using namespace std;

#define int long long

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int N, M;
	cin >> N >> M;

	string S;
	cin >> S;

	for (int i = 0; i < M; i++) {
		string T;
		cin >> T;
	
		int first_diff = -1;
		for (int i = 0; i < T.size(); i++) {
			if (T[i] != T.front()) {
				first_diff = i;
				break;
			}
		}

		int ans = max(S.size(), T.size());
		for (int j = 0; j < S.size(); j++) {
			int here = S.size()-j;
			if (S[j] != T.front()) {
				here += T.size();
			} else {
				if (first_diff != -1) {
					here += T.size()-first_diff;
				} else {
					here += 0;
				}
			}
			ans = max(ans, here);
		}
		cout << ans << '\n';
	}
}
