#include <bits/stdc++.h>
using namespace std;

#define int long long
using ll = long long;

const int MAX = 4e5;

namespace lct {
	struct node {
		int p, ch[2];
		ll val, sub;
		bool rev;
		int sz, ar;
		ll lazy;
		node() {}
		node(int v, int ar_) :
			p(-1), val(v), sub(v), rev(0), sz(ar_), ar(ar_), lazy(0) {
			ch[0] = ch[1] = -1;
		}	
	};

	node t[2*MAX]; // MAXN + MAXQ
	map<pair<int, int>, int> aresta;
	int sz;

	void prop(int x) {
		if (t[x].lazy) {
			if (t[x].ar) t[x].val += t[x].lazy;
			t[x].sub += t[x].lazy * t[x].sz;
			if (t[x].ch[0]+1) t[t[x].ch[0]].lazy += t[x].lazy;
			if (t[x].ch[1]+1) t[t[x].ch[1]].lazy += t[x].lazy;
		}
		if (t[x].rev) {
			swap(t[x].ch[0], t[x].ch[1]);
			if (t[x].ch[0]+1) t[t[x].ch[0]].rev ^= 1;
			if (t[x].ch[1]+1) t[t[x].ch[1]].rev ^= 1;
		}
		t[x].lazy = 0, t[x].rev = 0;
	}
	void update(int x) {
		t[x].sz = t[x].ar, t[x].sub = t[x].val;
		for (int i = 0; i < 2; i++) if (t[x].ch[i]+1) {
			prop(t[x].ch[i]);
			t[x].sz += t[t[x].ch[i]].sz;
			t[x].sub += t[t[x].ch[i]].sub;
		}
	}
	bool is_root(int x) {
		return t[x].p == -1 or (t[t[x].p].ch[0] != x and t[t[x].p].ch[1] != x);
	}

	void rotate(int x) {
		int p = t[x].p, pp = t[p].p;
		if (!is_root(p)) t[pp].ch[t[pp].ch[1] == p] = x;
		bool d = t[p].ch[0] == x;
		t[p].ch[!d] = t[x].ch[d], t[x].ch[d] = p;
		if (t[p].ch[!d]+1) t[t[p].ch[!d]].p = p;
		t[x].p = pp, t[p].p = x;
		update(p), update(x);
	}

	int splay(int x) {
		while (!is_root(x)) {
			int p = t[x].p, pp = t[p].p;
			if (!is_root(p)) prop(pp);
			prop(p), prop(x);
			if (!is_root(p)) rotate((t[pp].ch[0] == p)^(t[p].ch[0] == x) ? x : p);
			rotate(x);
		}
		return prop(x), x;
	}
	int access(int v) {
		int last = -1;
		for (int w = v; w+1; update(last=w), splay(v), w=t[v].p)
			splay(w), t[w].ch[1] = (last == -1 ? -1 : v);
		return last;
	}

	void make_tree(int v, int w=0, int ar=0) { t[v] = node(w, ar); }

	int find_root(int v) {
		access(v), prop(v);
		while (t[v].ch[0]+1) v = t[v].ch[0], prop(v);
		return splay(v);
	}

	bool conn(int v, int w) {
		access(v), access(w);
		return v == w ? true : t[v].p != -1;
	}

	void rootify(int v) {
		access(v);
		t[v].rev ^= 1;
	}

	ll query(int v, int w) {
		rootify(w), access(v);
		return t[v].sub;
	}

	void link_(int v, int w) {
		rootify(w);
		t[w].p = v;
	}
	void link(int v, int w, int x) {
		int id = MAX + sz++;
		aresta[make_pair(v, w)] = id;
		make_tree(id, x, 1);
		link_(v, id), link_(id, w);
	}

	void cut_(int v, int w) {
		rootify(w), access(v);
		t[v].ch[0] = t[t[v].ch[0]].p = -1;
	}
	void cut(int v, int w) {
		int id = aresta[make_pair(v, w)];
		cut_(v, id), cut_(id, w);
	}
};

struct DSU {
	vector<pair<int&, int>> hist;
	vector<int> P, S;
	vector<pair<int, int>> dia;
	DSU (int N) : P(N, -1), S(N, 1), dia(N) {
		for (int i = 0; i < N; i++) {
			dia[i] = {i, i};
		}
	}

	int find(int v) {
		if (P[v] == -1) return v;
		return find(P[v]);
	}

	int join(int v, int u) {
		v = find(v);
		u = find(u);
		if (u == v) return v;
		if (S[v] < S[u]) swap(v, u);
		hist.push_back(pair<int&, int>(P[u], P[u]));
		P[u] = v;
		hist.push_back(pair<int&, int>(S[v], S[v]));
		S[v] += S[u];
		return v;
	}

	void set_dia(int v, int a, int b) {
		v = find(v);
		hist.push_back(pair<int&, int>{dia[v].first, dia[v].first});
		hist.push_back(pair<int&, int>{dia[v].second, dia[v].second});
		dia[v] = {a, b};
	}

	void rollback(int sz) {
		while (hist.size() > sz) {
			auto [addr, val] = hist.back();
			hist.pop_back();
			addr = val;
		}
	}
};

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int N, M, Q;
	cin >> N >> M >> Q;

	map<pair<int, int>, int> born, len;

	int TIME = 0;
	for (int i = 0; i < M; i++) {
		int v, u, w;
		cin >> v >> u >> w;
		v--, u--;
		if (v > u) swap(v, u);

		born[{v, u}] = TIME;
		len[{v, u}] = w;
	}

	// born, die, v, u, w
	vector<array<int, 5>> edges;

	for (int i = 0; i < Q; i++) {
		TIME++;

		int op;
		cin >> op;
	
		if (op == 1) {
			int v, u, w;
			cin >> v >> u >> w;
			v--, u--;
			if (v > u) swap(v, u);

			born[{v, u}] = TIME;
			len[{v, u}] = w;
		} else {
			int v, u;
			cin >> v >> u;
			v--, u--;
			if (v > u) swap(v, u);

			edges.push_back({born[{v, u}], TIME-1, v, u, len[{v, u}]});
			born.erase({v, u});
		}
	}
	TIME++;

	for (auto [ed, bornt] : born) {
		auto [v, u] = ed;
		edges.push_back({born[{v, u}], TIME-1, v, u, len[{v, u}]});
	}

	//cout << "Finished creating edges" << endl;

	// {v, u, w}
	vector<vector<array<int, 3>>> T(4*TIME);	
	auto insert = [&](auto &&F, int l, int r, int v, int u, int w, int id, int il, int ir) -> void{
		if (ir < l or r < il) return;
		if (l <= il && ir <= r) {
			T[id].push_back({v, u, w});
			return;
		}

		int im = (il + ir)/2;
		F(F, l, r, v, u, w, 2*id, il, im);
		F(F, l, r, v, u, w, 2*id+1, im+1, ir);
	};

	for (auto [l, r, v, u, w] : edges) {
		insert(insert, l, r, v, u, w, 1, 0, TIME-1);
	}

	//cout << "Finished inserting edges" << endl;

	DSU D(N);
	vector<int> ans(TIME);
	int cur_ans = 0;

	for (int i = 0; i < N; i++) {
		lct::make_tree(i);
	}

	auto dfs = [&](auto &&F, int id, int il, int ir) -> void {
		//cout << "DFS " << id << ' ' << il << ' ' << ir << endl;

		// juntar os caras
		// 	link cut tree
		// 	arrumar o diametro, etc

		int initial = cur_ans;
		int checkpoint = D.hist.size();


		for (auto [v, u, w] : T[id]) {
			//cout << "Adding edge: " << v << u << w << endl;
			//cout << "ans_now: " << cur_ans << endl;
			// arrumar o diametro
			auto cur_dia_v = D.dia[D.find(v)];
			auto cur_dia_u = D.dia[D.find(u)];

			//cout << "got dia_v: " << cur_dia_v.first << ' ' << cur_dia_v.second << ' ' << lct::query(cur_dia_v.first, cur_dia_v.second) << endl;
			//cout << "got dia_u: " << cur_dia_u.first << ' ' << cur_dia_u.second << ' ' << lct::query(cur_dia_u.first, cur_dia_u.second) << endl;

			cur_ans -= lct::query(cur_dia_v.first, cur_dia_v.second);
			cur_ans -= lct::query(cur_dia_u.first, cur_dia_u.second);

			//cout << "OI1" << endl;

			lct::link(v, u, w);
			int leader = D.join(v, u);
			//cout << "OI2" << endl;

			// calcula novo diametro
			//  add na resposta
			//  update na DSU
			array<int, 3> best{-1, -1, -1};
			vector<int> opts{cur_dia_v.first, cur_dia_v.second, cur_dia_u.first, cur_dia_u.second};
			for (int i = 0; i < opts.size(); i++) {
				for (int j = i+1; j < opts.size(); j++) {
					best = max(best, {lct::query(opts[i], opts[j]), opts[i], opts[j]});
				}
			}
			//cout << "OI3" << endl;
			//cout << "Setting diameter of " << leader << " to " << best[1] << ' ' << best[2] << " len: "  << best[0] << endl;
			D.set_dia(leader, best[1], best[2]);
			cur_ans += best[0];

			//cout << "ans_after: " << cur_ans << endl;
		}
		//cout << "Finished adding edges" << endl;

		// checa se ta na folha
		// 	sim -> resposta
		if (il == ir) {
			//cout << il << ' ' << ir << endl;
			//cout << size(ans) << endl;
			ans[il] = cur_ans;
		} else {
		//  	nao -> recursao
			int im = (il+ir)/2;
			F(F, 2*id, il, im);
			F(F, 2*id+1, im+1, ir);
		}

		// desfaz tudo aqui
		// rollback + cut
		cur_ans = initial;
		D.rollback(checkpoint);
		for (auto [v, u, w] : T[id]) {
			lct::cut(v, u);
		}
	};
	dfs(dfs, 1, 0, TIME-1);
	
	for (auto x : ans) {
		cout << x << '\n';
	}
}
