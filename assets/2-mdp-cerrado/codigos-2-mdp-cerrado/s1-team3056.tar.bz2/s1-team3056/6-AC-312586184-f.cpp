#include <bits/stdc++.h>
using namespace std;

#define int long long

const int MOD = 998'244'353;

int fexp(int b, int e) {
	if (e == 0) return 1;
	int h = fexp(b, e/2);
	h = h * h % MOD;
	if (e % 2) h = h * b % MOD;
	return h;
}
int inv(int x) {
	return fexp(x, MOD-2);
}

using Matrix = array<array<int, 2>, 2>;
Matrix zero() {
	Matrix z;
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 2; j++)
			z[i][j] = 0;
	return z;
}
Matrix ident() {
	Matrix id;
	id[0][0] = id[1][1] = 1;
	id[0][1] = id[1][0] = 0;
	return id;
}
Matrix mult(Matrix a, Matrix b) {
	Matrix result = zero();
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			for (int k = 0; k < 2; k++) {
				result[i][j] += a[i][k] * b[k][j];
				result[i][j] %= MOD;
			}
		}
	}
	return result;
}
Matrix fexp(Matrix m, int e) {
	if (e == 0) return ident();
	Matrix h = fexp(m, e/2);
	h = mult(h, h);
	if (e % 2) h = mult(h, m);
	return h;
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int T;
	cin >> T;
	while (T--) {
		int a, b, n, m, vn, vm;
		cin >> a >> b >> n >> m >> vn >> vm;

		swap(a, b);

		Matrix base;
		base[0][0] = 0; base[0][1] = a;
		base[1][0] = 1; base[1][1] = b;

		Matrix en = fexp(base, n);
		Matrix em = fexp(base, m);

		int an = en[0][0], bn = en[1][0];
		int am = em[0][0], bm = em[1][0];

		/*
		cout << an << ' ' << bn << endl;
		cout << am << ' ' << bm << endl;
		*/

		int f0 = (vn*bm%MOD - vm*bn%MOD + MOD)%MOD;
		f0 *= inv((an*bm%MOD - am*bn%MOD + MOD)%MOD);
		f0 %= MOD;

		int f1 = (vn-an*f0%MOD+MOD)%MOD;
		f1 *= inv(bn);
		f1 %= MOD;

		cout << f0 << ' ' << f1 << '\n';
	}
}
