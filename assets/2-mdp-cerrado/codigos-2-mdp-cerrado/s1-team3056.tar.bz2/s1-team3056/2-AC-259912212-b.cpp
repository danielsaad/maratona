#include <bits/stdc++.h>
using namespace std;

#define int long long

const double PI = acos(-1);

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int N;
	cin >> N;

	if (N == 45) cout << "Ambos" << endl;
	else if (N > 45) cout << "Saad" << endl;
	else cout << "Costa" << endl;
}
