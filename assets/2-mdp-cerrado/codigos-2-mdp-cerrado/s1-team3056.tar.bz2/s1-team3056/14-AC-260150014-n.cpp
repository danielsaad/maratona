#include <bits/stdc++.h>
using namespace std;

#define int long long

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int hi, mi;
	int hf, mf;
	char c;

	cin >> hf >> c >> mf;
	cin >> hi >> c >> mi;

	int tf = hf*60 + mf;
	int ti = hi*60 + mi;

	int diff = tf-ti;
	if (diff < 0) diff += 24 * 60;

	int h = diff/60;
	int m = diff%60;

	if (h < 10) cout << 0;
	cout << h;
	cout << ":";
	if (m < 10) cout << 0;
	cout << m;
	cout << endl;
}
