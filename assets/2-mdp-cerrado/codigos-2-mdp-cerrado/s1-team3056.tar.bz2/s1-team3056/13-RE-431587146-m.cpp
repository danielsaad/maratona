#include <bits/stdc++.h>
using namespace std;

#define int long long

#define sz(s) (int)s.size()

struct LCA{
    int M = 1;
    vector<vector<int>> p;
    vector<int> d;
    LCA(vector<vector<int>> &g){
        const int N = sz(g);
        while((1 << M) <= N) M++;
        p.assign(M, vector<int>(N, -1));
        d.resize(N);
        d[0] = 0;
        dfs(g, 0);
        for(int i = 1; i < M; i++)
            for(int j = 0; j < N; j++)
                if(p[i - 1][j] != -1) p[i][j] = p[i - 1][p[i - 1][j]];
    }
    void dfs(vector<vector<int>> &g, int u){
        for(int v : g[u]){
            if(v != p[0][u]){
                p[0][v] = u;
                d[v] = d[u] + 1;
                dfs(g, v);
            }
        }
    }
    int query(int u, int v){
        if(d[u] > d[v]) swap(u, v);
        for(int i = M - 1; i >= 0; i--)
            if(p[i][v] != -1 && d[u] <= d[p[i][v]]) v = p[i][v];
        if(u == v) return u;
        for(int i = M - 1; i >= 0; i--)
            if(p[i][u] != -1 && p[i][u] != p[i][v])
                u = p[i][u], v = p[i][v];
        return p[0][u];
    }
};

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

    int N; cin >> N;
    vector<vector<int>> g(N);
    for(int i = 0; i < N - 1; i++){
        int u, v; cin >> u >> v;
        u--, v--;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    LCA lca(g);
    
    vector<int> comp(N);
    vector<int> p(N, -1);
    vector<int> d(N);

    vector<bool> is_tail(N);

    auto dfs = [&](int u, auto &&dfs) -> int{
        int ret = -1;
        for(int v : g[u]){
            if(v != p[u]){
                p[v] = u;
                d[v] = d[u] + 1;
                ret = max(ret, dfs(v, dfs));
            }
        }
        comp[u] = ret;
        ret = max(ret, u);
        is_tail[ret] = true;
        return ret;
    };

    dfs(0, dfs);

    vector<vector<int>> g_aux(N);
    vector<int> comp_head(N, -1);

    for(int i = 0; i < N; i++){
        if(comp[i] != -1){
            g_aux[comp[i]].push_back(i);
            if(comp_head[comp[i]] == -1 || d[comp_head[comp[i]]] > d[i])
                comp_head[comp[i]] = i;
        }
    }
    vector<bool> is_head(N);
    is_head[0] = true;
    for(int i = 1; i < N; i++)
        if(comp[i] != comp[p[i]]) is_head[i] = true;
    
    vector<vector<pair<int, int>>> link;
    int M = 1;
    while((1 << M) <= N) M++;
    link.assign(M, vector<pair<int, int>>(N, {-1, 0}));

    auto dfs2 = [&](int u, int head_link, auto &&dfs2) -> void{
        if(u && is_head[u]){
            link[0][u].first = head_link;
            if(is_tail[u]){
                link[0][u].second = 1;
            }else{
                link[0][u].second = d[u] - d[head_link];
                link[0][u].second = min(link[0][u].second, 2 + d[comp[head_link]] - d[p[u]]);  
            }
            head_link = u;
        }
        for(int v : g[u])
            if(v != p[u]) dfs2(v, head_link, dfs2);
    };

    dfs2(0, 0, dfs2);

    for(int i = 1; i < M; i++){
        for(int j = 0; j < N; j++){
            if(link[i - 1][j].first != -1 && link[i - 1][link[i - 1][j].first].first != -1){
                link[i][j].first = link[i - 1][link[i - 1][j].first].first;
                link[i][j].second = link[i - 1][j].second + link[i - 1][link[i - 1][j].first].second;
            }
        }
    }

    int Q; cin >> Q;
    while(Q--){
        int u, v; cin >> u >> v;
        u--, v--;
        
        int w = lca.query(u, v);
        int ans = d[u] - d[w];

        int aux = d[v] - d[w];
        if(is_tail[v]){
            if(comp[w] == v){
                aux = min(aux, 1LL);
            }else{
                int cost = 1;
                v = comp_head[v];

                for(int i = M - 1; i >= 0; i--){
                    if(link[i][v].first != - 1 && d[link[i][v].first] > d[w]){
                        cost += link[i][v].second;
                        v = link[i][v].first;
                    }
                }

                if(is_tail[v]) cost++;
                else{
                    int last = d[v] - d[w];
                    last = min(last, 2 + d[comp[w]] - d[p[v]]);
                    cost += last;
                }
                aux = min(aux, cost);
            }
        }else{
            if(comp[v] == comp[w]){
                aux = min(aux, 1 + d[comp[v]] - d[v]);
            }else{
                int cost = min(d[v] - d[comp_head[comp[v]]], 1 + d[comp[v]] - d[v]);
                v = comp_head[comp[v]];

                for(int i = M - 1; i >= 0; i--){
                    if(link[i][v].first != - 1 && d[link[i][v].first] > d[w]){
                        cost += link[i][v].second;
                        v = link[i][v].first;
                    }
                }

                if(is_tail[v]) cost++;
                else{
                    int last = d[v] - d[w];
                    last = min(last, 2 + d[comp[w]] - d[p[v]]);
                    cost += last;
                }
                aux = min(aux, cost);
            }
        }

        ans += aux;
        cout << ans << ' ';
    }

    cout << '\n';

    /*for (int i = 0; i < N; i++) {
        cout << i << ": " << link[0][i].first << ' ' << link[0][i].second << endl;
    }

    for (int i = 0; i < N; i++) {
        cout << i << ": " << link[1][i].first << ' ' << link[1][i].second << endl;
    }*/
}
