#include <bits/stdc++.h>
using namespace std;

#define int long long

const int MAX = 1e5+5;

vector<int> lz[MAX];

signed main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  int n, m; cin >> n >> m;

  int v[n];

  for(int i =0; i < n; i++){
    cin >> v[i];
  }

  for(int i =0; i < m; i++){
    int a,b; cin >> a >> b;
    a--;
    lz[a].push_back(b);
  }

  vector<int> pilha;

  int ans[n];
  int acc = 0;

  for(int i = 0; i < MAX; i++){
    if(i < n){
      v[i] -= acc;
      ans[i] = pilha.size();
      while(!pilha.empty()){
        if(pilha.back() <= v[i]){
          pilha.pop_back();
        }
        else{
          break;
        }
      }
      pilha.push_back(v[i]);
    }
    for(auto  x : lz[i]){
      acc += x;
    }
  }

  for(int i =1 ;i < n; i++){
    cout << ans[i] << '\n'; 
  }

}
