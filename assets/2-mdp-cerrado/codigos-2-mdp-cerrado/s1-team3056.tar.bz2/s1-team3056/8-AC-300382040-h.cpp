#include <bits/stdc++.h>
using namespace std;

#define int long long

#define sz(s) (int)s.size()

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

    int N; cin >> N;
    vector<int> a(N);
    for(int i = 0; i < 3; i++){
        int t; cin >> t;
        for(int j = 0; j < t; j++){
            int x; cin >> x;
            x--;
            a[x] = i;
        }
    }

    vector<pair<int, int>> ans;
    auto HANOI = [&](int n, int tgt, auto && HANOI) -> void{
        if(n == 0){
            if(a[n] != tgt)
                ans.push_back({a[n], tgt}), a[n] = tgt;
        }else{
            if(a[n] == tgt) HANOI(n - 1, tgt, HANOI);
            else{
                int aux = (3 - tgt - a[n]) % 3;
                HANOI(n - 1, aux, HANOI);
                ans.push_back({a[n], tgt}), a[n] = tgt;
                HANOI(n - 1, tgt, HANOI);
            }
        }
    };

    HANOI(N - 1, 1, HANOI);
    cout << sz(ans) << '\n';
    array<char, 3> c{'A', 'B', 'C'};
    for(auto [x, y] : ans) cout << c[x] << ' ' << c[y] << '\n';
}
