#include <bits/stdc++.h>
using namespace std;

#define int long long

const int MAX = 1e7+7;
vector<int> primos;

int ps[MAX];

void init(){
    for(int i = 2; i < MAX; i++){
        if(ps[i]) continue;
        primos.push_back(i);
        for(int j = i; j < MAX; j+=i){
            ps[j] = i;
        }
    }
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

    init();


    int n; cin >> n;

    vector<int> pontos;

    for(int i = 0; i < n; i++){
        int x; cin >> x;
        while(x > 1){
            pontos.push_back(ps[x]);
            x = x/ps[x];
        }
    }

    map<int,int> soma;
    for(auto x : pontos){
        soma[x] += x;
    }

    vector<int> respvdd;
    
    for(auto [a,b] : soma){
        respvdd.push_back(b);
    }

    sort(respvdd.begin(), respvdd.end());
    reverse(respvdd.begin(), respvdd.end());

    int ans = 0;

    for(int i =0; i < (int)respvdd.size(); i+= 2){
        ans += respvdd[i];
    }

    cout << ans << '\n';
}
