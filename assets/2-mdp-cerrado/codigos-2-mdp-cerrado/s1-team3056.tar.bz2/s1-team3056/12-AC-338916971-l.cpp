#include <bits/stdc++.h>
using namespace std;

#define int long long

#define sz(s) (int)s.size()

signed main() {
	//ios::sync_with_stdio(false);
	//cin.tie(nullptr);

    int N; cin >> N;
    vector<vector<int>> a(N + 2);
    
    int cnt = 1;
    for(int i = 0; i < N + 2; i++){
        a[i].resize(i + 1);
        for(int j = 0; j < i + 1; j++)
            a[i][j] = cnt++;
    }

    int L = 0, R = N + 1;
    int i = 0, j = 0;
    while(L + 2 <= R){
        int m = (L + R) / 2;
        int l = j, r = j + m - i;
        bool achei = false;
        for(int k = l; k <= r; k++){
            cout << "? " << a[m][k] << endl;
            int x; cin >> x;
            if(x){
                achei = true;
                i = m;
                j = k;
                break;
            }
        }
        if(achei) L = m;
        else R = m;
    }
    cout << "! " << a[i][j] << endl;
}
