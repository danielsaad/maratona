#include <bits/stdc++.h>
using namespace std;

#define int long long

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int N;
	cin >> N;

	string S;
	cin >> S;

	map<char, int> M;
	M['E'] = 0;
	M['C'] = 1;
	M['D'] = 2;

	vector DP(N, vector<int>(3, -1));
	for (int i = 0; i < 3; i++) {
		DP[0][i] = (M[S[0]] == i);
	}

	for (int i = 0; i+1 < N; i++) {
		for (int j = 0; j < 3; j++) {
			for (int nxt = 0; nxt < 3; nxt++) {
				if (abs(j-nxt) > 1) continue;
				DP[i+1][nxt] = max(DP[i+1][nxt], DP[i][j] + (M[S[i+1]] == nxt));
			}
		}
	}

	/*
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < 3; j++) {
			cout << DP[i][j] << ' ';
		}
		cout << endl;
	}
	*/

	cout << max({DP.back()[0], DP.back()[1], DP.back()[2]}) << endl;
}
