#include <bits/stdc++.h>
using namespace std;

#define int long long

vector<int> PI(string const& S) {
	vector<int> p(size(S));
	for (int i = 1; i < size(S); i++) {
		int g = p[i-1];
		while (g && S[i] != S[g]) g = p[g-1];
		p[i] = g + (S[i] == S[g]);
	}
	return p;
}

vector<int> match(string const& S, string const& pat) {
	auto p = PI(pat + '\0' + S);
	vector<int> res;
	for (int i = p.size()-S.size(); i < p.size(); i++) {
		if (p[i] == size(pat))
			res.push_back(i - 2*size(pat));
	}
	return res;
}

auto const INF = -2;

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	string S, T;
	cin >> S >> T;

	int N = size(S), M = size(T);
	vector<int> W(N);
	for (auto &x : W) cin >> x;

	while (S.size() < 2*T.size()) S += S;

	auto matches = match(S, T);
	vector<bool> ismatch(S.size());
	for (auto x : matches) ismatch[x] = true;

	vector<int> ans(N, -1);
	auto cnt = [&](auto &&F, int i, int steps) {
		i %= N;

		if (ans[i] != -1) return ans[i];
		if (steps > N) return ans[i] = INF;
		if (!ismatch[i]) return ans[i] = 0;
		
		auto nxt = F(F, i+T.size(), steps+1);
		if (nxt == INF) return ans[i] = INF;
		else return ans[i] = nxt + W[i];
	};

	for (int i = 0; i < N; i++) cnt(cnt, i, 0);

	for (auto x : ans) {
		if (x == INF) {
			cout << -1 << endl;
			exit(0);
		}
	}

	cout << *max_element(begin(ans), end(ans)) << endl;
}
