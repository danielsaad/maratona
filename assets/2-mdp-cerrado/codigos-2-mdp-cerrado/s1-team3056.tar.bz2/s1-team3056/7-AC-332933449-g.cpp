#include <bits/stdc++.h>
using namespace std;

#define int long long

int curs = 0;
int curi = 0;
vector<string> lines;

string ans;

void nxt() {
	curi++;
	if (curi == lines[curs].size()) curs++, curi = 0;
}

char here() {
	return lines[curs][curi];
}

bool done() {
	return curs == lines.size();
}

void parseEXP() {
	char op = here();
	if (op == '"' or op == '\'') {
		ans += here();
		nxt();
		while (here() != op) {
			ans += here();
			nxt();
		}
		ans += here();
	} else {
		while (!done() && here() != ':' && here() != ')') {
			ans += here();
			nxt();
		}
	}
}

void parsePRINT() {
	ans += "APRESENTE ";
	curi += 6;
	parseEXP();
}

void parseINPUT() {
	ans +="LEIA ";
	while (here() != ' ') {
		ans += here();
		nxt();
	}
}

void parseIO() {
	if (curi + 6 < lines[curs].size() && lines[curs].substr(curi, 6) == "print(") {
		parsePRINT();
	} else {
		parseINPUT();
	}
}

void parseIF() {
	ans += "SE ";
	curi += 3;
	parseEXP();
	ans += " ENTAO ";
	nxt();
	parseIO();
}

void parseWHILE() {
	ans += "ENQUANTO ";
	curi += 6;
	parseEXP();
	nxt();
	ans += " ";
	parseIO();
	nxt();
}

void parsePROGRAM() {
	if (lines[0].size() >= 3 && lines[0].substr(0, 3) == "if ") {
		parseIF();
	} else if (lines[0].size() >= 6 && lines[0].substr(0, 6) == "while ") {
		parseWHILE();
	} else {
		parseIO();
	}
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	string line;
	while (getline(cin, line)) {
		lines.push_back(line);
		auto &line = lines.back();
		while (line.front() == ' ' or line.front() == '\t') line = line.substr(1);
		while (line.back() == ' ' or line.back() == '\t' or line.back() == '\n') line.pop_back();
	}

	parsePROGRAM();
	cout << ans << endl;
}
