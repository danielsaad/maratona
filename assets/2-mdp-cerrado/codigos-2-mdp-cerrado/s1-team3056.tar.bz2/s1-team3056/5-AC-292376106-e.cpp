#include <bits/stdc++.h>
using namespace std;

#define ll long long

const int MAX = 1e7+7;

int ps[MAX];

void init(){
    for(ll i = 2; i < MAX; i++){
        if(ps[i]) continue;
        for(ll j = i * i; j < MAX; j+=i){
            ps[j] = i;
        }
        ps[i] = i;
    }
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

    init();


    int n; cin >> n;

    map<int,ll> soma;

    for(int i = 0; i < n; i++){
        int x; cin >> x;
        while(x > 1){
            soma[ps[x]] += ps[x];
            x = x/ps[x];
        }
    }

    vector<ll> respvdd;
    
    for(auto [a,b] : soma){
        respvdd.push_back(b);
    }

    sort(respvdd.rbegin(), respvdd.rend());

    ll ans = 0;

    for(int i =0; i < (int)respvdd.size(); i+= 2){
        ans += respvdd[i];
    }

    cout << ans << '\n';
}
