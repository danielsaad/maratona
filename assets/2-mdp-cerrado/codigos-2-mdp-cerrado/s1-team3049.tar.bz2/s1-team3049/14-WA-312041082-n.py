final = input()
atual = input()

hora_final = final[0:2]
min_final = final[3:5]
hora_final = int(hora_final)
min_final = int(min_final)

hora_atual = atual[0:2]
min_atual = atual[3:5]
hora_atual = int(hora_atual)
min_atual = int(min_atual)

min = abs(min_final - (min_atual))
min_str = str(min)

hora = (hora_final) - (hora_atual)
hora_str = str(hora)

if (min < 10) and (hora < 10):
    print("0" + hora_str + ":0" + min_str)

elif (hora < 10) and (min > 10):
        print("0" + hora_str + ":" + min_str)

elif (min < 10) and (hora > 10):
            print(hora_str + ":0" + min_str)
else:
    print(hora_str + ":" + min_str)
