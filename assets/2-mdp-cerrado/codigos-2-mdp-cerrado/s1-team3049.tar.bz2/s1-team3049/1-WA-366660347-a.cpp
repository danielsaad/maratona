#include<bits/stdc++.h>
using namespace std;
// #define int long long
// #define oo 1e9

// int lis (vector<int>& v, int y) {
//     vector<int> dp;
//     for(int x = 0; x < y; ++x) {
//         auto it = lower_bound(dp.begin(), dp.end(), x);
//         if(it == dp.end()) dp.push_back(x);
//         else *it = x;
//     }
//     return dp.size();
// }

int main (){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n, c;
    cin >> n >> c;
    vector<int> v(n);
    vector<int> vv((n+2), 0);
    vector<int> cons(c+1, 0);
    for(int i = 0; i < n; ++i) {
        cin >> v[i];
    }
    for(int i = 0; i < c; ++i) {
        int a, b;
        cin >> a >> b;
        vv[a] += b;
        // cin >> vv[i].first >> vv[i].second;
    }
    int cnt = 0;
    for(int i = (n+1); i > 0; --i) {
        if(vv[i] != 0) {
            vv[i] += cnt;
            cnt += vv[i];
        }
        else vv[i] += cnt;
        // cout << cnt << endl;
    }
    int k = 1;
    for(int i = 0; i < n; ++i) {
        v[i] += vv[i+1];
        // cout << v[i] << endl;
    }
    int rep = 0;
    for(int i = 0; i < n; ++i) {
        // cout << v[i] << endl;
        if(i != 0) {
            cout << k - rep << ' ';
            if(v[i-1] >= v[i]) k++;
            else k = 1;
            if(v[i-1] == v[i]) rep++;
        }
    }

    cout << endl;


}