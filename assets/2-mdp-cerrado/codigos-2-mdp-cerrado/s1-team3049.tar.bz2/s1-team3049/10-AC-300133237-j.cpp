#include<bits/stdc++.h>
using namespace std;
// #define int long long
// #define oo 1e9

int main (){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int x;
    string s;
    cin >> x >> s;
    vector<int> ans;
    for(int i = 0; i < x; i++) {
        if(s[i] == 'D') ans.push_back(0);
        else if(s[i] == 'C') ans.push_back(1);
        else ans.push_back(2);
    }
    int resp = 1;
    for(int i = 0; i < (x-1); i++) {
        if(abs(ans[i] - ans[i+1]) <= 1) resp++;
        else ans[i+1] = 1;
        // cout << s[i] << " " << s[i+1] << endl;
    }
    cout << resp << endl;
    
}