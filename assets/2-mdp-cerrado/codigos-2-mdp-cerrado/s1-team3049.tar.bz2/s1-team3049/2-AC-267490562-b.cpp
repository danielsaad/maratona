#include<bits/stdc++.h>
using namespace std;
#define int long long
#define oo 1e9

int32_t main (){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    double x;
    cin >> x;
    if(x < 45) cout << "Costa" << endl;
    else if(x > 45) cout << "Saad" << endl;
    else cout << "Ambos" << endl;
    // double y = (x*(M_PI))/180.0;
    // cout << sin(y) << " " << cos(y) << endl;
    // if(sin(y) > cos(y)) cout << "Saad" << endl;
    // else if(sin(y) < cos(y)) cout << "Costa" << endl;
    // else cout << "Ambos" << endl;
}