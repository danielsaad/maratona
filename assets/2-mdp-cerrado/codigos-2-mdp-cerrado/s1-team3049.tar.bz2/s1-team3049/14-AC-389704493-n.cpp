#include <bits/stdc++.h>
using namespace std;

int main () {
    string s, ss;
    cin >> s >> ss;
    string hora1;
    string hora2;
    string min1;
    string min2;
    hora1 += s[0];
    hora1 += s[1];
    min2 += ss[3];
    min2 += ss[4];
    hora2 += ss[0];
    hora2 += ss[1];
    min1 += s[3];
    min1 += s[4];
    int h1 =stoi(hora1);
    int h2 =stoi(hora2);
    int m1 =stoi(min1);
    int m2 =stoi(min2);
    // cout << h2 << endl;

    m1 += h1*60;
    m2 += h2*60;
    int mf = m1 - m2;
    int hf = mf/60;
    // cout << mf << endl;
    mf = mf - (hf*60);
    // cout << hf << ':' << mf - (hf*60) << endl;
    if(hf < 10) cout << '0' << hf << ':';
    else cout << hf << ':';
    if(mf < 10) cout << '0' << mf << endl;
    else cout << mf << endl;
    

    // cout << h1 << ':' << m1 << endl;
    // for(int i = 0; i < s.size(); ++i) {

    // }
}