#include<bits/stdc++.h>
using namespace std;
// #define int long long
// #define oo 1e9

int main (){
    // ios::sync_with_stdio(false);
    // cin.tie(NULL);
    int x;
    string s;
    cin >> x >> s;
    vector<int> ans;
    int cnt = 0;
    for(int i = 0; i < x; i++) {
        if((s[i] =='D' and s[i+1] == 'E') or (s[i] =='E' and s[i+1] == 'D')) cnt++;
    }
    cout << x - cnt << endl;
    
}