#include<bits/stdc++.h>
using namespace std;
#define int long long
#define oo 1e9

int32_t main (){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int x;
    cin >> x;
    if(sin(x) > cos(x)) cout << "Saad" << endl;
    else if(sin(x) < cos(x)) cout << "Costa" << endl;
    else cout << "Ambos" << endl;
}