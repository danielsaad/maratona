final = input()
atual = input()

hora_final = final[0:2]
min_final = final[3:5]
hora_final = int(hora_final)
min_final = int(min_final)

hora_atual = atual[0:2]
min_atual = atual[3:5]
hora_atual = int(hora_atual)
min_atual = int(min_atual)

hora = (hora_final) - (hora_atual)

if(min_final < min_atual):
    aux = (min_atual + min_final)
    hora -= 1
    if(aux == 60):
        min = int(min_final * 2)
    if(aux > 60):
        min = (min_atual + min_final) - 60

else:
    min = int(min_final - min_atual)

hora_str = str(hora)
min_str = str(min)


if (min < 10) and (hora < 10):
    print("0" + hora_str + ":0" + min_str)

elif (hora < 10):
        print("0" + hora_str + ":" + min_str)

elif (min < 10):
            print(hora_str + ":0" + min_str)
else:
    print(hora_str + ":" + min_str)
