#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    int n;

    cin >> n;

    if(n<45){
        cout << "Costa\n";
    }
    else if(n>45 && n<=90){
        cout << "Saad\n";
    }
    else{
        cout<< "Ambos\n";
    }

    return 0;
}