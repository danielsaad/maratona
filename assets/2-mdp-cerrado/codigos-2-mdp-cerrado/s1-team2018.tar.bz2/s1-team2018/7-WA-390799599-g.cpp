#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    _;
    map<string,string>m;
    string a;
    string s="";
    bool iif=false,input=false,pri=false,uaiou=false;
    
    getline(cin,a);
    int t = a.length();
    
    for(int i=0;i<a.length()-1;i++){
        if(a.substr(i,10)==" = input()"){
            s += a.substr(0,i); 
            input=true;
        }
    }
    if(input){
        cout << "LEIA " << s;
    }

    if(a.substr(0,5)=="while"){
        s+=a.substr(5,t-6);
        cout << "ENQUANTO " << s << ' ';
        s = "";

        getline(cin,a);
        t = a.length();
        for(int i=0;i<a.length()-1;i++){
            if(a.substr(i,10)==" = input()"){
                s += a.substr(0,i); 
                input=true;
            }
        }
        if(input){
            cout << "LEIA " << s;
            input = false;
        }
        if(a.substr(0,5)=="print"){
            s+=a.substr(6,t-7);
            pri=true;
    
        }
        if(pri){
            cout<< "APRESENTE " << s;
        }
    }

    else if(a.substr(0,5)=="print"){
        s+=a.substr(6,t-7);
        cout<< "APRESENTE " << s;
    }
    

    else if(a.substr(0,2)=="if"){
        s+=a.substr(3,t-4);
        cout << "SE " << s << " ENTAO ";
        s = "";

        getline(cin,a);
        t = a.length();
        for(int i=0;i<a.length()-1;i++){
            if(a.substr(i,10)==" = input()"){
                s += a.substr(0,i); 
                input=true;
            }
        }
        if(input){
            cout << "LEIA " << s;
            input = false;
        }
        if(a.substr(0,5)=="print"){
            s+=a.substr(6,t-7);
            pri=true;
    
        }
        if(pri){
            cout<< "APRESENTE " << s;
        }
    }

    cout << '\n';

    return 0;
}