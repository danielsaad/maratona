#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    _;
    int n,mes,menor=1,ve=1;
    int ind, a;
    cin >> n >> mes;
    vector<int> p(n);

    for(int i=0;i<n;i++){
        cin >> p[i];
    }

    for(int i=0;i<mes;i++){
        cin>> ind >> a;
        p[ind-1] +=a;
    }

    cout << 1 << '\n';
    for(int i=2;i<n;i++){
        if(p[i-1]<p[i]){
            menor++;
            ve=0;
        }
        else if(p[i-1]>p[i]){
            ve++;
            menor=0;
        }  
        else{
            ve=1;
        }
        cout << ve+menor << '\n';
    }


    return 0;
}