#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    _;
    int n, posicao = 1,gol=0;
    string s, comandos {"ECD"};

    cin >> n;
    int a = n;

    cin >> s;

    for(int i = 0; i < n; i++){
        if(s[i] == 'E'){
            if(s[i] != comandos[posicao]){
                posicao -=1;
                if(s[i]==comandos[posicao]){
                    gol++;
                }
            }
            else{
                gol++;
            }
        }
        if(s[i] == 'D'){
            if(s[i] != comandos[posicao]){
                posicao +=1;
                if(s[i]==comandos[posicao]){
                    gol++;
                }
            }
            else{
                gol++;
            }
        }
        if(s[i] == 'C'){
            if(s[i] == comandos[posicao]){
                gol++;
            }
        }

    }   

    cout << gol << '\n';


    return 0;
}