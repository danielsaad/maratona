#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    _;
    int n,mes,ve=1;
    int ind, a;
    cin >> n >> mes;
    vector<int> p(n);

    for(int i=0;i<n;i++){
        cin >> p[i];
    }

    for(int i=0;i<mes;i++){
        cin>> ind >> a;
        p[ind-1] +=a;
    }

   

    for (int i = 1; i < n; i++){
        if (p[i] > p[i-1]){
            cout << ve << endl;
          ve = 1;

        } else if (p[i] <= p[i-1]){
            cout << ve << endl;
            ve++;
        }
    }
    
    // for(int i=2;i<n;i++){
    //     if(p[i-1]<p[i]){
    //         menor++;
    //         ve=0;
    //     }
    //     else if(p[i-1]>p[i]){
    //         ve++;
    //         menor=0;
    //     }  
    //     else{
    //         ve=1;
    //     }
    //     cout << ve+menor << '\n';
    // }


    return 0;
}