#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    _;
    int h,m;
    int ch,cm;
    char ig;
    cin >> h >> ig >> m;
    cin >> ch >> ig >> cm;

    m+=h*60;
    cm+=ch*60;
    m-=cm;
    h= m/60;
    m=m%60;

    if(m<10 && h<10){
        cout <<'0' << h  << ':' << '0' << m << '\n';
    }
    else if(m>10 && h<10){
        cout <<'0' << h  << ':' << m << '\n';
    }
    else if(m<10 && h>10){
        cout << h  << ':' <<'0' << m << '\n';
    }
    else{
        cout << h << ':' << m << '\n';
    }

    



    return 0;
}