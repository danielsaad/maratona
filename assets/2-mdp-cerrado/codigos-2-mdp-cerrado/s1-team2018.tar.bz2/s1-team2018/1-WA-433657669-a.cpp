#include <bits/stdc++.h>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);


int main(){
    _;
    int n,mes,ve=1,menor;
    int ind, a;
    cin >> n >> mes;
    vector<int> p(n);
    stack <int> pilha;

    for(int i=0;i<n;i++){
        cin >> p[i];
    }

    for(int i=0;i<mes;i++){
        cin>> ind >> a;
        p[ind-1] +=a;
    }

   pilha.push(p[0]);

   for(int i=1;i<n;i++){
       cout << pilha.size() << '\n';
       if(p[i]<pilha.top()){
        pilha.push(p[i]);
       }
       if(p[i]>pilha.top()){
        do{
            pilha.pop();
        }while(pilha.size());
        pilha.push(p[i]);
       }
   }
    
   
   // for (int i = 1; i < n; i++){


    //     if (p[i] > p[i-1]){
    //         cout << ve << endl;
    //       ve = 1;

    //     } else if (p[i] <= p[i-1]){
    //         cout << ve << endl;
    //         ve++;
    //     }
    // }



    return 0;
}