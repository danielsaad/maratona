a = input()
b = input()

ha, ma = a.split(":")
hb, mb = b.split(":")

ha = int(ha)
hb = int(hb)
ma = int(ma)
mb = int(mb)


mc = ma - mb if ma >= mb else 60 + (ma -mb)
hc = ha - hb if ma >= mb else (ha -hb -1)

print(f"{'0' if hc < 10 else ''}{hc}:{'0' if mc < 10 else ''}{mc}")