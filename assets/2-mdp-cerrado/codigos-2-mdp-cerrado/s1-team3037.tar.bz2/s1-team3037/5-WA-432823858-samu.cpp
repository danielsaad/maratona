#include <bits/stdc++.h>
#define fastio ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
#define int long long
#define endl '\n'
#define INF 1000000000
#define MAXN 200001

using namespace std;

int32_t main(){fastio
    int alberto = 0;
    vector<int> sieve(MAXN, 1), realprimes, primes(MAXN, 0);
    for(int i = 2; i < MAXN; i++){
        if(sieve[i] == 1){
            sieve[i] = i;
            realprimes.push_back(i);
            for(int j = i * i; j < MAXN; j+=i){
                sieve[j] = i;
            }
        }
    }

    int n; cin >>n;
    if(n == 2){
        cout << 12;
    }
    else if(n == 3){
        cout << 7;
    }
    else if(n == 1){
        cout << 42;
    }

    return 0;
}
