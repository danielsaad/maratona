#include <bits/stdc++.h>
#define fastio ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
#define int long long
#define endl '\n'
#define INF 1000000000
#define MAXN 20001

using namespace std;

int32_t main(){fastio
    int alberto = 0;
    vector<int> sieve(MAXN, 1), realprimes, primes(MAXN, 0);
    for(int i = 2; i < MAXN; i++){
        if(sieve[i] == 1){
            sieve[i] = i;
            realprimes.push_back(i);
            for(int j = i * i; j < MAXN; j+=i){
                sieve[j] = i;
            }
        }
    }

    // cout << realprimes.back() << endl;

    int n; cin >> n;
    for(int i = 0; i < n; i++){
        int value; cin >> value;
        int divisor = 0;
        while(1){
            if(value == 1 || divisor >= (int) realprimes.size()){
                break;
            }  
            while(value % realprimes[divisor] == 0){   

                primes[realprimes[divisor]] += realprimes[divisor];
                value /= realprimes[divisor];
            }
            
            divisor++;

            //primes[sieve[value]] += sieve[value];
        }
    }

    sort(primes.begin(), primes.end(), greater<int>());
   
    // for(int i = 0; i < MAXN; i++){
    //     if(primes[i] == 0) break;
    //     cout << primes[i] << endl;
    // }

    for(int i = 0; i < MAXN; i+=2){
        if(primes[i] == 0) break;
        alberto += primes[i];
    }
    cout << alberto << endl;

    return 0;
}
