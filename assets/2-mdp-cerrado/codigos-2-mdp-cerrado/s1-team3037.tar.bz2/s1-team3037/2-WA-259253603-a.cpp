#include <bits/stdc++.h>
#define fastio ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
#define int long long
#define endl '\n'

using namespace std;

int32_t main(){fastio
    int a; cin >> a;


    if(cos(a) > sin(a)) {
        cout << "Costa" << endl;
    } else if (a!= 45) {
        cout << "Saad" << endl;
    } else {
        cout << "Ambos"<< endl;
    }

    return 0;
}