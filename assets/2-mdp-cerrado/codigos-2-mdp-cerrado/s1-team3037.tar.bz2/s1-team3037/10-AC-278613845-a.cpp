#include <bits/stdc++.h>
#define fastio ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
#define int long long
#define endl '\n'
#define oo 1000000000

using namespace std;

int32_t main(){fastio
    int n; cin >> n;
    string s; cin >> s;

    vector<vector<int>> dp(n, vector<int>(3, 0));
    dp[0][0] = (s[0] == 'E' ? 1 : 0);
    dp[0][1] = (s[0] == 'C' ? 1 : 0);
    dp[0][2] = (s[0] == 'D' ? 1 : 0);

    for(int i = 1; i < n; i++){
        for(int j = 0; j < 3; j++){
            if(j == 0){
                dp[i][j] = max({dp[i - 1][0], dp[i - 1][1]});    
            }
            else if(j == 2){
                dp[i][j] = max({dp[i - 1][1], dp[i - 1][2]});
            }
            else{
                dp[i][j] = max({dp[i - 1][0], dp[i - 1][1], dp[i - 1][2]});
            }
            if((s[i] == 'E' && j == 0) || (s[i] == 'C' && j == 1) || (s[i] == 'D' && j == 2)){
                dp[i][j]++;
            }
        }
    }

    cout << max({dp[n - 1][0], dp[n - 1][1], dp[n - 1][2]}) << endl;

    return 0;
}
