#include <bits/stdc++.h>
#define fastio ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
#define int long long
#define endl '\n'
#define INF 1000000000
#define MAXN 10000001

using namespace std;

int32_t main(){fastio
    int alberto = 0;
    vector<int> sieve(MAXN, 1), primes(200001, 0);
    for(int i = 2; i < 200001; i++){
        if(sieve[i] == 1){
            sieve[i] = i;
            for(int j = i * 2; j < MAXN; j+=i){
                sieve[j] = i;
            }
        }
    }

    int n; cin >> n;
    for(int i = 0; i < n; i++){
        int value; cin >> value;
        while(1){
            if(value == 1) break;
            primes[sieve[value]] += sieve[value];
            value /= sieve[value];
        }
    }

    sort(primes.begin(), primes.end(), greater<int>());
   
    // for(int i = 0; i < MAXN; i++){
    //     if(primes[i] == 0) break;
    //     cout << primes[i] << endl;
    // }

    for(int i = 0; i < MAXN; i+=2){
        if(primes[i] == 0) break;
        alberto += primes[i];
    }
    cout << alberto << endl;

    return 0;
}
