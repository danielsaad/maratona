#include <bits/stdc++.h>
#define fastio ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
#define int long long
#define endl '\n'
#define INF 1000000000

using namespace std;


int32_t main(){fastio
    int n, c; cin >> n >> c;

    vector<int> v(n+1);

    for(int i=1; i<=n; i++) cin >> v[i];

    vector<int> delta(n+2);

    for(int i=0; i<c; i++) {
        int m, h; cin >> m >> h;
        delta[0] += h;
        delta[min(n, m)+1] -= h;

    }

    for(int i=1; i<=n; i++) {
        delta[i] += delta[i-1];
    }

    for(int i=1; i<=n; i++) {
        v[i]+= delta[i];
    }

    vector<int> ans(n+1);

    for(int i=1; i<=n; i++) {
         
        if(v[i-1] > v[i]) ans[i] = ans[i-1] +1;
    }


    for(int i=2; i<=n; i++) {
        cout << (ans[i-1]+1) << endl;
    }




    return 0;
}
