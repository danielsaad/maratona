def parseRoll(string):
    if(string.startswith("print(")):
        string = string[6: -1]
        return f"APRESENTE {string.strip()}"
    elif(string.endswith(")") and string[:-1].strip().endswith("input(")):
        i = string.index("=")
        return f"LEIA {string[:i].strip()}"
    elif(string.startswith("if ")):
        string = string[3: -1]
        return f"SE {string.strip()} ENTAO"
    elif(string.startswith("while ")):
        string = string[6: -1]
        return f"ENQUANTO {string.strip()}"
    else: 
        return string 
ans = ""
while True:
    try:
        x = input().strip()

   
        ans += parseRoll(x) + " " 
    except: 
        break 

print(ans[:-1])
