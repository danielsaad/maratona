def parseRoll(string):
    if(string.startswith("print(")):
        string = string[6: -1]
        return f"APRESENTE {string}"
    elif(string.endswith("input()")):
        string = string[0: -10]
        return f"LEIA {string}"
    elif(string.startswith("if ")):
        string = string[3: -1]
        return f"SE {string} ENTÃO"
    elif(string.startswith("while ")):
        string = string[6: -1]
        return f"ENQUANTO {string}"
    else: 
        return string 


ans = ""
while True:
    try:
        x = input().strip()

   
        ans += parseRoll(x) + " " 
    except: 
        break 

print(ans)
