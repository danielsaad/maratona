import re

def main():
    a = input()

    match = re.match("[ ]*(.*) = input()", a)

    if match:
        print(f"LEIA {match[1]}", end=" ")
        return

    match = re.match("[ ]*print[(](.*)[)]", a)

    if match:
        print(f"APRESENTE {match[1]}", end=" ")
        return

    match = re.match("if (.*):", a)

    if match:
        print(f"SE {match[1]} ENTAO", end=" ")
        main()
        return
    
    match = re.match("while (.*):", a)

    if match:
        print(f"ENQUANTO {match[1]}", end=" ")
        main()
        return

main()
print()