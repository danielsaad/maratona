#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;
#define int long long

const double eps = 1e-12;
const int N=2e5+10;
vector<int> v(N), suf(N);

void test() {
    ll n, c;

    map<int, int> mp;
    while (cin >> n) {
        cin >> c;
        int qtd  = 1;
        for(int i = 1; i<= n; i++) cin >> v[i];
        for(int i = 1;i<= c; i++){
            int a, b; cin >> a >> b;
            mp[a] = b;
        }

        for(int i = 0; i <= n+1;i++) suf[i] = 0;

        for(int i =n; i >= 1; i--){
            suf[i] = suf[i+1];
            if(mp.count(i)) suf[i] += mp[i];
        }

        for(int i = 1; i<= n; i++) v[i] += suf[i];
        set <int> st;
        
        st.insert(v[1]);
        for(int i = 2; i<= n; i++){
            if(i == 1) continue;

            int at = v[i-1];
            while(*st.begin() < at) st.erase(st.begin());
            cout << st.size()<<"\n";
            st.insert(v[i]);
        }

    }
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t=1;
    // cin>>t;

    while(t--) test();

    return 0;
}