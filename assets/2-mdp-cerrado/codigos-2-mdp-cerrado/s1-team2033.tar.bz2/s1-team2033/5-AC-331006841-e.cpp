#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;

const int N = (int)1e7 + 10;
int a[N], composite[N], freq[N], lp[N];

void test() {
    int n; cin >> n;

    rep(i, 2, N - 1) {
        if (composite[i] == 1) {
            continue;
        }

        lp[i] = i;

        for (int j = 2*i; j < N; j += i) {
            composite[j] = 1;
            lp[j] = i;
        }
    }

    rep(i, 1, n) {
        cin >> a[i];

        while (a[i] > 1) {
            int p = lp[a[i]];
            int k = 0;

            while (a[i] % p == 0) {
                a[i] /= p;
                k++;
            }

            freq[p] += k;
        }
    }

    vector<ll> v;

    rep(i, 1, N - 1) {
        if (freq[i] > 0) {
            v.push_back((ll)i*(ll)freq[i]);
        }
    }

    sort(v.rbegin(), v.rend());

    ll s = 0;

    for (ll i = 0; i < v.size(); i += 2) {
        s += v[i];
    }

    cout << s << el;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    ll t = 1;
    // cin >> t;

    while (t--) {
        test();
    }

    return 0;
}