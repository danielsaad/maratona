#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;
#define int long long

const double eps = 1e-12;
const int N=2e5+10;
vector<int> v(N);

void test() {
    ll n, c;

    map<int, int> mp;
    while (cin >> n) {
        cin >> c;
        int qtd  = 1;
        for(int i = 1; i<= n; i++) cin >> v[i];
        for(int i = 1;i<= c; i++){
            int a, b; cin >> a >> b;
            mp[a] = b;
        }

        for(int i = 2; i<= n; i++){
            if(mp.count(i-1)){
                v[i-1] += mp[i-1];
            }

            cout << qtd <<"\n";

            if(v[i-1] > v[i]){
                // cout <<"aumenta i = " << i << "\n";
                qtd++;
            } else {
                qtd = 1;
                // cout <<"reseta i = " << i <<"\n";
            }
            // cout << qtd <<" ";
        }
    }
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t=1;
    // cin>>t;

    while(t--) test();

    return 0;
}