#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;
#define int long long

const double eps = 1e-12;

void test() {
    ll n;

    cin >> n;
    int q; cin >> q;
    string s;
    map<char, int> mp;

    cin >> s;
    string cp = s;

    for(int i = 0;i<s.size(); i++) {
        char x = s[i];
        if(!mp.count(x)) mp[x] = i;
    }

    map<int, int> mp1;
    for(int i = 0; i < q; i++){
        cin >> s;
        for(int j = 0; j< s.size(); j++){
            if(!mp1.count(s[j])) mp1[s[j]] = j;
        }

        int idx = 2e18, ans = -1;

        for(auto[c,v]: mp1){
            if(c != cp[0]){
                idx = min(idx, v);
                if(idx == v){
                    ans = max(ans, (ll)cp.size() + (ll)s.size() - v);
                }
            }
        }

        
        if(idx == 2e18){
            // nesse caso, a string b é igual a pos 0 de a
            for(auto [c, v]: mp){
                if(c != cp[0]){
                    idx = min(idx, v);
                    if(idx == v){
                        if(v > s.size()){
                            ans = cp.size()-s.size();
                        } else{
                            ans = cp.size()-v + s.size()-v;
                        }
                    }
                }
            }
        }

        
        if(idx == 2e18){
            ans = cp.size()-s.size();
        }

        for(auto [c,v]: mp){
            if(c != s[0]){
                idx = min(idx, v);
                if(idx==v){
                    ans = max(ans, (ll)s.size() + (ll)cp.size()-v);
                }
            }
        }

        ans = max({(int)s.size(), (int)cp.size(), ans});

        cout << ans<<"\n";
        mp1.clear();
    }
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t=1;
    // cin>>t;

    while(t--) test();

    return 0;
}