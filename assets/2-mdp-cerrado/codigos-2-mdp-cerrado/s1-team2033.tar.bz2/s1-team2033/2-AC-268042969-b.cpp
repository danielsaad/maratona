#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;

const double eps = 1e-12;

void test() {
    ll n;

    while (cin >> n) {
        double a = M_PI*n / 180.0;

        double x = sin(a);
        double y = cos(a);

        if (abs(x - y) < eps) cout << "Ambos";
        else if (x + eps < y) cout << "Costa";
        else cout << "Saad";

        cout << el;
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t=1;
    // cin>>t;

    while(t--) test();

    return 0;
}