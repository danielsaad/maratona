#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;

const double eps = 1e-12;

void test() {
    ll n;

    map<char, int> mp ={{'C', 2}, {'D', 3}, {'E', 1}};
    while (cin >> n) {
        string s; cin >> s;
        int qtd = 0, pos = 2;
        for(auto x: s){
            if(mp[x] == 2){
                if(pos == 1)pos++;
                else if(pos == 3) pos--;
            } else if(mp[x]==1){
                pos--;
                pos = max(pos, 1);
            } else{
                pos++;
                pos = min(pos, 3);
            }

            if(pos == mp[x]) qtd++;
        }
        cout << qtd <<"\n";
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t=1;
    // cin>>t;

    while(t--) test();

    return 0;
}