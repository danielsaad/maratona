#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (ll i = (a); i <= (b); i++) 
#define per(i, a, b) for (ll i = (a); i >= (b); i--) 
#define el "\n"

using ll = long long;
using ld = long double;

const double eps = 1e-12;

void test() {
    ll n;

    string s1, s2;
    while (cin >> s1) {
        cin >> s2;
        int cmc = stoi(s2.substr(0,2))*60 + stoi(s2.substr(3, 2));
        int fim =stoi(s1.substr(0,2))*60 + stoi(s1.substr(3, 2));
        int ans = fim-cmc;
        
        int hr = ans/60;
        if(hr < 10){
            cout <<"0" << hr<<":";
        } else cout << hr<<":";
        int min = ans%60;
        if(min < 10){
            cout <<"0"<<min<<"\n";
        } else cout << min <<"\n";

        
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t=1;
    // cin>>t;

    while(t--) test();

    return 0;
}