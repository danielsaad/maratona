
import sys


entrada = float(sys.stdin.readline())

if entrada == 45:
    print("Ambos")

elif entrada > 45 :
    print("Saad")

elif entrada < 45 :
    print("Costa")



