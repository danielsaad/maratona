import sys

posicao = {
    "E" : 0,
    "C" : 1,
    "D" : 2
}

n = int(sys.stdin.readline())

chutes = sys.stdin.readline().strip()

posicao_atual = posicao[chutes[0]]

count = 1

for i in range(len(chutes)-1):

    proximo = chutes[i+1]

    if abs(posicao_atual - posicao[proximo]) <= 1:

        count += 1
        posicao_atual = posicao[proximo]

    else :

        posicao_atual = posicao["C"]

print(count)


