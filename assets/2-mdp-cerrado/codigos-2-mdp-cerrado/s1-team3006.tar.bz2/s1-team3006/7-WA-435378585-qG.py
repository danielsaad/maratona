import sys 

def func_print(text):
    
    string_saida = ""
    
    flag = False

    for i in text:

        for j in i:

            if j == ")":

                print(f"APRESENTE {string_saida}")
                return

            elif flag:

                string_saida += j
            
            if j == "(":

                flag = True

        string_saida += " "



def func_input(text):

    variavel = text[0] 

    print(f"LEIA {variavel}")

    return 



def func_while(text_1 , text_2):
    
    string_saida = ""

    text_1[-1] = text_1[-1].strip(":")

    for word in text_1:
        
        if word == "while":
            continue

        if word == "or":
           word = "OU"

        if word == "and":
            word = "E"

        string_saida += word
        string_saida += " "

    if "input()" in text_2:

        print(f"ENQUANTO {string_saida}{func_input(text_2)}")
        return

    else :

        print(f"ENQUANTO {string_saida}{func_print(text_2)}")
        return 

def func_if(text_1 , text_2):
    
    string_saida = ""

    text_1[-1] = text_1[-1].strip(":")

    for word in text_1:
        
        if word == "if":
            continue

        if word == "or":
           word = "OU"

        if word == "and":
            word = "E"

        string_saida += word
        string_saida += " "

    if "input" in text_2:

        print(f"SE {string_saida}ENTAO {func_input(text_2)}")
        return


    else :

        print(f"SE {string_saida}ENTAO {func_print(text_2)}")
        return




entrada_1 = sys.stdin.readline().split()

if "if" in entrada_1 or "while" in entrada_1 :

    entrada_2 = sys.stdin.readline().split()

if "input()" in entrada_1:

    func_input(entrada_1)

elif entrada_1[0][:5] == "print":
    func_print(entrada_1)

elif  "while" in entrada_1:

    func_while(entrada_1, entrada_2)

else:

    func_if(entrada_1, entrada_2)