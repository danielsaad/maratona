#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    string a,b; cin >> a >> b;

    int h1 = (a[0] * 10 + a[1])*60 + a[3] * 10 + a[4],h2 = (b[0] * 10 + b[1])*60 + b[3] * 10 + b[4];
    int m1;
    if (h1 > h2) {
        h1 = h1-h2;
        m1 = h1%60;
        h1 = h1/60;
        if (h1 < 10)cout << '0';
        cout << h1 << ':';
        if (m1 < 10)cout << '0';
        cout << m1 << '\n';
    }else if (h2 > h1) {
        h1 = 60*24 - (h2-h1);
        m1 = h1%60;
        h1 = h1/60;
        if (h1 < 10)cout << '0';
        cout << h1 << ':';
        if (m1 < 10)cout << '0';
        cout << m1 << '\n';
    }else {
        cout << "00:00\n";
    }

}