#include <bits/stdc++.h>
using namespace std;
#define int long long


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int np, cp; cin >> np >> cp;
    vector<int> pr(np);
    vector<int> num(np, 1);

    for (int i=0; i<np; i++) {
        cin >> pr[i];
    }

    for (int i=0; i<cp; i++) {
        int m, a;
        cin >> m >> a;
        for (int j=0; j<m; j++) {
            pr[j]+=a;
        }
    }

    for (int i=1; i<np; i++) {
        if (pr[i] < pr[i-1]) {
            num[i+1] += num[i];
        }
    }

    for (int i=1; i<np; i++) {
        cout << num[i] << "\n";
    }


}