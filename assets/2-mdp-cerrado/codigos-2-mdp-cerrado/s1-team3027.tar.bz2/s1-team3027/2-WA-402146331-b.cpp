#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int a; cin >> a;

    if (cos(a) > sin(a)) {
        cout << "Costa" << "\n";
    } else if (cos(a) < sin(a)) {
        cout << "Saad" << "\n";
    } else {
        cout << "Ambos" << "\n";
    }
}