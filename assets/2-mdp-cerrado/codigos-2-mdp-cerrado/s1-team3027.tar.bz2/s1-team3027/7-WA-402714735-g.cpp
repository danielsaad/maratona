#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

#define int long long

void saida(string a)
{
    cout << "APRESENTE ";
    for(int i = a.find("print") + 6; i < a.size();i++)
    {
        if(a[i] == ')')
        {
            i = a.size() + 10;
        }
        else
        {
            cout << a[i];
        }
    }
    cout << '\n';
}
void entrada(string a)
{
    cout << "LEIA ";
    for(int i = 0; i < a.size();i++)
    {
        if(a[i] == ' ')
        {
            i = a.size() + 10;
        }
        else
        {
            cout << a[i];
        }
    }
    cout << '\n';
}

void se(string a)
{
    cout << "SE";
    for(int i = a.find("if") + 2; i < a.size() - 1;i++)
    {
       cout << a[i];
    }
    cout << " ENTAO ";
}

void enquanto(string a)
{
    cout << "ENQUANTO";
    for(int i = a.find("while") + 5; i < a.size() - 1;i++)
    {
        cout << a[i];
    }
    cout << ' ';
}
signed main() {
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);

    vector<string> instrucoes;
    string a,b,temp;
    char sabe;
    do
    {
      cin >> temp;
      if(a!= "")a+= " ";
      a += temp;
    }while(scanf("%c",&sabe) != EOF && sabe != '\n');
    //cout << a << '\n';
    if(a.find("input") != string::npos)
    {
        entrada(a);
    }
    else if(a[0] == 'w')
    {
        enquanto(a);
        do
        {
            cin >> temp;
            if(b!= "")b+= " ";
            b += temp;
        }while(scanf("%c",&sabe) != EOF && sabe != '\n');
        if(b.find("input") != string::npos)
        {
            entrada(b);
        }
        else
        {
            saida(b);
        }
    }
    else if(a[0] == 'i')
    {
        se(a);
        do
        {
            cin >> temp;
            if(b!= "")b+= " ";
            b += temp;
        }while(scanf("%c",&sabe) != EOF && sabe != '\n');
        if(b.find("input") != string::npos)
        {
            entrada(b);
        }
        else
        {
            saida(b);
        }
    }
    else if(a[0] == 'p')
    {
        saida(a);
    }
}