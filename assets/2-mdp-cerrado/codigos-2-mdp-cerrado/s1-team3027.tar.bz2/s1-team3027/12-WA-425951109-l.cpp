#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);

    int n,a,b,last = 1; cin >> n;
    int total =1,temp;
    for (int i = 0; i < n;i++) {
        a = last + i + 1;
        cout << "? " << a << '\n';
        cin >> temp;
        if (temp)last = a;
        else {
            b = last + i +2;
            cout << "? " << b << '\n';
            cin >> temp;
            if (temp)last = b;
            else {
                cout << "! " << last << '\n';
                return 0;
            }
        }
    }
    cout << "! "<<last << '\n';
}