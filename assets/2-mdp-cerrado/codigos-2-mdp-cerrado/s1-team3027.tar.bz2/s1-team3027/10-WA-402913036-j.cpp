#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n; cin >> n;
    string a; cin >> a;
    char ant = a[0];
    int ans = 0;
    for(int i = 1; i < n; i++)
    {
        if(ant == 'E' && a[i] == 'D' || ant == 'D' && a[i] == 'E')
        {
             ans+=1;
        }
        ant = a[i];
    }
    cout << a.size() - ans << '\n';
}