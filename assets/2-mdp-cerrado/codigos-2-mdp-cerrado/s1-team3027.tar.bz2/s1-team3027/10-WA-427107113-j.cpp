#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n; cin >> n;
    string a; cin >> a;
    int ans = 0;
    int pos = 'C';
    for(int i = 0; i < n; i++)
    {
        //cout << (char)pos << '\n';
         if(pos == 'C')
         {
           ans++;
           if(a[i] == 'D')pos = 'D';
           if(a[i] == 'E')pos = 'E';
         }
         else if(pos != a[i])pos = 'C';

    }
    cout << ans << '\n';
}