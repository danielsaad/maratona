#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);

    int n,a,b,last = 1; cin >> n;
    int total =1,temp,pos = 1;
    for (int i = 0; i < n;i++) {
        a = last + pos;
        cout << "? " << a << '\n';
        cin >> temp;
        if (!temp){
            b = last + pos + 1;
            cout << "? " << b << '\n';
            cin >> temp;
            if (temp)pos++;
            else {
                cout << "! " << last + pos  - i - 2 << '\n';
                return 0;
            }
        }
        last +=i+2;
    }
    cout << "! "<<last << '\n';
}