#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n; cin >> n;
    string a; cin >> a;
    int ans = 0;
    int d = 0,e =0;
    for(int i = 0; i < n; i++)
    {
        if(a[i] == 'D')d++;
        if(a[i] == 'E')e++;
        if(a[i] == 'C')
        {
            ans += min(e,d);
            d = 0;
            e = 0;
        }
    }
    ans += min(e,d);
    cout << a.size() - ans << '\n';
}