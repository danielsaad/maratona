#include <bits/stdc++.h>
using namespace std;
#define int long long



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int a; cin >> a;

    if (a == 45) {
        cout << "Ambos\n";
    } else if (a<45) {
        cout << "Costa" << "\n";
    } else{
        cout << "Saad" << "\n";
    }
}