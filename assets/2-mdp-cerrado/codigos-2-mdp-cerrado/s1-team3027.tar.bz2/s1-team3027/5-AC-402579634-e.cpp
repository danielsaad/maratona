#include <bits/stdc++.h>
using namespace std;
#define int long long

vector<int>ans;
set<int>tem;
map<int,int>quantos;
vector<int>primos;
void crivo() {
    int MAX = 4000;
    vector<bool>prime(MAX+1,true);
    for (int i = 2; i <= MAX; i++) {
        if (prime[i]) {
            primos.push_back(i);
            for (int j = 2*i; j <= MAX; j+=i) {
                prime[j] = false;
            }
        }
    }
}
void factor(int n)
{
    for (auto p : primos) {
        if (p * p > n)break;
        if (n % p == 0)tem.insert(p);
        while (n % p == 0) {
            n/=p;
            quantos[p]++;
        }
    }
    if (n!= 1) {
        tem.insert(n);
        quantos[n]++;
    }
    return;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    crivo();
    int n,temp; cin >> n;

    for(int i =0;i < n;i++) {
        cin >> temp;
        factor(temp);
    }
    int flag = 1,total = 0;
    for (auto x : tem) {
        ans.push_back(quantos[x] * x);
    }
    sort(ans.begin(),ans.end(), greater<int>());
    for (auto x: ans) {
        if (flag)total += x;
        flag ^= 1;
    }
    cout << total << '\n';
}