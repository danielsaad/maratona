#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"
#define fastio ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

signed main () {fastio

    int n, c, a, m, soma=1;
    

    cin >> n >>c;
    vector<int> v(n), delta(n+2, 0), ans(n,0);

    for(int i=0; i<n; i++){
        cin>>v[i];
    }

    for(int i=0; i<c; i++){
        cin >> m >> a;

        delta[0]=a;
        delta[m]=-a;
    }

    for(int i=0; i<n;i++){
        ans[i]=delta[i]+ans[i];
    }

    for(int i=1; i<n;i++){
       
        
        cout << soma <<endl;

        if(v[i]+ans[i] > v[i-1]+ans[i-1]) soma=1;
        else soma++;


    }


    return 0;   
}
