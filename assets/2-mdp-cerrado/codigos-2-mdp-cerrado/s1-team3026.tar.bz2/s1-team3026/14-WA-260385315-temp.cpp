#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"
#define fastio ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

signed main () {fastio

    int hi,mi, hf, mf;
    scanf("%lld:%lld", &hf,&mf);
    scanf("%lld:%lld", &hi,&mi);

    int m = mf - mi;
    int h = hf - hi;

    printf("%.2lld:%.2lld\n", h, m);

    return 0;   
}