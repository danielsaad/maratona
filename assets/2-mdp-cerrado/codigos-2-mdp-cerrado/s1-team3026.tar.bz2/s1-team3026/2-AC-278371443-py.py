import math
n = int(input())

if n == 45:
    print("Ambos")
elif math.sin((math.pi *  n) /180.0) > math.cos((math.pi *  n) /180.0):
    print("Saad")
else:
    print("Costa")
