#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"
#define fastio ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

signed main () {fastio

    vector<int> crivo(1e7+5, 0);
    for(int i=2; i<1e7; i++){
        if(crivo[i] == 0){
            crivo[i] = i;
            for(int j = i*i; j<=1e7; j+=i){
                if(crivo[j] == 0) crivo[j] = i;
            }
        }
    }

    int n;
    cin >> n;

    vector<int> v(n);
    for(int i=0; i<n; i++) cin >> v[i];

    map<int, int> fat;

    for(int i=0; i<n; i++){
        int y=v[i];

        while(y != 1){
            fat[crivo[y]]++;
            y /= crivo[y];
        }
    }

    int ans=0, i=0;
    vector<int> v2;
    for(auto [p, e] : fat){
        v2.push_back(p*e);
    }

    int sz = fat.size();
    
    //if (sz&1) i = 0;
    //else i = 1;
    for(auto [p, e] : fat){
        //cout << p << " " << e << endl;
        //if(i%2==0) ans += p * e;
        //i++;
        //v2.push_back([p*e]);
    }

 
    sort(v2.rbegin(), v2.rend());

    for (int i =0; i < v2.size();i++) {
        if(i%2==0)  ans += v2[i];
    }

    cout<< ans << endl;

    return 0;   
}