#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"
#define fastio ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

signed main () {fastio

    int n;
    cin >> n;
    
    string s;
    cin >> s;

    vector<char> pos = {'E', 'C', 'D'};
    int cur = 1, ans = 0, b =0;
    for (auto c : s) {
        int idx;

        if (c == 'E') {
            if (cur!=2) cur = 0, ans++;
            else cur=1;
        } else if (c == 'D') {
            if (cur!=0) cur = 2, ans++;
            else cur=1;
        } else{
            cur=1,ans++;
        }

    
    } 
  
    cout << ans << endl;


    return 0;   
}

/*
EDDECEEDDE
*/