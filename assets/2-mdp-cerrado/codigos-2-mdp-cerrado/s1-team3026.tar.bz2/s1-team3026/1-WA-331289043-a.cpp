#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"
#define fastio ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

signed main () {fastio

    int n, c, a, m, soma=1;
    

    cin >> n >>c;
    vector<int> v(n), delta(n+2, 0), ans(n+2,0);

    for(int i=0; i<n; i++){
        cin>>v[i];
    }

    for(int i=0; i<c; i++){
        cin >> m >> a;

        delta[0]+=a;
        delta[m]+=-a;
    }

    ans[0]+=delta[0];
    for(int i=1; i<=n;i++){
        ans[i]=delta[i]+ans[i-1];
    }
    v[0]+=ans[0];

    for(int i=1; i<n;i++){
       
        
        cout << soma <<endl;

        v[i]+=ans[i];

        if(v[i] >= v[i-1]) soma=1;
        else soma++;

        //cout << v[i] << " ";


    }


    return 0;   
}


/*
6 2
6 11 120 200 20 7
1 6
3 81

*/