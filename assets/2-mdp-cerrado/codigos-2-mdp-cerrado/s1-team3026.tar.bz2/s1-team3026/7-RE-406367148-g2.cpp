#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"
#define fastio ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

signed main () {fastio

    string p, s;
    getline(cin, p);
    getline(cin, s);

    s += '&', p += '&';
    vector<string> pl, sl;
    string cur;
    for(auto c : p) {
        if (c == ' ' || c == '&') {
            if(!cur.empty()) pl.push_back(cur);
            cur = "";
        } else {
            cur += c;
        }
    }

    cur = "";
    for(auto c : s) {
        if (c == ' ' || c == '&') {
            if(!cur.empty()) sl.push_back(cur);
            cur = "";
        } else {
            cur += c;
        }
    }

    string ppl = pl[0], upl = pl[pl.size() - 1];
    string spl = sl[0], usl = sl[sl.size() - 1];

    int podpl = 0, podsl = 0;
    if (ppl == "while" || ppl == "if") {
        if (ppl == "while") cout << "ENQUANTO ";
        else cout << "SE ";

        for (int i = 1; i < pl.size(); i++) {
            string ult;
            if(i == pl.size() - 1) {
                for (int id = 0; id < pl[i].size() - 1; id++) {
                    ult += pl[i][id];
                }
                pl[i] = ult;
            }
            cout << (i != 1 ? " " : "") << pl[i];
        }
    } else if (ppl.substr(0, 6) == "print(") {
        cout << "APRESENTE " ;
        for (int i = 0; i < p.size(); i++) {
            if (p[i] == '"') {
                podpl++;
                continue;
            }
            if(podpl == 1) {
                cout << p[i];
            }
        }
    } else if (upl == "input()") {
        cout << "LEIA ";
        for (int i = 0; i < pl.size(); i++) {
            if (pl[i] == "=") {
                break;
            }
            cout << (i ? " " : "") << pl[i];
        }
    }

    bool sec =0;

    if (spl.substr(0, 6) == "print(") {
        cout << " APRESENTE " ;
        for (int i = 0; i < s.size(); i++) {
            if (s[i] == '"') {
                podsl++;
                continue;
            }
            if(podsl == 1) {
                cout << s[i];
            }
        } cout << endl, sec =1;
    } else if (usl == "input()") {
        cout << " LEIA ";
        for (int i = 0; i < sl.size(); i++) {
            if (sl[i] == "=") {
                break;
            }
            cout << (i ? " " : "") << sl[i];
        }cout << endl, sec =1;
    }

    if (!sec)cout << endl;

    return 0;   
}