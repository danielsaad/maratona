import math
n = int(input())

if math.sin(math.pi *  n /180) == math.cos(math.pi *  n /180):
    print("Ambos")
elif (math.sin(math.pi *  n /180) > math.cos(math.pi *  n /180)):
    print("Saad")
else:
    print("Costa")
