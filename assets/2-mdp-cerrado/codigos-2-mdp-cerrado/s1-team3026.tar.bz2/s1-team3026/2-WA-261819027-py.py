import math
n = int(input())

if math.sin(n) == math.cos(n) :
    print("Ambos")
elif (math.sin(n) > math.cos(n)):
    print("Saad")
else:
    print("Costa")
