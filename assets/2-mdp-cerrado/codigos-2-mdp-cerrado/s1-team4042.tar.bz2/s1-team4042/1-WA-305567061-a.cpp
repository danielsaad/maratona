#include <bits/stdc++.h>
using namespace std;

int main(){

    int n, c;
    cin >> n >> c;

    int a[n] = {};
    for(int i=0;i<n;i++) cin >> a[i];

    while(c--){
        int x, y;
        cin >> x >> y;

        x--;

        a[x] += y;
    }

    int dp[n+1] = {};
    dp[0] = 1;
    for(int i=1;i<n;i++){
        if(a[i] < a[i-1]) dp[i] = dp[i-1] + 1;
        else dp[i] = 1;
    }

    for(int i=0;i<n-1;i++) cout << dp[i] << endl;

    return 0;
}
