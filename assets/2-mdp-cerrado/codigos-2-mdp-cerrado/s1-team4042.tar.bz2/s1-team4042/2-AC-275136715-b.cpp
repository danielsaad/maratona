#include <bits/stdc++.h>
#include <math.h>
using namespace std;

int main(){

    double x;
    cin >> x;

    if(x == 45) cout << "Ambos" << endl;
    else if(x < 45) cout << "Costa" << endl;
    else if (x > 45) cout << "Saad" << endl;
    return 0;
}
