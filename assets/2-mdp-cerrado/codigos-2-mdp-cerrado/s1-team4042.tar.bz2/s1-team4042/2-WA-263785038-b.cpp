#include <bits/stdc++.h>
#include <math.h>
using namespace std;

int main(){

    int x;
    cin >> x;

    if(x == 45) cout << "Ambos" << endl;
    else if(cos(x) > sin(x)) cout << "Costa" << endl;
    else if (cos(x) < sin(x)) cout << "Saad" << endl;

    return 0;
}
