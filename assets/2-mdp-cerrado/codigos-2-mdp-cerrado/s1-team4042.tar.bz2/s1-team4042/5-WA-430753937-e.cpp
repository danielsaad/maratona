#include <bits/stdc++.h>
using namespace std;


#define int long long
vector<int> primes;

signed main(){
    int n;
    cin >> n;

    int a[n] = {};

    for(int i=0;i<n;i++){
        cin >> a[i];
    }

    for(int i=2;i<=7000;i++){

        bool isPrime = true;

        for(int j=2;j*j<=i;j++){
            if(i % j == 0) isPrime = false;
        }

        if(!isPrime) continue;
        
        primes.push_back(i);
    }


    vector<int> acc(7001, 0);

    for(int i=0;i<n;i++){

        for(int p: primes){
            while(a[i] % p == 0){
                a[i]/=p;
                acc[p]++;
            }
        }
    }

    vector<int> fraq;
    for(int i=0;i<n;i++){
        if(a[i] > 1) fraq.push_back(a[i]);
    }

    for(int i=2;i<=7000;i++){
        int cur = acc[i] * i;

        if(cur > 0) fraq.push_back(cur);
    }

    sort(fraq.begin(), fraq.end(), greater<int>());

    int anss = 0;

    for(int i=0;i<fraq.size();i+=2){
        anss += fraq[i];
    }

    cout << anss << endl;

    return 0;
}
