#include <bits/stdc++.h>
using namespace std;

int main(){
    string horarioIni, horarioFim;
    cin >> horarioFim >> horarioIni;

    string hInicio, hFim, mInicio, mFim;
    hInicio = horarioIni.substr(0, 2);
    hFim = horarioFim.substr(0, 2);
    mInicio = horarioIni.substr(3, 5);
    mFim = horarioFim.substr(3, 5);
    
    int nHFim = stoi(hFim), nHIni = stoi(hInicio), nMIni = stoi(mInicio), nMFim = stoi(mFim);

    int hTotal, mTotal;

    if (nMIni > nMFim) {
        mTotal = (60 + nMFim) - nMIni;
        hTotal = nHFim - nHIni - 1;
    } else {
        mTotal = nMFim - nMIni;
        hTotal = nHFim - nHIni;
    }

    if (hTotal < 10) {
        cout << "0" << hTotal << ":";
    } else if (hTotal >= 10) {
        cout << hTotal << ":";
    }
    
    if (mTotal < 10) {
        cout << "0" << mTotal << endl;
    } else if (mTotal >=10) {
        cout << mTotal << endl;
    }

    return 0;
}
