#include <bits/stdc++.h>
using namespace std;

int main(){

    int n;
    cin >> n;

    string s;
    cin >> s;

    int dp[3][n+1] = {};

    if(s[0] == 'E'){
        dp[0][0] = 1;
    }
    else if(s[0] == 'D') dp[2][0] = 1;
    else dp[1][0] = 1;

    for(int i=1;i<n;i++){

        dp[1][i] = max(dp[0][i-1], dp[2][i-1]);
        dp[0][i] = dp[1][i-1];
        dp[2][i] = dp[1][i-1];

        if(s[i] == 'C'){
            dp[1][i]++;
        }
        else if(s[i] == 'E') dp[0][i]++;
        else dp[2][i]++;

    }

    cout << max(dp[0][n-1], max(dp[1][n-1], dp[2][n-1])) << endl;

    return 0;
}
