#include <bits/stdc++.h>
using namespace std;

int main(){

    int n, c;
    cin >> n >> c;

    int a[n] = {};
    for(int i=0;i<n;i++) cin >> a[i];

    int psum[n+1] = {};

    while(c--){
        int x, y;
        cin >> x >> y;

        x--;

        psum[x] += y;
    }

    a[n-1] += psum[n-1];

    for(int i=n-2;i>=0;i--){
        psum[i] += psum[i+1];
        a[i] += psum[i];
        
    }



    //for(int i=0;i<n;i++) a[i] = -a[i];
    
    set<int> s;
    int ans[n+1] = {};

    for(int i=0;i<=n;i++) {
        
        if(s.empty()){
            s.insert(a[i]);
        }
        else{
            while(!s.empty() && *s.begin() < a[i]) s.erase(s.begin());
            s.insert(a[i]);
        }
        
         ans[i] = s.size();
    }

    for(int i=0;i<n-1;i++) cout << ans[i] << endl;

    return 0;
}
