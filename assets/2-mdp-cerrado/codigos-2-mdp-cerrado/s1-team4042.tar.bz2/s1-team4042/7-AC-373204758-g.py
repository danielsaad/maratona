import re

reg_input = re.compile(r'\s*(.+) = (input)\(\)')
reg_loop_if = re.compile(r'(while|if) (.+):')
reg_print = re.compile(r'\s*(print)\((.*)\)')

def is_input_or_print(com):
    ans = ''
    if(reg_input.match(com)):
        [var, _] = reg_input.findall(com)[0]
        ans = f'LEIA {var}'
    elif (reg_print.match(com)):
        [_, var] = reg_print.findall(com)[0]        
        ans = f'APRESENTE {var}'
    return ans


com1 = str(input())
if (reg_loop_if.match(com1)):
    com2 = str(input())
    ans2 = is_input_or_print(com2)
    [comando, cond] = reg_loop_if.findall(com1)[0]
    if (comando == 'if'):
        print(f'SE {cond} ENTAO {ans2}')
    else:
        print(f'ENQUANTO {cond} {ans2}')
else:
    print(is_input_or_print(com1))

