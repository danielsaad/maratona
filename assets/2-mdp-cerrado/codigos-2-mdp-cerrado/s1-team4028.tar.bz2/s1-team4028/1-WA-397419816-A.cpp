#include <bits/stdc++.h>

#define int long long
using namespace std;

int32_t main(){
    ios::sync_with_stdio(NULL);cin.tie(0);cout.tie(0); 
    
    int n;
    cin >> n;

    int predios[n];
    int acc[n];

    int tapados[n];

    int c;
    cin >> c;

    for(int i = 0; i < n; i++){
        cin >> predios[i];
    }

    for(int i = 0; i < c; i++){
        int a, v;
        cin >> a >> v;

        for(int j = 0; j < a; j++){
            predios[j] += v;
        }
    }

    int maior_global = 0;
    acc[0] = 0;
    tapados[0] = 0;

    for(int i = 1; i < n; i++){
        acc[i] = (i - maior_global) - tapados[i - 1];
        
        cout << acc[i] << endl;

        if(predios[i] >= predios[maior_global]){
            maior_global = i;
            tapados[i] = 0;
        }
        if(maior_global != i){
            if(predios[i] >= predios[i - 1])
                tapados[i] = tapados[i - 1] + 1; 
            else
                tapados[i] = tapados[i - 1];
        }
    }
    
}