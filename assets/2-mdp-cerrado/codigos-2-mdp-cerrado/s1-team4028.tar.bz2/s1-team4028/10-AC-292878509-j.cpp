#include <bits/stdc++.h>

#define int long long
using namespace std;

int32_t main(){
    ios::sync_with_stdio(NULL);cin.tie(0);cout.tie(0); 
    int N;
    cin >> N;
    vector<char> S;
    for(int i=0;i<N;i++){
        char c;
        cin >> c;
        S.push_back(c);
    }
    int count=0;
    char P='C';
    for(int i=0;i<S.size();i++){
        if(P=='C'){
            count++;
            P=S[i];
        }else if(P=='D'){
            if(S[i]=='D' || S[i]=='C') count++;
            if(S[i]=='C' || S[i]=='E') P='C';
        }else{
            if(S[i]=='E' || S[i]=='C') count++;
            if(S[i]=='C' || S[i]=='D') P='C';
        }
    }
    cout << count << endl;
}