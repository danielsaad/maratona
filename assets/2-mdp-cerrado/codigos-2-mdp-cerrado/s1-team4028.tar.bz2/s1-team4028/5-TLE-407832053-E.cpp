#include <bits/stdc++.h>

#define int long long

using namespace std;

map<int,int> fat_count;

vector<int> num(10000001,0);
vector<int> primais;

void primos(int X){
    num[0]=1;
    num[1]=1;
    for(int i=2;i<=X;i++){
        if(num[i]==0){ 
            primais.push_back(i);
            for(int j=i+i;j<=X;j+=i) num[j]=1;
        }
    }
    return;
}

void fatorar(int X){
    for(int i=0;i<primais.size();i++){
        while(X%primais[i]==0){
            X/=primais[i];
            fat_count[primais[i]]++;
        }
    }
}

int32_t main(){
    ios::sync_with_stdio(NULL);cin.tie(0);cout.tie(0); 
    vector<int> V;
    int N;
    cin >> N;
    int Max=0;
    for(int i=0;i<N;i++){
        int X;
        cin >> X;
        V.push_back(X);
        Max=max(Max,X);
    }
    primos(Max);
    

    for(int i=0;i<V.size();i++) fatorar(V[i]);
    
    priority_queue<pair<int,int>> vet_final;
    
    for(int i=0;i<primais.size();i++) vet_final.push({fat_count[primais[i]],primais[i]});
    
    int soma=0;
    int vez=1;
    while(!vet_final.empty()){
        
        int C=vet_final.top().first;
        int prim=vet_final.top().second;
        vet_final.pop();
        if(vez==1) soma+=C*prim;
        vez*=-1;
    }
    cout << soma << endl;
    
}