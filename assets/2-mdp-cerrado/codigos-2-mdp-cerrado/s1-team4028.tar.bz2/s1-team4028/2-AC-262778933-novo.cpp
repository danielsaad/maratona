#include <bits/stdc++.h>

#define int long long
#define ios_base::sync_with_stdio(NULL);cin.tie(0);cout.tie; faster
using namespace std;

int32_t main(){
    ios::sync_with_stdio(NULL);cin.tie(0);cout.tie(0);
    int a;
    cin >> a;

    if(a < 45)
        cout << "Costa" << endl;
    else if (a == 45)
    {
        cout << "Ambos" << endl;
    }
    else{
        cout << "Saad" << endl;
    }
    
}