#include <bits/stdc++.h>

#define int long long
using namespace std;

int32_t main(){
    ios::sync_with_stdio(NULL);cin.tie(0);cout.tie(0); 
    string A,B;
    cin >> A >> B;
    int HF = (A[0]-'0')*10+(A[1]-'0'),MF=(A[3]-'0')*10+(A[4]-'0');
    int HA = (B[0]-'0')*10+(B[1]-'0'),MA=(B[3]-'0')*10+(B[4]-'0');
    int HT=0,MT=0;
    if(MA>MF){
        HT++;
        MF+=60;
    }
    HT=HF-HA;
    MT=MF-MA;
    cout << HT;
    if(HT<10) cout << "0";
    cout << ":" << MT;
    if(MT<10) cout << "0";
    cout << endl;
}