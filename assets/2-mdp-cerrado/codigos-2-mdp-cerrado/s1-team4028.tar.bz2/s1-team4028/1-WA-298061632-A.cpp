#include <bits/stdc++.h>

#define int long long
using namespace std;

int32_t main(){
    ios::sync_with_stdio(NULL);cin.tie(0);cout.tie(0); 
    
    int n;
    cin >> n;

    int predios[n];
    int max[n];
    max[0] = 1;

    int c;
    cin >> c;

    for(int i = 0; i < n; i++){
        cin >> predios[i];
    }

    for(int i = 0; i < c; i++){
        int a, v;
        cin >> a >> v;

        for(int j = 0; j < a; j++){
            predios[j] += v;
        }
    }

    for(int i = 1; i < n; i++){
        cout << max[i - 1] << endl;

        if(predios[i - 1] <= predios[i])
            max[i] = 1;
        else{
            max[i] = max[i - 1] + 1;
        }
    }
}