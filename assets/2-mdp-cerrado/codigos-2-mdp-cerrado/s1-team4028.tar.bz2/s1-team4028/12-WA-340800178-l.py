def sol():
    N = int(input())

    n = 1
    i, a = 1, 1
    n_max = N + 2
    
    def pergunta(i, n, v):
        print(f"? {i + n + v}", flush=True)
        a = int(input())

        return a
    
    while True:
        a = pergunta(i, n, 0)
        if a == 0:
            a = pergunta(i, n, 1)

            if a == 0:
                break

            i = i + n + 1
            n += 1

            if n + 1 == n_max:
                break
        else:
            i = i + n
            n += 1

            if n + 1 == n_max:
                break
    print(f"! {i}")

sol()