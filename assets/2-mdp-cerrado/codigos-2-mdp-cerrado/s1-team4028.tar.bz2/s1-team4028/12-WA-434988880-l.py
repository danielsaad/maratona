def sol():
    N = int(input())

    i, a = 1, 1
    n_max = N + 2

    n_elem = int(n_max * (n_max - 1) / 2)

    i = n_elem
    n = n_max - 1
    
    def pergunta(i):
        print(f"? {i}", flush=True)
        a = int(input())

        return a
    
    while True:
        a = pergunta(i)
        if a == 0:
            a = pergunta(i - 1)

            if a == 0:
                i = i - (n_max - 1)
                break
            i = i - 1

            if n + 1 == n_max:
                break
        else:
            break
    print(f"! {i}")

sol()