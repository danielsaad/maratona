from collections import deque, defaultdict, Counter

n, c = input().split(" ")
predios = list(input().split(" "))
n = int(n)
c = int(c)

upgrades = [0 for i in range(n)]

for u in range(c):
    indice, upgrade = input().split(" ")
    upgrades[int(indice) - 1] += int(upgrade)

ans = []

for i in range(len(predios)):
    predios[i] = int(predios[i]) + upgrades[i]


for i in range(len(predios)-1, 0, -1):
    cur_avista = 0
    cur_maior = 0
    for j in range(i-1,-1,-1):
        if (predios[j]>cur_maior):
            cur_avista += 1
            cur_maior = predios[j]

    ans.append(cur_avista)

for num in ans[::-1]:
    print(f"{num}")
