# Base
import sys
from collections import deque, defaultdict, Counter
from bisect import bisect_left, bisect_right
from heapq import heappush, heappop
from math import gcd, isqrt, floor, ceil, factorial
from itertools import permutations, combinations, product

# Files
from pathlib import Path
import json
import csv

h_final, m_final = input().split(":")
h_atual, m_atual = input().split(":")

h_atual = int(h_atual)
m_atual = int(m_atual)
h_final = int(h_final)
m_final = int(m_final)

h_atual *= 60
h_final *= 60

h_atual_min = h_atual + m_atual
h_final_min = h_final + m_final

diff = h_final_min - h_atual_min

div = int(diff / 60)
resto = diff % 60

div = str(div)
resto = str(resto)

n_div = len(div)
n_resto = len(resto)

if n_div == 1:
    div = "0" + div
if n_resto == 1:
    resto = "0" + resto
print(f"{div}:{resto}")
