
quantidade = int(input())

chutes = input()


def dfs(pos, defesas, i):
    if i == len(chutes):
        return defesas

    cur_chute = chutes[i]

    if cur_chute == pos:
        return dfs(pos, (defesas+1), i+1)
    elif (cur_chute == "E" and pos == "D") or (cur_chute == "D" and pos == "E"):
        return dfs("C", defesas, i+1)
    else:
        return dfs(cur_chute, (defesas +1), i+1)

    return 1

print(max(dfs("C", 0, 0), dfs("D", 0, 0), dfs("E", 0, 0)))


