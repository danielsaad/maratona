#include <bits/stdc++.h>

using namespace std;

int dfs(char pos, int defesas, int i, int n, string& chutes) {
	if (i == n)
		return defesas;

	char chute_atual = chutes[i];

	if (chute_atual == pos) {
		return dfs(pos, defesas+1, i+1, n, chutes);
	} else if (chute_atual == 'E' and pos == 'D' or chute_atual == 'D' and pos == 'E') {
		return dfs('C', defesas, i+1, n, chutes);
	} else {
		return dfs(chute_atual, defesas+1, i+1, n, chutes);
	}
	return 0;
}

void solve(int n) {
	string s;
	cin >> s;

	int count = max({dfs('C', 0, 0, n, s), dfs('E', 0, 0, n, s), dfs('D', 0, 0, n, s)});

	cout << count << "\n";
}

int main() {
	ios_base::sync_with_stdio(0);
	cin.tie(nullptr);
	
	int n;
	cin >> n;
	solve(n);

	return 0;
}
