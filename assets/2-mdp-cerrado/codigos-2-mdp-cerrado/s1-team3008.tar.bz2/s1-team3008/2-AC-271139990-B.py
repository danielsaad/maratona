# Base
import sys
from collections import deque, defaultdict, Counter
from bisect import bisect_left, bisect_right
from heapq import heappush, heappop
from math import gcd, isqrt, floor, ceil, factorial, cos, sin, pi
from itertools import permutations, combinations, product

# Files
from pathlib import Path
import json
import csv

n = int(input())
x = (n * pi) / 180
costa = cos(x)
saad = sin(x)

costa = f"{costa:.14}"
saad = f"{saad:.14}"

if n == 90:
    print("Saad\n")
else:
    if (costa > saad):
        print("Costa\n")
    elif (saad > costa):
        print("Saad\n")
    else:
        print("Ambos\n")