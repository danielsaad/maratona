#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = double;

#define int long long
#define vi vector<int>
#define endl '\n'


ll gauss(ll a){return a*(a+1)/2;}

void solve() {
    int n, c;
    cin >> n >> c;

    vi predios(n);
    vector<pair<int, int>> cons;

    for (int i = 0; i < n; i++) cin >> predios[i];
    for (int i = 0; i < c; i++) {
        int m, a;
        cin >> m >> a;
        cons.push_back({m,a});
    }

    int idx = 0;
    bool flag = false;

    if (cons[idx].first == 1) {
        predios[0] += cons[idx].second;
        idx++;
    }

    for (int i = 1; i < predios.size(); i++) {
        if (i+1 == cons[idx].first) {
            flag = true;
        }

        int visao = 0;
        int maior = 0;
        for (int j = i - 1; j >= 0; j--) {
            if (predios[j] > maior) {
                maior = predios[j];
                visao++;
            }
            if (flag) {
                predios[j] += cons[idx].second;
            }
        }

        cout << visao << endl;

        if (flag) {
            predios[i] += cons[idx].second;
            idx++;
            flag = false;
        }
    }
}


const bool TEST_CASES = 0;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int tc = 1;
    if (TEST_CASES) cin >> tc;

    while(tc--) {
        solve();
    }

    return 0;
}