#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = double;

#define int long long
#define vi vector<int>
#define endl '\n'


ll gauss(ll a){return a*(a+1)/2;}

void solve() {
    int n; cin >> n;
    string s; cin >> s;

    char pos = 'C';
    int pontos = 0;

    for (char c : s) {
        if (c == pos) {
            pontos++;
            continue;
        }
        if (pos == 'C') {
            pos = c;
            pontos++;
            continue;
        }
        if ((pos == 'E' && c == 'D') || (pos == 'D' && c == 'E')) {
            pos = 'C';
            continue;
        }
        if ((pos == 'E' || pos == 'D') && c == 'C') {
            pos = 'C';
            pontos++;
            continue;
        }
    }

    cout << pontos << endl;

}


const bool TEST_CASES = 0;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int tc = 1;
    if (TEST_CASES) cin >> tc;

    while(tc--) {
        solve();
    }

    return 0;
}