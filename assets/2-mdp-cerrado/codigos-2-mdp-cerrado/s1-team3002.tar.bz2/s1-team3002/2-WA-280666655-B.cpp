#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = double;

#define int long long
#define vi vector<int>
#define endl '\n'


ll gauss(ll a){return a*(a+1)/2;}

void solve() {
    int a;
    cin >> a;

    int b = sin(a) - cos(a);

    if (b == 0) {
        cout << "Ambos" << endl;
    } else if (b > 0) {
        cout << "Saad" << endl;
    } else {
        cout << "Costa" << endl;
    }
}


const bool TEST_CASES = 0;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int tc = 1;
    if (TEST_CASES) cin >> tc;

    while(tc--) {
        solve();
    }

    return 0;
}