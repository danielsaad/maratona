#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = double;

#define int long long
#define vi vector<int>
#define endl '\n'


ll gauss(ll a){return a*(a+1)/2;}

void solve() {
    int n, c;
    cin >> n >> c;

    vi predios(n);
    for (int i = 0; i < n; i++) cin >> predios[i];
    for (int i = 0; i < c; i++) {
        int m, a;
        cin >> m >> a;

        for (int j = 0; j < m; j++) {
            predios[j] += a;
        }
    }

    for (int i = 1; i < predios.size(); i++) {
        int visao = 0;
        int maior = 0;
        for (int j = i - 1; j >= 0; j--) {
            if (predios[j] > maior) {
                maior = predios[j];
                visao++;
            }
        }
        cout << visao << endl;
    }
}


const bool TEST_CASES = 0;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int tc = 1;
    if (TEST_CASES) cin >> tc;

    while(tc--) {
        solve();
    }

    return 0;
}