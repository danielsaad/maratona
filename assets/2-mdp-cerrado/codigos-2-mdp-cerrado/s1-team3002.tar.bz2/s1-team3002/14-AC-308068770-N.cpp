#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = double;

#define int long long
#define vi vector<int>
#define endl '\n'


ll gauss(ll a){return a*(a+1)/2;}

void solve() {
    string final;
    cin >> final;

    string horario1 = "";
    horario1.push_back(final[0]);
    horario1.push_back(final[1]);

    string minutos1 = "";
    minutos1.push_back(final[3]);
    minutos1.push_back(final[4]);

    int hora1 = stoll(horario1);
    int minuto1 = stoll(minutos1);

    string atual;
    cin >> atual;

    string horario2 = "";
    horario2.push_back(atual[0]);
    horario2.push_back(atual[1]);

    string minutos2 = "";
    minutos2.push_back(atual[3]);
    minutos2.push_back(atual[4]);

    int hora2 = stoll(horario2);
    int minuto2 = stoll(minutos2);

    int hora_final = hora1 - hora2;
    int minuto_final;

    if (minuto1 > minuto2) {
        minuto_final = minuto1 - minuto2;
    } else {
        hora_final--;
        minuto_final = (minuto1 + 60) - minuto2;
    }

    if (minuto_final >= 60) {
        minuto_final -= 60;
        hora_final++;
    }

    string hora;
    string minuto;

    if (hora_final < 10) {
        hora = "0" + to_string(hora_final);
    } else {
        hora = to_string(hora_final);
    }

    if (minuto_final < 10) {
        minuto = "0" + to_string(minuto_final);
    } else {
        minuto = to_string(minuto_final);
    }

    cout << hora << ":" << minuto << endl;
}


const bool TEST_CASES = 0;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int tc = 1;
    if (TEST_CASES) cin >> tc;

    while(tc--) {
        solve();
    }

    return 0;
}