#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ii pair<int, int>
#define vi vector<int>
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define endl '\n'
#define dbg(x) cout << #x << ' ' << x << endl
#define ff(n,m) for(int i = 0 ; i < n ; i++) for(int j = 0 ; j < m ; j++)
#define fastio ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
typedef vector<vector<int>> graph;

void esq(int& pos){
    if(pos > -1) pos--;
}
void cen(int& pos){
    pos = 0;
}
void dir(int& pos){
    if(pos < 1) pos++;
}

void solve(){
    int n, pos = 0, count = 0;
    cin >> n;
    string chutes;
    cin >> chutes;
    for(int i = 0; i < n; i++){
        if(chutes[i] == 'E'){
            esq(pos);
            if(pos == -1) count++;
        }
        if(chutes[i] == 'C'){
            cen(pos);
            if(pos == 0) count++;
        }
        if(chutes[i]== 'D'){
            dir(pos);
            if(pos == 1) count++;
        }
    }
    cout << count << '\n';
}

signed main(){
    fastio;
    int t = 1; 
    //cin >> t;
    while(t--) solve();
    return 0;
}