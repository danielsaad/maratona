#include <bits/stdc++.h>
using namespace std;
#define int long long
#define ii pair<int, int>
#define vi vector<int>
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define endl '\n'
#define dbg(x) cout << #x << ' ' << x << endl
#define ff(n,m) for(int i = 0 ; i < n ; i++) for(int j = 0 ; j < m ; j++)
#define fastio ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
typedef vector<vector<int>> graph;

vi update(vi v, int n){
    vi delta(v.size(), 0);
    for(int i = 0; i < n; i++){
        int m, h;
        cin >> m >> h;
        delta[0] += h;
        if(m < v.size()) delta[m] -= h;
    }
    vi psum(v.size(), 0);
    psum[0] = delta[0];

    for(int i = 1 ; i < v.size() ; i++){
        psum[i] = psum[i-1] + delta[i];
    }


    for(int i = 0 ; i < v.size() ; i++){
        v[i] += psum[i];
    }

    return v;
}

void solve(){
    int n, c;
    cin >> n >> c;
    vi aux(n);
    for(int i = 0; i < n; i++)
        cin >> aux[i];

    vi v = update(aux, c);

    int maior = 0, index = -1;

    for(int i = 1 ; i < v.size() ; i++){
        if(v[i-1] >= maior){
            maior = v[i-1]; index = i-1;
        }
        cout << i - index << endl;
    }

}

signed main(){
    fastio;
    int t = 1; 
    //cin >> t;
    while(t--) solve();
    return 0;
}