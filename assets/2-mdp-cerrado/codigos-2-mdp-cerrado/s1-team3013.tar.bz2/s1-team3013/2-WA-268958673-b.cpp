#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ii pair<int, int>
#define vi vector<int>
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define endl '\n'
#define dbg(x) cout << #x << ' ' << x << endl
#define ff(n,m) for(int i = 0 ; i < n ; i++) for(int j = 0 ; j < m ; j++)
#define fastio ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
typedef vector<vector<int>> graph;

void solve(){
    double n; cin >> n;

    if(sin(n) > cos(n)) cout << "Saad" << endl;
    else if(sin(n) == cos(n)) cout << "Ambos" << endl;
    else cout << "Costa" << endl;
}

signed main(){
    fastio;
    int t=1;
    while(t--) solve();
    return 0;
}