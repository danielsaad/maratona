#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define ii pair<int, int>
#define vi vector<int>
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define endl '\n'
#define dbg(x) cout << #x << ' ' << x << endl
#define ff(n,m) for(int i = 0 ; i < n ; i++) for(int j = 0 ; j < m ; j++)
#define fastio ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
typedef vector<vector<int>> graph;

vi v(10e7, 0);

void factors(int n){
    vector<ii> ans;
    if(n%2 == 0){
        ii p = mp(2, 0);
        while(n%2 == 0){
            p.second++;
            n /= 2;
        }
        ans.pb(p);
    }

    for(int i = 3 ;  i <= n ; i+= 2){
        if(n%i == 0){
            ii p = mp(i, 0);
            while(n%i == 0){
                p.second++;
                n /= i;
            }
            ans.pb(p);
        }
    }
    for(auto a : ans){
        v[a.first] += a.second;
    }

}

void solve(){
    int n, count = 0;
    cin >> n;
    int a[n];
    for(int i = 0; i < n; i++){
        cin >> a[i];
    }
    for(auto i : a){
        factors(i);
    }

    vi v2;
    for(int i = 0 ; i < v.size() ; i++){
        if(v[i] != 0) v2.pb(i * v[i]);
    }

    sort(v2.begin(), v2.end()); reverse(v2.begin(), v2.end());
    int i = 0;

    while(i < v2.size()){
        if(i % 2 == 0) count += v2[i];
        i++;
    }
    
    cout << count << '\n';
}

signed main(){
    fastio;
    int t = 1;
    while(t--) solve();
    return 0;
}