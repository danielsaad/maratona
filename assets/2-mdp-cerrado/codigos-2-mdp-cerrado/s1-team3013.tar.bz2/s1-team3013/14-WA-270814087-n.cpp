#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ii pair<int, int>
#define vi vector<int>
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define endl '\n'
#define dbg(x) cout << #x << ' ' << x << endl
#define ff(n,m) for(int i = 0 ; i < n ; i++) for(int j = 0 ; j < m ; j++)
#define fastio ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
typedef vector<vector<int>> graph;

void solve(){
    int h1, m1, h2, m2;
    scanf("%d:%d", &h1, &m1); scanf("%d:%d",&h2, &m2);

    int hf = h1 - h2;
    int mf = m1 - m2;

    if(mf < 0){
        mf += 60;
        h1 --;
    }

    if(hf < 10) cout << 0;
    cout << hf << ':';
    if(mf < 10) cout << 0;
    cout << mf << endl;
}

signed main(){
    fastio;
    int t = 1;
    while(t--) solve();
    return 0;
}