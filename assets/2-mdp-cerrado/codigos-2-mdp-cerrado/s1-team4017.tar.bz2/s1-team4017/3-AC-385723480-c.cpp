#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N=2e5+5;
const int INFLL=1000000000000000010;

int w[N], z[5*N], marc[5*N];

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    
    string s, t;
    cin>>s>>t;

    int n = s.size();
    int m = t.size();

    for(int i = 0; i < n; i++) {
        cin>>w[i];
    }

    string ss;
    for(int i = 0; i < n; i+=m)
        ss += t;

    ss.push_back('#');
    int k = ss.size();

    for(int i = 0; i < 2*max(n, m); i+=n)
        ss += s;

    int nn = ss.size();

    int l = 0, r = 0;
    for(int i = 1; i < nn; i++) {
        if(i > r) {
            l = i, r = i;
            while(r < nn && ss[r] == ss[r-l])
                r++;
            z[i] = r-l;
            r--;
            continue;
        }

        if(i + z[i-l] <= r) {
            z[i] = z[i-l];
            continue;
        }

        l = i;
        while(r < nn && ss[r] == ss[r-l])
            r++;
        z[i] = r-l;
        r--;
    }

    int resp = 0;
    for(int i = k; i < nn; i++) {
        if(marc[i])
            continue;

        int exp = z[i] / m;

        if(exp * m >= n) {
            cout<<"-1\n";
            return 0;
        }

        int sc = 0;
        for(int j = 0; j < exp; j++) {
            sc += w[(i+j*m-k)%n];
            marc[i+j*m] = 1;
        }

        resp = max(resp, sc);
    }
    cout<<resp<<"\n";

    return 0;
}