#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N = 1e7+5;

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n,ans=0,cur=0;
    string s;

    cin >> n >> s;
    for(int i=0;i<n;i++)
    {
        if(s[i]=='C')
            cur=0;
        if(s[i]=='E' && cur>=0)
            cur--;
        if(s[i]=='D' && cur<=0)
            cur++;
        ans+=(cur==-1 && s[i]=='E');
        ans+=(cur==0 && s[i]=='C');
        ans+=(cur==1 && s[i]=='D');
    }
    cout << ans << endl;

    return 0;
}