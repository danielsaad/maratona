#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N = 1e7+5;

bool Prefix(string t, string s) // t eh prefixo de s
{
    if((int)(s.size())<(int)(t.size())) return false;
    for(int i = 0;i < (int)(t.size());i++)
        if(s[i]!=t[i])
            return false;
    return true;
}
bool Solv(string s)
{
    reverse(s.begin(), s.end());
    if(Prefix(")(tupni",s))
    {
        reverse(s.begin(), s.end());
        cout << "LEIA ";
        for(int i = 0;s[i]!=' ';i++) cout << s[i];
        cout << endl;
        return false;
    }
    reverse(s.begin(), s.end());
    if(Prefix("print(",s))
    {
        cout << "APRESENTE ";
        for(int i = 6;s[i]!=')';i++) cout << s[i];
        cout << endl;
        return false;
    } 
    if(Prefix("if",s) && s.back()==':')
    {
        cout << "SE ";
        for(int i = 3;s[i]!=':';i++) cout << s[i];
        cout << " ENTAO ";
        return true;
    }
    if(Prefix("while",s) && s.back()==':')
    {
        cout << "ENQUANTO ";
        for(int i = 6;s[i]!=':';i++) cout << s[i];
        cout << " ";
        return true;
    }
    assert(false);
    return false;
}

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    string s;
    getline(cin, s);
    if(Solv(s))
    {
        getline(cin, s);
        /*
        reverse(s.begin(), s.end());
        for(int i = 0;i < 4;i++) s.pop_back();
        reverse(s.begin(), s.end());
        */
        if(Solv(s)) assert(false);
    }

    return 0;
}