#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N=1e5+5;
const int INFLL=1000000000000000010;

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n,cur=1,lvl=1;

    cin >> n;
    int lim=(n+1)*(n+2)/2;
    vector<int>possib;
    while(1)
    {
        if(cur+lvl>lim)
            break;
        cout << "? " << cur+lvl << endl;
        int x;
        cin >> x;
        cur+=lvl+(bool)(!x);
        possib.push_back(cur);
        lvl++;
    }
    int ans=1;
    int l=0;
    int r=(int)(possib.size())-1;    
    while(l<=r)
    {
        int mid=((l+r)>>1);
        cout << "? " << possib[mid] << endl;
        int x;
        cin >> x;
        if(x)
        {
            ans=possib[mid];
            l=mid+1;
        }else
        {
            r=mid-1;
        }
    }
    cout << "! " << ans << endl;

    return 0;
}