#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N=1e5+5;
const int INFLL=1000000000000000010;

int v[N];
int sum[N];

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n,q;

    cin >> n >> q;
    for(int i=1;i<=n;i++)
        cin >> v[i];
    while(q--)
    {
        int r,x;
        cin >> r >> x;
        sum[1]+=x;
        sum[r+1]-=x;
    }
    int s=0;
    for(int i=1;i<=n;i++)
    {
        s+=sum[i];
        v[i]+=s;
    }
    stack<int>cur;
    cur.push(INFLL);
    for(int i=1;i<n;i++)
    {
        int x=v[i];
        while(x>=cur.top())
            cur.pop();
        cur.push(x);
        cout << (int)(cur.size())-1 << endl;
    }

    return 0;
}