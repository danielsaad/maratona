#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N = 1e7+5;
const int MOD = 998244353;

int fexp(int x, int k) {
    int r = 1;
    for(int i = 30; i >= 0; i--) {
        r = r*r % MOD;
        if(k & (1<<i))
            r = r*x % MOD;
    }
    return r;
}

int inv(int x) {
    return fexp(x, MOD-2);
}

struct matriz {
    int m[2][2];

    matriz() {
        for(int i = 0; i < 2; i++)
            for(int j = 0; j < 2; j++)
                m[i][j] = 0;
    }

    matriz operator * (matriz b) {
        matriz c;
        for(int i = 0; i < 2; i++)
            for(int j = 0; j < 2; j++)
                for(int k = 0; k < 2; k++)
                    c.m[i][j] = (c.m[i][j] + m[i][k]*b.m[k][j]) % MOD;
        return c;
    }
};

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    
    int T;
    cin>>T;

    while(T--) {
        int a, b, n, m, v, u;
        cin>>a>>b>>n>>m>>v>>u;

        matriz mat, r;
        mat.m[0][0] = 0;
        mat.m[1][0] = 1;
        mat.m[0][1] = b;
        mat.m[1][1] = a;
        r.m[0][0] = 1;
        r.m[1][0] = 0;
        r.m[0][1] = 0;
        r.m[1][1] = 1;

        for(int i = 30; i >= 0; i--) {
            r = r*r;
            if((m-n) & (1<<i))
                r = r*mat;
        }

        int v_;
        bool flag = true;
        if(r.m[0][1]) {
            v_ = (u - r.m[1][1]*v%MOD + MOD) % MOD * inv(r.m[0][1]) % MOD;
        }
        else if(r.m[1][0]) {
            flag = false;
            v_ = (u - r.m[0][0]*v%MOD + MOD) % MOD * inv(r.m[1][0]) % MOD;
        }
        else
            assert(false);

        mat.m[0][0] = 0;
        mat.m[1][0] = 1;
        mat.m[0][1] = inv(b);
        mat.m[1][1] = (MOD-a)*inv(b) % MOD;
        r.m[0][0] = 1;
        r.m[1][0] = 0;
        r.m[0][1] = 0;
        r.m[1][1] = 1;

        int exp = flag ? n-1 : n;
        for(int i = 30; i >= 0; i--) {
            r = r*r;
            if(exp & (1<<i))
                r = r*mat;
        }

        int f0, f1;
        if(flag) {
            f0 = (r.m[0][1]*v + r.m[1][1]*v_) % MOD;
            f1 = (r.m[0][0]*v + r.m[1][0]*v_) % MOD;
        }
        else {
            f0 = (r.m[0][1]*v_ + r.m[1][1]*v) % MOD;
            f1 = (r.m[0][0]*v_ + r.m[1][0]*v) % MOD;
        }

        cout<<f0<<" "<<f1<<"\n";
    }

    return 0;
}