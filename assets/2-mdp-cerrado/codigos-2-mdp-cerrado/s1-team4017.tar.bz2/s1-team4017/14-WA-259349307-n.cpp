#include <bits/stdc++.h>
using namespace std;


int32_t main() {
    int a, b, c, d;
    scanf("%d:%d", &a, &b);
    scanf("%d:%d", &c, &d);

    if(d < b)
        d += 60, c--;

    if(a > c)
        c += 24;

    cout<<(c-a<10?"0":"")<<(c-a)<<":";
    cout<<(d-b<10?"0":"")<<(d-b)<<"\n";
}