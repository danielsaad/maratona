#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N = 1e7+5;

int lp[N];
vector<int> primes;
int freq[N];
int vet[N];

void Sieve()
{
    for(int i = 2;i < N;i++)
    {
        if(!lp[i])
        {
            lp[i] = i;
            primes.push_back(i);
        }
        for(int j = 0;i*primes[j] < N;j++)
        {
            lp[i*primes[j]] = primes[j];
            if(primes[j]==lp[i]) break;
        }
    }
    return;
}

vector<pii> Fatorar(int n)
{
    vector<pii> fat;
    while(n!=1)
    {
        int k = lp[n];
        fat.push_back({k,0});
        while(lp[n]==k) fat.back().second++, n /= k;
    }
    return fat;
}

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    Sieve();

    int n;
    cin >> n;
    while(n--)
    {
        int x;
        cin >> x;
        for(auto [a,b] : Fatorar(x)) freq[a] += a*b;
    }
    n = 0;
    vector<int> v;
    for(int i = 0;i < N;i++)    
        if(freq[i])
            vet[n++] = freq[i];
    sort(vet, vet+n, greater<int>());
    int ans = 0;
    for(int i = 0;i < n;i += 2) ans += vet[i];
    cout << ans << endl;
    return 0;
}