#include <bits/stdc++.h>
using namespace std;

const double EPS=10e-6;

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int x;

    cin >> x;
    double s=sin(x);
    double c=cos(x);
    if(fabs(s-c)<EPS)
    {
        cout << "Ambos" << endl;
    }else
    {
        cout << (s<c ? "Costa" : "Saad") << endl;
    }

    return 0;
}