#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N=1e5+5;
const int INFLL=1000000000000000010;

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n,cur=1,lvl=1;

    cin >> n;
    while(1)
    {
        cout << "? " << cur+lvl << endl;
        int x;
        cin >> x;
        if(x)
        {
            cur=cur+lvl;
            lvl++;
            continue;
        }
        cout << "? " << cur+lvl+1 << endl;
        cin >> x;
        if(x)
        {
            cur=cur+lvl+1;
            lvl++;
            continue;
        }
        cout << "! " << cur << endl;
        break;
    }

    return 0;
}