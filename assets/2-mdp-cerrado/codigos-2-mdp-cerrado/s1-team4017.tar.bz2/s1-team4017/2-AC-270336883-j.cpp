#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N = 1e7+5;

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int x;

    cin >> x;
    if(x<45)
        cout << "Costa" << endl;
    else if(x>45)
        cout << "Saad" << endl;
    else
        cout << "Ambos" << endl;

    return 0;
}