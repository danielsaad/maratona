#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N=1e5+5;
const int INFLL=1000000000000000010;

char p[25];
vector<string> resp;

void solve(int n, char orig, char dest, char aux) {
    if(!n)
        return;

    if(p[n] == dest) {
        solve(n-1, orig, dest, aux);
        return;
    }

    char c = p[n];
    if(c == orig)
        solve(n-1, orig, aux, dest);
    else
        solve(n-1, aux, orig, dest);
        
    string s;
    s.push_back(c);
    s.push_back(' ');
    s.push_back(dest);
    resp.push_back(s);
    p[n] = dest;
    
    if(c == orig)
        solve(n-1, aux, dest, orig);
    else
        solve(n-1, orig, dest, aux);
}

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    
    int n;
    cin>>n;

    for(char c = 'A'; c <= 'C'; c++) {
        int k;
        cin>>k;

        for(int i = 1; i <= k; i++) {
            int x;
            cin>>x;

            p[x] = c;
        }
    }

    solve(n, 'A', 'B', 'C');

    cout<<resp.size()<<"\n";
    for(auto s : resp)
        cout<<s<<"\n";

    return 0;
}