#include <bits/stdc++.h>
using namespace std;

#define int long long
typedef pair<int,int> pii;

const int N=1e5+5;
const int INFLL=1000000000000000010;

int32_t main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, q;
    cin >> n >> q;
    string s;
    cin >> s;

    int x = 0;
    while(x<n && s[x]==s[0]) x++;

    while(q--)
    {
        string t;
        cin >> t;
        int m = (int)(t.size());
        int y = 0;
        while(y<m && t[y]==t[0]) y++;
        int ans = n+m;
        if(s[0]==t[0]) ans -= min(x,y);
        cout << ans << "\n";
    }

    return 0;
}