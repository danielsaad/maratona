#include <bits/stdc++.h>
using namespace std;

string fun(string linha){
    stringstream ss(linha);
    string palavra;
    string ans;
    while(ss>>palavra){
        if(palavra=="if"){
            string exp;
            exp = linha.substr(palavra.size()+1);
            exp.pop_back();
            ans+="SE "+exp+" ENTÃO ";
            string ent;
            getline(cin,ent);
            return ans+=fun(ent);
        }
        else if(palavra=="while"){
            string exp;
            exp = linha.substr(palavra.size()+1);
            exp.pop_back();
            ans+="ENQUANTO "+exp+' ';
            string ent;
            getline(cin,ent);
            return ans+=fun(ent);
        }
        else if(palavra.substr(0,6)==("print(")){
            string exp;
            exp=linha.substr(6);
            exp.pop_back();
            return ans+="APRESENTE " + exp;
        }
        else{
            
            ans+="LEIA " + palavra;
            return ans;
        }
    }
    return ans;
}

int main(){
    string linha;
    getline(cin,linha);
    string ans=fun(linha);
    cout<<ans<<'\n';
}