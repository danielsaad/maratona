#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
    int n, q;
    cin >> n >> q;
    vector<int> v(n+1), pref(n+1);
    for(int i = 0;i < n;i++)
        cin>>v[i];
    while(q--){
        int u, p;
        cin >> u >> p;
        pref[0] += p;
        pref[u] -= p;
    }
    v[0] += pref[0];
    for(int i = 1;i < n;i++){
        pref[i] += pref[i-1];
        v[i] += pref[i];
    }

    /*
    6 2
    6 11 120 200 20 7
    1 6
    3 81
    */

    vector<int> mai(n, 0), men(n, 0);
    int cma = 0, cme = 0;
    for(int i = 1; i < n; i++){
        if(v[i] < v[i-1]){
            mai[i] = ++cma;
            cme = 0;
        }
        else if(v[i] > v[i-1]){
            mai[i] = cma;
            cma = 0;
            men[i] = ++cme;
        }
    }
    for(int i = 1; i < n; i++){
        cout<<mai[i]+men[i]<<endl;
    }
}