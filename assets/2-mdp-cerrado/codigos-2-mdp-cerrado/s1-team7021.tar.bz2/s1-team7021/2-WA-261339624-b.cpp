#include <bits/stdc++.h>
using namespace std;
int main(){
    int a;
    cin >> a;

    double s = sin(a);
    double c = cos(a);
    if(c > s) cout<<"Costa\n";
    else if(c < s) cout<<"Saad\n";
    else cout<<"Ambos\n";
}