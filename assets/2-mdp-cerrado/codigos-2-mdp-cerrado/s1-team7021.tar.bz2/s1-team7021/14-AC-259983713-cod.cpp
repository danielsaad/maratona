#include <bits/stdc++.h>
using namespace std;
int main(){
    int a1,a2,b1,b2;
    char ch;
    cin>>a1>>ch>>b1;
    cin>>a2>>ch>>b2;

    int tota=a1*60+b1;
    int totb=a2*60+b2;

    int ans= abs(tota-totb);

    printf("%0*d:%0*d\n",2,(ans/60),2,(ans%60));
}