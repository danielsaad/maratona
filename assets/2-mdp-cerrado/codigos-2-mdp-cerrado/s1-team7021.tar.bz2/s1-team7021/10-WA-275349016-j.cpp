#include <bits/stdc++.h>
using namespace std;
int dp[200001][3];
int n;
string str, gol = "ECD";
int memo(int i, int p){
    if(i == n)return 0;
    if(dp[i][p] != -1)return dp[i][p];
    int ans = memo(i+1, 1) + (str[i] == gol[p]);
    if(p == 1){
        ans = max({ans, memo(i+1, 0) + (str[i] == gol[p]), memo(i+1, 2) + (str[i] == gol[p])});
    }else {
        ans = max(ans, memo(i+1, 1) + (str[i] == gol[p]));
    }
    return dp[i][p] = ans;
}
int main(){
    memset(dp, -1, sizeof dp);
    cin >> n;
    cin >> str;
    cout << max({memo(0, 0), memo(0, 1), memo(0, 2)}) << endl;
}