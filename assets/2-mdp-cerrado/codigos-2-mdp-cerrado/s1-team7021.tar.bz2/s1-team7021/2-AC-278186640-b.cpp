#include <bits/stdc++.h>
using namespace std;

int main(){
    int a;
    cin >> a;
    if(a==45) cout<<"Ambos\n";
    else if(a<45) cout<<"Costa\n";
    else cout<<"Saad\n";
}