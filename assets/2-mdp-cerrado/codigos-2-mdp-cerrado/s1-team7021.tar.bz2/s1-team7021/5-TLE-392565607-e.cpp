#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>
using namespace std;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    const int lim = 10000001;
    int divi[lim+1] = {0};

    for(int i = 2;i <= lim;i++)
        if(divi[i] == 0)
            for(int j = i;j <= lim;j += i)
                divi[j] = i;
    
    unordered_map<long long,long long> fact;

    int n;
    cin >> n;
    vector<int> v(n);
    for(int i = 0;i < n;i++){
        cin >> v[i];
    }
    int c=0;
    for(int i = 0;i < n;i++){
        int aux = v[i];
        c++;
        while(aux > 1){
            fact[divi[aux]]++;
            aux /= divi[aux];
        }
    }
    vector<long long> qtd;
    for(auto [i, j] : fact){
        qtd.emplace_back(i * j);
    }
    sort(qtd.rbegin(), qtd.rend());
    
    long long ans = 0;
    for(int i = 0;i < qtd.size();i += 2){
        ans += qtd[i];
    }

    cout << ans << endl;

}