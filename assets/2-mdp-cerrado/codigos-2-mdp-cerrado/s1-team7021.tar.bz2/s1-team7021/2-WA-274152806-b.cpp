#include <bits/stdc++.h>
using namespace std;

int main(){
    int a;
    cin >> a;
    if(cos(a) > sin(a)) cout<<"Costa\n";
    else if(cos(a) < sin(a)) cout<<"Saad\n";
    else cout<<"Ambos\n";
}