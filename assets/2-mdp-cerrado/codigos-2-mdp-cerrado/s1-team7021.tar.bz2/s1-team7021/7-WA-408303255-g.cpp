#include <bits/stdc++.h>
using namespace std;

string fun(string linha){
    stringstream ss(linha);
    string palavra;
    string ans;
    ss>>palavra;
    if(palavra=="if" and linha.back()==':'){
        string exp;
        exp = linha.substr(palavra.size()+1);
        exp.pop_back();
        ans+="SE "+exp+" ENTÃO ";
        string ent;
        getline(cin,ent);
        return ans+=fun(ent);
    }
    else if(palavra=="while" and linha.back()==':'){
        string exp;
        exp = linha.substr(palavra.size()+1);
        exp.pop_back();
        ans+="ENQUANTO "+exp+' ';
        string ent;
        getline(cin,ent);
        return ans+=fun(ent);
    }
    else if(palavra.substr(0,6)==("print(") && linha.back() == ')'){
        string exp;
        
        exp=linha.substr(6);
        exp.pop_back();
        reverse(exp.begin(),exp.end());
        while(exp.back()==' ' or exp.back()=='('){
            exp.pop_back();
        }
        reverse(exp.begin(),exp.end());

        
        return ans+="APRESENTE " + exp;
    }
    else if(linha.substr(linha.size()-10)==" = input()"){
        ans+="LEIA " + linha.substr(0,linha.size()-10);
        return ans;
    }
}

int main(){
    string linha;
    getline(cin,linha);
    string ans=fun(linha);
    cout<<ans<<'\n';
}