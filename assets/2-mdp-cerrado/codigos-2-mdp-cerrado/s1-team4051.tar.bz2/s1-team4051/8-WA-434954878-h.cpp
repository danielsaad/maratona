#include <bits/stdc++.h>
#define int long long
using namespace std;
#define faster ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define pii pair<int,int>
#define fi first 
#define se second 
#define NMAX 21
#define pb push_back

vector<pii>resp;
vector<int>v[4];
int id[NMAX];


void hanoi(int n, int ori, int dest){
    if(n==1){
        resp.pb({ori,dest});
        return;
    }
    hanoi(n-1,ori,ori^dest);
    resp.pb({ori,dest});
    hanoi(n-1,ori^dest,dest);
}

void arruma(int n, int ori, int dest){
    if(id[n]==dest)return;
    if(n==1){
        resp.pb({ori,dest});
        return;
    }

    while(v[dest].size()>0 && v[dest].back()<n){
        arruma(v[dest].back(),dest,ori^dest);
        id[v[dest].back()]=ori^dest;
        v[ori^dest].pb(v[dest].back());
        v[dest].pop_back();
    }

    while(v[ori].back()<n){
        arruma(v[ori].back(),ori,ori^dest);
        id[v[ori].back()]=ori^dest;
        v[ori^dest].pb(v[ori].back());
        v[ori].pop_back();
    }


    resp.pb({ori,dest});
}





int32_t main(){ faster  
    int n;
    cin>>n;
    for(int i=1; i<=3; i++){
        int k;
        cin>>k;
        int x;
        while(k--){
            cin>>x;
            id[x]=i;
            v[i].pb(x);
        }
        reverse(v[i].begin(),v[i].end());
        //for(auto it: v[i])cout<<it<<" ";
        //cout<<"\n";
    }
    int aqui=1;
    for(int i=n; i>=1; i--){
        arruma(i,id[i],2);

        int p=id[i];
    }
    cout<<resp.size()<<"\n";
    map<int,char>trad;
    trad[1]='A';
    trad[2]='B';
    trad[3]='C';
    for(auto it:resp){
        cout<<trad[it.fi]<<" "<<trad[it.se]<<"\n";
    }

}





