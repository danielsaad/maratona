#include <bits/stdc++.h>
#define int long long

using namespace std;

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, c;
    cin >> n >> c;

    vector<int> v(n + 1), rmv(n + 5);
    for(int i = 1; i <= n; i++)
        cin >> v[i];

    int sum = 0;
    for(int j = 0; j < c; j++) {
        int m, a;
        cin >> m >> a;
        rmv[m + 1] += a;
        sum += a;
    }
    
    stack<int> s;

    for(int i =1; i <= n; i++) {
        sum -= rmv[i];
        int x = v[i] + sum;
        if(i > 1)
            cout << s.size() << endl;
        while(s.size() && s.top() <= x)
            s.pop();
        s.push(x); 
    }
}