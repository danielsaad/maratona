#include <bits/stdc++.h>
using namespace std;

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, q;
    cin >> n >> q;

    string s;
    cin >> s;
    s.push_back('#');

    const int MAXN = 2e6 + 5;
    vector<int> z(MAXN);
    
    z[0] = s.size();
    
    int l = 0, r = 0;
    for(int i = 1; i < s.size(); i++) {
        if(i < r) z[i] = min(z[i - l], r - i);
        while(i + z[i] < s.size() && s[z[i]] == s[i + z[i]])
            z[i]++;

        if(i + z[i] > r) {
            l = i;
            r = z[i] + i;
        }
    }


    while(q--) {

        int laux = l, raux = r;
        string t;
        cin >> t;

        int ans = 0;
        for(int i = n+1, j = 0; j < t.size(); j++, i++) {
            z[i] = 0;
            if(i < r) z[i] = min(z[i - l], r - i);
            while(j + z[i] < t.size() && s[z[i]] == t[z[i]])
                z[i]++;
                
            if(i + z[i] > r) {
                l = i;
                r = z[i] + i;
            }
            
            ans = max(ans, n + (int)t.size() - j - z[i]);
        }   


        l = laux, r = raux;
        cout << ans << endl;
    }
}