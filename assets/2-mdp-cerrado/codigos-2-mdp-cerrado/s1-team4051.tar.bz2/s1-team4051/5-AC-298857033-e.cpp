#include <bits/stdc++.h>
#define int long long
using namespace std;

const int MAXN = 1e7 + 7;
vector<int> primes, lp(MAXN), aux(MAXN);

void sieve() {
    for(int i = 2; i < MAXN; i++) {

        if(!lp[i]) {
            lp[i] = i;
            aux[i] = primes.size();
            primes.push_back(i);
        }

        for(int &j : primes) {
            if(1LL * j * i >= MAXN)
                break;
            lp[j * i] = j;

            if(lp[i] == j)
                break;
        }
    }
}

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    sieve();

    int n;
    cin >> n;


    vector<long long> tot(primes.size() + 5);

    for(int i = 0; i < n; i++) {
        int x;
        cin >> x;
        while(x > 1) {
            int y = lp[x];
            while(x % y == 0) {
                tot[aux[y]] += y;
                x /= y;
            }
        }
    }
    sort(tot.begin(), tot.end(), greater<int>());

    long long ans = 0;
    for(int i = 0; i < tot.size(); i+=2)
        ans += tot[i];
    cout << ans << endl;
}