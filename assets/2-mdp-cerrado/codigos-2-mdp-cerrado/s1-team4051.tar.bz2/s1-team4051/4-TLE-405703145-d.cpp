#include <bits/stdc++.h>
using namespace std;

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, q;
    cin >> n >> q;

    string s;
    cin >> s;
    s.push_back('#');

    const int MAXN = 2e6 + 5;
    vector<int> z(MAXN);
    



    while(q--) {

        int l = 0, r = 0;
        string t;
        cin >> t;

        int ans = 0;
        for(int i = 0; i < t.size(); i++) {
            z[i] = 0;

            if(i < r) z[i] = min(z[i - l], r - i);
            while(i + z[i] < t.size() && s[z[i]] == t[i + z[i]])
                z[i]++;
                
            if(i + z[i] > r) {
                l = i;
                r = z[i] + i;
            }
            
            ans = max(ans, n + (int)t.size() - i - z[i]);
        }   


        cout << ans << endl;
    }
}