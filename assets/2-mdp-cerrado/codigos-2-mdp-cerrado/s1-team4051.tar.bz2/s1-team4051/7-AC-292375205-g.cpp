#include <bits/stdc++.h>
using namespace std;
#define faster ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long 
#define pb push_back

int32_t main() { //faster
    string s; 
    while(getline(cin,s)){
        if(s[0]=='i' && s[1]=='f' && s[2]==' '){
            string s3, s2;
            getline(cin,s3);
            bool prim=true;
            for(auto it:s3){
                if(prim && it==' ')continue;
                prim=false;
                s2.pb(it);
            }
            cout<<"SE ";
            for(int i=3; i<s.size()-1; i++)cout<<s[i];
            string aux=s2.substr(0,6);
            if(aux=="print("){
                cout<<" ENTAO APRESENTE ";
                for(int i=6; i<s2.size()-1; i++)cout<<s2[i];
                cout<<"\n";
            }
            else{
                cout<<" ENTAO LEIA ";
                for(int i=0; i<s2.size(); i++){
                    if(s2[i]=='=')break;
                    cout<<s2[i];
                }
                cout<<"\n";
            }
        }
        else{
            bool flag=true;
            string aux="while ";
            int id=0;
            for(auto it:s){
                if(it==aux[id]){
                    id++;
                    if(id==aux.size())break;
                }
                else{
                    flag=false;
                    break;
                }
            }

            if(flag){
                cout<<"ENQUANTO ";
                for(int i=6; i<s.size()-1; i++)cout<<s[i];
                string s3, s2;
                getline(cin,s3);
                bool prim=true;
                for(auto it:s3){
                    if(prim && it==' ')continue;
                    prim=false;
                    s2.pb(it);
                }
                string aux=s2.substr(0,6);
                if(aux=="print("){
                    cout<<" APRESENTE ";
                    for(int i=6; i<s2.size()-1; i++)cout<<s2[i];
                    cout<<"\n";
                }
                else{
                    cout<<" LEIA ";
                    for(int i=0; i<s2.size(); i++){
                        if(s2[i]=='=')break;
                        cout<<s2[i];
                    }
                    cout<<"\n";
                }

            }
            else{
                string aux=s.substr(0,6);
                if(aux=="print("){
                    cout<<"APRESENTE ";
                    for(int i=6; i<s.size()-1; i++)cout<<s[i];
                    cout<<"\n";
                }
                else{
                    cout<<"LEIA ";
                    for(int i=0; i<s.size(); i++){
                        if(s[i]=='=')break;
                        cout<<s[i];
                    }
                    cout<<"\n";
                }
            }
        }
    }
}