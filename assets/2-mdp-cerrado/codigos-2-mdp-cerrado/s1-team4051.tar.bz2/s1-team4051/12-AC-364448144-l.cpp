#include <bits/stdc++.h>
#define int long long
using namespace std;
#define pb push_back

vector<int>v[1003];
int lb[1003],rb[1003];

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n; cin >> n;
    int id = 1;
    for(int i=1;i<=n+2;i++){
        for(int j=1;j<=i;j++){
            v[i].pb(id++);
        }
        // cout << i << " = ";
        // for(auto j:v[i]) cout << j << " ";
        // cout << endl;
        lb[i] = v[i][0];
        rb[i] = v[i].back();
    }

    int l = 1, r = n+2;
    while(l<r){
        int m = (l+r+1)/2;
        int found = -1;
        
        if(m == n+2){ r = m-1; continue; }

        for(int j=lb[m];j<=rb[m];j++){
            cout << "? " << j << endl;
            int resp; cin >> resp;
            if(resp==1){ found = j; break; }
        }
        if(found == -1) r = m-1;
        else{
            l = m;
            int ll = m+found, rr = m+found+1;
            lb[m] = found, rb[m] = found;
            for(int i=m+1;i<=r;i++){
                lb[i] = ll, rb[i] = rr;
                ll = i+ll, rr = i+rr+1;
            }
        }
    }
    //cout << "nivel = " << l << " " << r << endl;
    if(lb[l]==rb[l]) cout << "! " << lb[l] << endl;
    else{
        for(int j=lb[l];j<=rb[l];j++){
            cout << "? " << j << endl;
            int resp; cin >> resp;
            if(resp==1){ cout << "! " << j << endl; break; }
        }
    }
}
/*
502
1 500

1 1002
*/