#include <bits/stdc++.h>
#define int long long
using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const int mod = (1LL<<61) - 1, B = uniform_int_distribution<int>(1023, mod - 1)(rng);

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, q;
    cin >> n >> q;

    string s;
    cin >> s;

    const int MAXN = 1e6 + 5;


    vector<int> hash(n), hash2(MAXN), p(MAXN);
    hash[0] = s[0];

    p[0] = 1;
    for(int i = 1; i < MAXN; i++)
        p[i] = (__int128_t)B * p[i - 1] % mod;

    for(int i = 1; i < n; i++)
        hash[i] = ((__int128_t)hash[i - 1] * B + s[i])%mod;

    auto getHash = [&](int sz) -> int {
        return hash[sz - 1];
    };

    auto getHash2 = [&](int l, int r) -> int {
        __int128_t ans = hash2[r];
        if(l)
            return (ans - ((__int128_t)hash2[l - 1] * p[r - l + 1])%mod + mod)%mod;
        return ans;
    };

    while(q--) {

        string t;
        cin >> t;

        int m = t.size();

        hash2[0] = t[0];
        for(int i = 1; i < m; i++)
            hash2[i] = ((__int128_t)hash2[i - 1] * B %mod + t[i])%mod;

        int res = 0;
        for(int i = 0; i < m; i++) {
            int ini = 1, mid, end = m - i, ans = 0;
            while(ini <= end) {
                mid = (ini + end) / 2;
                if(getHash(mid) == getHash2(i, i + mid - 1)) {
                    ans = max(ans, mid);
                    ini = mid + 1;
                }
                else end = mid - 1;
            }
            res = max(res, m - i + n - ans);
        
        }

        cout << res << endl;

    }
}