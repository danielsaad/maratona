#include <bits/stdc++.h>
#define int long long

using namespace std;

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;

    vector<vector<int>> dp(n + 1, vector<int>(3, -1e18));
    dp[0][1] = 0;
    for(int i = 1; i <= n; i++) {
        dp[i][0] = max(dp[i - 1][0], dp[i - 1][1]);
        dp[i][1] = max({dp[i - 1][0], dp[i - 1][1], dp[i - 1][2]});
        dp[i][2] = max({dp[i - 1][1], dp[i - 1][2]});

        char c;
        cin >> c;
        if(c == 'C')
            dp[i][1]++;
        else if(c == 'E')
            dp[i][0]++;
        else dp[i][2]++;
    }

    cout << max({dp[n][0], dp[n][1], dp[n][2]}) << endl;

}