#include <bits/stdc++.h>

using namespace std;

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;

    if(n == 45) {
        cout << "Ambos" << endl;
        return 0;
    }

    double a = sin(n/360.0 * 2.0 * acos(-1));
    double b = cos(n/360.0 * 2.0 * acos(-1));
    cout << (a >= b ? "Saad" : "Costa") << endl;
}