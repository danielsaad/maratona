#include <bits/stdc++.h>
#define int long long
using namespace std;

const int mod = 998244353;

int modExpo(int a, int p) {
    int ans = 1;
    while(p) {
        if(p & 1)
            ans = (ans * a) % mod;
        a = (a * a)%mod;
        p >>= 1;
    }
    return ans;
}

struct matrix {
    int n,m;
    vector<vector<int>> mat;

    matrix(int n_) {
        n = n_;
        m = n_;
        mat.resize(n, vector<int>(m));
    }

    void operator *=(matrix &a) {
        assert(m == a.n);
        matrix c(n);
        for(int i = 0; i < n; i++)
            for(int k = 0; k < m; k++) {
                if(!mat[i][k]) continue;
                for(int j = 0; j < a.m; j++) {
                    c.mat[i][j] = (1LL * mat[i][k] * a.mat[k][j])%mod + c.mat[i][j];

                    if(c.mat[i][j] >= mod)
                        c.mat[i][j] -= mod;
                }
            }

        mat = c.mat;
        return;
    }

    void operator ^= (int p) {
        assert(n == m);
        if(!p) {
            for(int i = 0; i < n; i++)
                for(int j = 0; j < n; j++)
                    mat[i][j] = (i == j);
            return;
        }

        matrix ans(n);
        ans ^= 0;

        matrix aux(n);
        aux.mat = mat;

        while(p) {
            if(p & 1)
                ans *= aux;

            aux *= aux;
            p >>= 1;
        }

        mat = ans.mat;
        return;
    }

    void print() {
        for(int i = 0; i < n; i++, cout << endl)
            for(int j = 0; j < n; j++)
                cout << mat[i][j] << " ";
    }

};



int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);


    int ct;
    cin >> ct;

    matrix c(2);


    while(ct--) {

        int a, b, n, m, vn, vm;
        cin >> a >> b >> n >> m >> vn >> vm;

        c.mat[0][0] = a;
        c.mat[0][1] = 1;
        c.mat[1][0] = b;
        c.mat[1][1] = 0;


        if(!n) {
            if(m == 1) {
                cout << vn << " " << vm << endl;
                continue;
            }

            int f0 = vn;

            c ^= m - 1;

            int am = c.mat[0][0], bm = c.mat[1][0];
            int f1 = (vm - (bm * f0)%mod + mod)%mod;
            f1 = (f1 * modExpo(am, mod - 2))%mod;

            cout << f0 << " " << f1 << endl;
            continue;
        }

        if(n == 1) {
            int f1 = vn;

            c ^= m - 1;

            int am = c.mat[0][0], bm = c.mat[1][0];
            int f0 = (vm - (am * f1)%mod + mod)%mod;
            f0 = (f0 * modExpo(bm, mod - 2))%mod;

            cout << f1 << endl;
            continue;

        }

        c ^= n - 1;
        int an = c.mat[0][0], bn = c.mat[1][0];

        c.mat[0][0] = a;
        c.mat[0][1] = 1;
        c.mat[1][0] = b;
        c.mat[1][1] = 0;

        c ^= m - 1;
        int am = c.mat[0][0], bm = c.mat[1][0];


        int aux = (vm * an)%mod;
        aux = (aux * modExpo(am, mod - 2)) % mod;
        aux = (vn - aux + mod)%mod;

        int dir = aux;

        aux = (an * bm)%mod;

        aux = (aux * modExpo(am, mod - 2))%mod;
        aux = (bn - aux + mod)%mod;

        int lef = aux;
        int f0 = (dir * modExpo(lef, mod - 2)) % mod;
        
        int f1 = (vn - (bn * f0)%mod + mod)%mod;
        f1 = (f1 * modExpo(an, mod - 2))%mod;

        cout << f0 << " " << f1 << endl;
    }

}