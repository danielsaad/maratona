#include <bits/stdc++.h>
#define int long long
using namespace std;

int32_t main() {
    string s, s2;
    cin >> s >> s2;

    char hd = s[0], hu = s[1], md = s[3], mu = s[4];    
    hd -= '0', hu -= '0', md -= '0', mu -= '0';
    int h = (10 * hd + hu) * 60 + (10 * md + mu);
    
    hd = s2[0], hu = s2[1], md = s2[3], mu = s2[4];    
    hd -= '0', hu -= '0', md -= '0', mu -= '0';

    int h2 = (10 * hd + hu) * 60 + (10 * md + mu);
    swap(h, h2);
    int ans = h2 - h;

    cout << ans/(10 * 60);
    ans %= (10 * 60);
    cout << ans/60;
    ans %= 60; 
    cout << ":";
    cout << ans/10;
    ans %= 10;
    cout << ans << endl;
}