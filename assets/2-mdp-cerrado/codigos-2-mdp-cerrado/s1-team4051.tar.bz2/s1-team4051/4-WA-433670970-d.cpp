#include <bits/stdc++.h>
using namespace std;

int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, q;
    cin >> n >> q;

    string s;
    cin >> s;

    const int MAXN = 3e6 + 5;

    string aux;
    aux.resize(MAXN);

    int ptr = 0;
    for(int i = 0; i < s.size(); i++) {
        aux[ptr] = s[i];
        ptr++;
    }

    char sep = '#';

    aux[ptr] = sep;
    sep = (sep == '#' ? '$' : '#');
    ptr++;


    vector<int> v(q);
    string t;

    for(int i = 0; i < q; i++) {
        cin >> t;
        v[i] = t.size();

        for(int j = 0; j < t.size(); j++) {
            aux[ptr] = t[j];
            ptr++;
        }


        aux[ptr] = sep;
        sep = (sep == '#' ? '$' : '#');
        ptr++;
    
    }

    vector<int> z(MAXN);
    z[0] = ptr;
    int l=0, r = 0;
    for(int i = 1; i < aux.size(); i++) {
        if(i < r) z[i] = min(z[i - l], r - i);
        while(i + z[i] < aux.size() && aux[z[i]] == aux[i + z[i]])
            z[i]++;
        if(i + z[i] > r) {
            l = i;
            r = z[i] + i;
        }
    }

    ptr = n + 1;
    for(int i = 0; i < q; i++) {

        int ans = 0;
        while(v[i]) {
            ans = max(ans, n + v[i] - z[ptr]);
            ptr++;
            v[i]--;
        }

        ptr++;
        cout << ans << '\n';
    }


}