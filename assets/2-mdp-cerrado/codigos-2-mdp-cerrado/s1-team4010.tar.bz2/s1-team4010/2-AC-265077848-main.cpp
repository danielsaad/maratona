#include <bits/stdc++.h>

using namespace std;

#define int long long

int32_t main(){
    
    int n; cin >> n;
    if(n == 45){
        cout <<"Ambos" << endl;
    } else if(n > 45){
        cout <<"Saad" << endl;
    } else {
        cout <<"Costa" << endl;
    }


    return 0;
}