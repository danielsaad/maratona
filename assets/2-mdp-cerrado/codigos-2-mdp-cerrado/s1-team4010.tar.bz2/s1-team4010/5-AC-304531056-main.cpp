#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e7+2;

int spf[MAXN];

void crivo(int n){
    for(int i = 1; i<n; i++) spf[i] = i;
    for(int p = 2; p*p <n; p++){
        if(spf[p] == p){
            for(int i = p*p; i<n; i+= p){
                if(spf[i] == i) spf[i] = p;
            }
        }
    }
}

vector <int> ans;

map <int, int, greater<int>> mp;

void fatorar (int n ){
    vector <int> f;
    while(n > 1){
        f.push_back(spf[n]);
        ans.push_back(spf[n]);
        mp[spf[n]] += spf[n];
        n /= spf[n];
    }
}

int32_t main(){
    ios :: sync_with_stdio(false);
    cin.tie(NULL);
    
    int n; cin >> n;
    crivo(MAXN);
    vector <int> a(n);
    for(int i = 0; i<n; i++) cin >> a[i];

    for(int i = 0; i<n; i++){
        fatorar(a[i]);
    }
    int cont = 0, ans = 0;
    vector <int> res;
    for(auto[primo, potencia] : mp){
        res.push_back(potencia);
    }
    sort(res.begin(), res.end(), greater<int>());
    for(int i = 0; i<res.size(); i++){
        if(i%2 == 0) ans += res[i];
    }
    cout << ans << endl;


    return 0;
}