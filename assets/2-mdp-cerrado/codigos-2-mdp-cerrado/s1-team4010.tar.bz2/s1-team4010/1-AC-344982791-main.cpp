#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e5+10;
int32_t main(){
    ios :: sync_with_stdio(false);
    cin.tie(NULL);
    
    int n, q; cin >> n >> q;
    vector <int> ac(n+1), h(n+1);
    for(int i = 1; i<=n; i++) cin >> h[i];
    while(q--){
        int m, a; cin >> m  >> a;
        ac[m] += a;
    }
    for(int i = n-1; i>=1; i--) ac[i] += ac[i+1];

    for(int i = 1; i<=n; i++) h[i] += ac[i];

    /*for(int i = 1; i<=n; i++) cout << h[i] <<" ";
    cout << endl;*/

    stack <int> s;
    s.push(h[1]);
    for(int i = 2; i<=n; i++){
        cout << s.size() << endl;
        while(!s.empty() and s.top() <= h[i]) s.pop();
        s.push(h[i]);
    }
    

    return 0;
}