#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e5+10;
int32_t main(){
    ios :: sync_with_stdio(false);
    cin.tie(NULL);
    
    vector<pair<int,int>> mes_qtd;
    vector<int> predios;
    int n,c,num;
    cin>>n>>c;
    for(int i=0;i<n;i++){
        cin>>num;
        predios.push_back(num);
    }
    int a,b,max_mex=0,aux=0;
    for(int i=0;i<c;i++){
        cin>>a>>b;
        mes_qtd.push_back({a,b});
    }
    sort(mes_qtd.begin(),mes_qtd.end());

    int vet[MAXN], acumulado=0;
    /*auto it = mes_qtd.rbegin();
    for(int i=n - 1; i != -1; i--){
        if(it != mes_qtd.rend() && it->first == i + 1){
            acumulado += it->second;
            it++;
        }
        predios[i] += acumulado;
    }*/
    acumulado=mes_qtd.back().second;
    int ultimo=mes_qtd.back().first-1;
    mes_qtd.pop_back();
    for(int i=ultimo;i>=0;i--){
        if(!mes_qtd.empty() && mes_qtd.back().first-1==i){
            acumulado+=mes_qtd.back().second;
            mes_qtd.pop_back();
        }
        vet[i]+=acumulado;

    }
    for(int i=0;i<n;i++){
        predios[i]+=vet[i];
    }

    stack<int> nums{ { predios[0] } };

    for(int i{ 1 }; i < n; i++){
        cout << nums.size() << endl;
        
        while(!nums.empty() && nums.top() <= predios[i])
            nums.pop();
        nums.push(predios[i]);
    }


    return 0;
}