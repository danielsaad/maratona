#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e5+10;


int32_t main(){
    ios :: sync_with_stdio(false);
    cin.tie(NULL);
    
    int n; cin >> n;
    int node = 1, nivel = 2;
    vector <int> candidatos;
    candidatos.push_back(1);
    while(nivel <= n+1){
        int esquerda = node + nivel-1;
        int direita = node + nivel;

        cout << "? " << esquerda << endl;

        int resposta; cin >> resposta;
        if(resposta){
            candidatos.push_back(esquerda);
            node = esquerda;
        } else {
            candidatos.push_back(direita);
            node = direita;
        }
        nivel++;
    }

    int hi = candidatos.size()-1, lo = 0;
    while(hi >= lo){
        int mid = (hi+lo)/2;
        int no = candidatos[mid];
        cout << "? " << no << endl;
        int resposta; cin >> resposta;
        if(resposta){
            lo = mid+1;
        } else {
            hi = mid-1;
        }
    }
    cout <<"! " << candidatos[hi] << endl; 

    return 0;
}