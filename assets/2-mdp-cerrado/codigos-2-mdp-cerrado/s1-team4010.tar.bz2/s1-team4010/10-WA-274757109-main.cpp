#include <bits/stdc++.h>

using namespace std;

#define int long long

int32_t main(){
    int n;
    cin>>n;
    string s;
    cin>>s;
    char p='C';
    int ans=0;
    for(int i=0;i<n;i++){
        if(p==s[i] or p =='C'){
            p = s[i];
            ans++; continue;
        }
        p = 'C';
    }
    cout<<ans<<endl;
    return 0;
}