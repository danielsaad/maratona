#include <bits/stdc++.h>

using namespace std;

#define int long long

int32_t main(){
    int32_t h1, h2, m1, m2;
    char c;
    cin >> h2 >> c >> m2;
    cin >> h1 >> c >> m1;

    int rh = h2 - h1;
    int rm = m2 - m1;
    if(rm < 0)
        {
            rh--;
            rm = 60 + rm;
        }
    printf("%02i:%02i", rh, rm);


    return 0;
}