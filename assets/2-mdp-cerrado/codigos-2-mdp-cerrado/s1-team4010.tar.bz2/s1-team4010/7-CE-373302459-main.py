import re

def P():
    string = input().strip()
    return IO(string) or IF(string) or WH(string)

def IF(string):
    if not string.startswith("if "):
        return False
    return f"SE {E(string[3:-1])} ENTAO {IO(input().strip())}"

def WH(string):
    if not string.startswith("while "):
        return False
    return f"ENQUANTO {E(string[6:-1])} {IO(input().strip())}"

def IO(string):
    return IN(string) or OUT(string)

def IN(string):
    if string.find(" = ") == -1:
        return False
    return f"LEIA {string[:string.find(" = ")]}"

def OUT(string):
    if not string.startswith("print("):
        return False
    return f"APRESENTE {E(string[6:-1])}"

def E(string):
    # r = r"((\".*[^\\]\")|('.*[^\\]')|\d+|\w+)"
    # if found := re.search(, string):
    #     return found.group(0)
    # if found := re.search(r"^\d+", string):
    #     return found.group(0)
    # else found := 
        

    return string
# P()

print(P())


