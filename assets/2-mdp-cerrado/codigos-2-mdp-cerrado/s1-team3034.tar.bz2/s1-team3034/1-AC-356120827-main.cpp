#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define vll vector<ll>
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define all(xs) xs.begin(), xs.end()
#define rep(i, a, b) for(ll i = (ll)a; i < (ll) b; i++)
#define eb emplace_back

signed main() {
    fio;
    
    ll n, m;
    cin >> n >> m;

    vll xs(n);
    for (ll& x : xs) cin >> x;

    vector<vll> builds((ll)1e5 + 1);
    while (m--) {
        ll mi, ai;
        cin >> mi >> ai;
        builds[mi].eb(ai);
    }

    vll dp(n);
    dp[0] = 0;

    vll dp2(n, -1);

    {
        ll i = 0;
        ll j = i - 1;
        while (j >= 0 && xs[j] <= xs[i]) {
            j = dp2[j];
            dp2[i] = j;
        }
    }

    dp[0] = 1;
    ll del = 0;

    rep(i, 1, n) {
        for (ll x : builds[i])
            del += x;
        xs[i] -= del;
        
        cout << dp[i - 1] << '\n';

        ll j = i - 1;
        while (j >= 0 && xs[j] <= xs[i]) j = dp2[j];
        dp2[i] = j;

        if (xs[i] < xs[i - 1])
            dp[i] = dp[i - 1] + 1;
        else {
            if (dp2[i] == -1)
                dp[i] = 1;
            else
                dp[i] = dp[dp2[i]] + 1;
        }
    }
}