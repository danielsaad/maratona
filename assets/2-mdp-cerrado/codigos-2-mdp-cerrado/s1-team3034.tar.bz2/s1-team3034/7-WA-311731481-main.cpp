#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define all(xs) xs.begin(), xs.end()

bool test_input(string s)
{
    auto it = s.find("input()");
    if(it!=string::npos)
    {
        cout << "LEIA ";
        for(ll i = 0; s[i]!= '>' && s[i]!= '<' && s[i]!= '!' &&  s[i]!= ' ' && s[i] != '=' && i < s.size(); ++i)
            cout << s[i];
        cout << '\n';
        return true;
    }
    return false;
}

bool test_print(string s)
{
    auto it2 = s.find("print");
    if(it2!=string::npos && s.back()==')' && s[5]=='(')
    {
        cout << "APRESENTE ";
        for(ll i = 6; i < s.size()-1; ++i)
            cout << s[i];
        cout << '\n';
        return true;
    }
    return false;
}

signed main() {
    fio;
    
    string s, t, ans;

    getline(cin, s);
    map<string, string> h;

    if(test_input(s) || test_print(s))
        return 0;

    if(s[0]=='i'&&s[1]=='f'&&s.back()==':')
    {
        cout << "SE ";

        ll i = 3;
        string n="", m="";
        for(;s[i]!= '>' && s[i]!= '<' && s[i]!= '!' &&  s[i]!= ' ' && s[i] != '=' && i < s.size(); ++i)
            n += s[i];
        cout << n;
        while((i < s.size())&&s[i]!=':'&&(s[i]!= '>' || s[i]!= '<' || s[i]!= '!' ||  s[i]!= ' ' || s[i] != '='))
        {
            cout << s[i];
            ++i;
        }
        
        while(i < s.size()-1 && (i < s.size()) && s[i]!=':')
        {
            m += s[i];
            ++i;
        }

        cout << m;
        cout << " ENTAO ";
        getline(cin, t);
        test_input(t);
        test_print(t);

        return 0;
    }

    auto it6 = s.find("while");
    if(it6!=string::npos)
    {
        cout << "ENQUANTO ";

        ll i = 6;
        string n="", m="";
        for(;s[i] != ':' && s[i]!= '>' && s[i]!= '<' && s[i]!= '!' &&  s[i]!= ' ' && s[i] != '=' && i < s.size(); ++i)
            n += s[i];
        cout << n;
        while((i < s.size())&&s[i]!=':'&&(s[i]!= '>' || s[i]!= '<' || s[i]!= '!' ||  s[i]!= ' ' || s[i] != '='))
        {
            cout << s[i];
            ++i;
        }
        
        while(i < s.size()-1 && (i < s.size()) && s[i]!=':')
        {
            m += s[i];
            ++i;
        }

        cout << m;
        cout << " ENTAO ";
        getline(cin, t);
        test_input(t);
        test_print(t);

        return 0;
    }
}