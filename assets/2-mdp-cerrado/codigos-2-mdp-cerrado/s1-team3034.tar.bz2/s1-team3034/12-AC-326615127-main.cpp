#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define vll vector<ll>
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define all(xs) xs.begin(), xs.end()
#define rep(i, a, b) for(ll i = (ll)a; i < (ll) b; i++)

ll query(ll i) {
    cout << "? " << i << endl;
    ll res;
    cin >> res;
    return res;
}

ll bb(const vll& is) {
    ll lo = 0;
    ll hi = is.size();
    while (lo + 1 < hi) {
        ll mi = (lo + hi) / 2;
        ll v = query(is[mi]);
        if (v == 1)
            lo = mi;
        else hi = mi;
    }
    return lo;
}

signed main() {
    ll n;
    cin >> n;
    n += 2;
    
    ll at = 1;
    ll nv = 1;

    vll is;
    is.emplace_back(at);
    
    while (true) {
        ll l = at + nv;
        ll r = at + nv + 1;
        ll v = query(l);
        if (v == 1) at = l;
        else at = r;
        is.emplace_back(at);
        nv ++;
        if (nv == n - 1) break;
    }

    ll ans = is[bb(is)];
    cout << "! " << ans << endl;
    
}