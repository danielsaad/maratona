#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define pll pair<ll, ll>
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define eb emplace_back

signed main() {
    fio;
    ll n, q;
    cin >> n >> q;

    string s;
    cin >> s;

    ll y = 0;
    for (ll i = 0; i < n; ++i)
        if (s[i] != s[0]) break;
        else ++y;

    while (q--) {
        string t;
        cin >> t;
        ll m = t.size();
        ll j = 0;
        ll ans = max(n, m);

        if (s[0] == t[0]) {
            char c = s[0];
            ll x = 0;
            for (ll i = 0; i < m; ++i)
                if (t[i] != c) break;
                else ++x;
            ans = max(ans, m - x + n);
            ans = max(ans, n - y + m);
        }
        else {
            ans = max(ans, n + m);
        }

        cout << ans << '\n';
    }
}