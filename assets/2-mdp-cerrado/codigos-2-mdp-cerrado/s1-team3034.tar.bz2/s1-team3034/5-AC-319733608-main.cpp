#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define vll vector<ll>
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define all(xs) xs.begin(), xs.end()
#define rep(i, a, b) for(ll i = (ll)a; i < (ll) b; i++)

constexpr ll MAXN = 1e7;

vll sieve(ll n) {
    vll spf(n+1);
    rep(i, 2, n+1) if(!spf[i]) {
        spf[i] = i;
        for(ll j=i*i; j<=n; j+=i)
            if(!spf[j]) spf[j] = i;
    }

    return spf;
}


void factors(ll x, const vll &spf, map<ll, ll> &mp) {
    while(x!=1) { 
        mp[spf[x]]++;
        x /= spf[x];
    }
}

signed main() {
    // fio;
    vll spf = sieve(MAXN);
    
    ll n;
    cin >> n;

    vll a(n);
    map<ll, ll> mp;
    rep(i, 0, n) {
        cin >> a[i];
        factors(a[i], spf, mp);
    }

    priority_queue<ll> pq;
    for(auto [p, qntp]: mp) {
        pq.push(p*qntp);
    }

    ll ans=0;
    while(!pq.empty()) {
        ans += pq.top(); pq.pop();
        if(!pq.empty()) pq.pop();
    }

    cout << ans << '\n';
}