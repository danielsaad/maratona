#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define fio cin.tie(0)->ios::sync_with_stdio(0)

signed main() {
    fio;
    ll x; cin >> x;
    double rad = acos(-1.0) * x / 180.0;
    double a = sin(rad); double b = cos(rad);
    // cout << a << ' ' << b << '\n';
    if(abs(a-b)<1e-5)
        cout << "Ambos";
    else if(b>a)
        cout << "Costa";
    else if(a>b)
        cout << "Saad";
    cout << '\n';
}