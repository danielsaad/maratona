#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define vll vector<ll>
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define all(xs) xs.begin(), xs.end()
#define rep(i, a, b) for(ll i = (ll)a; i < (ll) b; i++)
#define eb emplace_back

void analyze() {
    string first;
    cin >> first;

    ll n = first.size();

    string line;
    if (n >= 6 && first.substr(0, 6) == "print(") {
        first = first.substr(6);
        getline(cin, line);
        line = first + line;
        line.pop_back();
        cout << "APRESENTE " << line; 
    }
    else if (first == "if") {
        getline(cin, line);
        line.pop_back();
        cout << "SE" << line << " ENTAO ";
        analyze();
    }
    else if (first == "while") {
        getline(cin, line);
        line.pop_back();
        cout << "ENQUANTO" << line << " ";
        analyze();
    }
    else {
        string var, ig;
        cin >> ig;
        cin >> var;
        cout << "LEIA " << first;
    }
}

signed main() {
    fio;
    analyze();
    cout << '\n';
}