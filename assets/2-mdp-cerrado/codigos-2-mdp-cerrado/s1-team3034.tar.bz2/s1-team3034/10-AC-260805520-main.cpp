#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define fio cin.tie(0)->ios::sync_with_stdio(0)

signed main() {
    fio;
    ll n;
    cin >> n;
    string s;
    cin >> s;

    map<char, ll> pos = {
        {'C', 1},
        {'D', 2},
        {'E', 0},
    };

    ll ans = 0;
    ll at = -1;
    for (char c : s) {
        if (at == -1) {
            at = pos[c];
            ans++;
        }
        else {
            if (abs(at - pos[c]) <= 1) {
                at = pos[c];
                ans++;
            }
            else {
                at = 1;
            }
        }
    }

    cout << ans << '\n';
}