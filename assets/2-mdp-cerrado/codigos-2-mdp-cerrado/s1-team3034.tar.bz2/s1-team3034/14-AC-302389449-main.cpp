#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define fio cin.tie(0)->ios::sync_with_stdio(0)
#define all(xs) xs.begin(), xs.end()

signed main() {
    fio;
    
    string s;
    cin >> s;
    ll horas_f = ((s[0]-'0')*10) + (s[1]-'0');
    ll minutos_f = ((s[3]-'0')*10) + (s[4]-'0');

    cin >> s;
    ll horas_a = ((s[0]-'0')*10) + (s[1]-'0');
    ll minutos_a = ((s[3]-'0')*10) + (s[4]-'0');

    if(minutos_f < minutos_a)
        minutos_f += 60, horas_f--;
    
    ll horas = horas_f - horas_a;
    ll minutos = minutos_f - minutos_a;
    if(horas < 0) {
        horas = 0;
        minutos = 0;
    }

    cout << (horas < 10 ? "0" : "") << horas << ":" << (minutos < 10 ? "0" : "") << minutos << '\n'; 
}