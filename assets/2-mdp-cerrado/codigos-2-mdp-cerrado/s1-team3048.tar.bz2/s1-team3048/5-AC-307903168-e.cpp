#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second
constexpr int maxi=1e7+1;

int primos[maxi];

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    rep(i, 2, maxi){
        if(primos[i]) continue;
        for(int j=i; j < maxi; j+=i) primos[j] = i;
    }

    int n;
    cin >> n;
    map<int, int> quant;
    rep(i, 0, n){
        int x;
        cin >> x;
        while(x > 1){
            int p=primos[x];
            while(!(x % p)) quant[p]++, x /= p;
        }
    }
    priority_queue<int> pq;
    for(auto [p, q] : quant){
        pq.push(p*q);
    }
    int ans=0, i=1;
    while(!pq.empty()){
        if(i&1) ans += pq.top();
        i ^= 1;
        pq.pop();
    }
    cout << ans << endl;
    
}