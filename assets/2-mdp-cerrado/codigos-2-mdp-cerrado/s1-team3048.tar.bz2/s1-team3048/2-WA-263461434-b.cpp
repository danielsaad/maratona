#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
const double pi = acos(-1);

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int ang; cin >> ang;

    if(cos(1.0*ang*pi / 180.0) > sin(1.0*ang*pi / 180.0))
        cout << "Costa\n";
    else if(cos(1.0*ang*pi / 180.0) < sin(1.0*ang*pi / 180.0))
        cout << "Saad\n";
    else
        cout << "Ambos\n";
}