primOp = input()
primOpSpace = primOp[:].split()
primOpAspas = primOp[:].split("(")

if primOpSpace[0] == "if":

    exp = ""
    primOpSpace.pop(0)
    for exps in primOpSpace:
        exp += exps+" "
    print(f"SE {exp[:-2]} ENTAO", end=" ")

    secOp = input()
    secOpSpace = secOp[:].split()
    secOpAspas = secOp[:].split("(")
    if(secOpSpace[1] == '='):
        print(f"LEIA {secOpSpace[0]}")
    else:
        print(f"APRESENTE {secOpAspas[1][:-1]}")
elif primOpSpace[0] == "while":

    exp = ""
    primOpSpace.pop(0)
    for exps in primOpSpace:
        exp += exps+" "
    print(f"ENQUANTO {exp[:-2]}", end=" ")
    secOp = input()
    secOpSpace = secOp[:].split()
    secOpAspas = secOp[:].split("(")
    if(secOpSpace[1] == '='):
        print(f"LEIA {secOpSpace[0]}")
    else:
        print(f"APRESENTE {secOpAspas[1][:-1]}")
else:
    if(len(primOpSpace) > 1 and primOpSpace[1] == '='):
        print(f"LEIA {primOpSpace[0]}")
    else:
        print(f"APRESENTE {primOpAspas[1][:-1]}")