#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second
constexpr int mod = 1e9+7;

struct Hash {
    int base, n;
    string s;
    vector<int> h, p;

    Hash(string s, int base) :
        s(s), base(base), n(sz(s)), h(n), p(n) {

            for(int i = n-1; i >= 0; i--)
                p[i] = (i == n-1 ? 1 : (p[i+1]*base) % mod);
            rep(i, 0, n)
                h[i] = (s[i]*p[i] + (i ? h[i-1] : 0)) % mod;
        }

    int query(int l, int r){
        return(((h[r] + mod - (l ? h[l-1] : 0)) * p[n-l-1]) % mod);
    }
};

mt19937 rng(time(0));
uniform_int_distribution<int> distrib(5, mod-1);

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int n, m, b = distrib(rng);
    string s, t, S = "", T = "";

    cin >> s >> t;
    while (sz(S) < sz(t)) {
        S += s;
    }
    S += S;


    vector psum(sz(t), vector<int>());
    vector<int> v(sz(s));
    for(int& x : v) {
        cin >> x;
    }

    int idx = 0;
    while (sz(v) < sz(S)) v.emplace_back(v[idx++]);

    rep(i, 0, sz(v)) {
        if (sz(psum[i%sz(t)])) psum[i%sz(t)].emplace_back(psum[i%sz(t)].back());
        else psum[i%sz(t)].emplace_back(0);
        psum[i%sz(t)].back() += v[i];
    }

    while (sz(T) < sz(S)) T += t;

    Hash hS(S, b), ht(t, b), hT(T, b);
    vector<bool> match(sz(S), false);
    rep(i, 0, sz(S)) {
        match[i] = (hS.query(i, i+sz(t)-1) == ht.query(0, sz(t)-1) ? 1 : 0);
    }   

    rep(i, 0, sz(S)) cout << match[i] << ' ';
    cout << endl;

    bool ok = false;
    int g = gcd(sz(S)/2, sz(t));
    rep(i, 0, g) {
        int idx = i, aa = 0;
        
        while (!aa || idx != i) {
            aa = 1;
            if (!match[idx]) break;
            idx = (idx + sz(t)) % (sz(S)/2);
        }
        if (aa && idx == i) {
            ok = true;
            break;
        }
    }

    if (ok) {
        cout << "-1\n";
        return 0;
    }

    int resp = 0;
    rep(i, 0, sz(S)/2) {
        int l = 1, r = (sz(S)-i) / sz(t), mid, ans = 0;
        while (l <= r) {
            mid = (l+r)/2;

            if (hS.query(i, i+mid*sz(t)-1) == hT.query(0, mid*sz(t)-1)) {
                ans = mid;
                l = mid+1;
            } else
                r = mid-1;
        }

        resp = max(resp, psum[i%sz(t)][i%sz(t)+ans-1] - (i % sz(t) ? psum[i%sz(t)][i%sz(t) - 1] : 0));
    }

    cout << resp << endl;
}