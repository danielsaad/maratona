import math
n = float(input())
pi = math.acos(-1)
if math.cos(n*pi / 180.0) > math.sin(n*pi / 180):
    print("Costa")
elif math.cos(n*pi / 180.0) < math.sin(n*pi / 180):
    print("Saad")
else:
    print("Ambos")