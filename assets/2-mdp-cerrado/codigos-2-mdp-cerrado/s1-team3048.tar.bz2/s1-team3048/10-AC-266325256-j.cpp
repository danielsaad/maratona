#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int n;
    string s;

    cin >> n >> s;

    vector dp(n, vector<int>(3));
    dp[0][0] = s[0] == 'E' ? 1 : 0;
    dp[0][1] = s[0] == 'C' ? 1 : 0;
    dp[0][2] = s[0] == 'D' ? 1 : 0;

    rep(i, 1, n) {
        dp[i][0] = s[i] == 'E' ? 1 : 0;
        dp[i][0] += max(dp[i-1][0], dp[i-1][1]);

        dp[i][1] = s[i] == 'C' ? 1 : 0;
        dp[i][1] += max(max(dp[i-1][0], dp[i-1][1]), dp[i-1][2]);

        dp[i][2] = s[i] == 'D' ? 1 : 0;
        dp[i][2] += max(dp[i-1][2], dp[i-1][1]);
    }

    cout << max(max(dp[n-1][0], dp[n-1][1]), dp[n-1][2]) << endl;
}