#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second

constexpr int MOD = 998244353;

struct Matrix {
    int r, c;
    vector<vector<int>> mat;

    Matrix(int n, int m, bool id=false): r(n), c(m), mat(n, vector(m, 0ll)) {
        if (id) rep(i, 0, min(r,c)) mat[i][i] = 1;
    }

    Matrix operator*(const Matrix &o) const {
        assert(c == o.r);

        Matrix res(r, o.c);
        rep(i, 0, r) {
            rep(j, 0, o.c) {
                int s = 0;
                rep(k, 0, c) {
                    s += (mat[i][k] * o.mat[k][j]) % MOD;
                    s %= MOD;
                }
                res.mat[i][j] = s;
            }
        }
        return res;
    }
};

Matrix binpow(Matrix a, int b) {
    Matrix res(a.r, a.c, true);
    while (b) {
        if (b&1) res = res * a;
        a = a*a;
        b >>= 1;
    }
    return res;
}

int binpow(int a, int b) {
    int res = 1;
    while (b) {
        if (b&1) res = (res*a) % MOD;
        a = (a*a) % MOD;
        b >>= 1;
    }
    return res;
}

int sub(int a, int b) {
    return (a-b+MOD) % MOD;
}
int add(int a, int b) {
    return (a+b)%MOD;
}
int mul(int a, int b) {
    return (a*b)%MOD;
}

void solve() {
    int a, b, n, m, vn, vm;
    cin >> a >> b >> n >> m >> vn >> vm;

    Matrix rec(2, 2);
    rec.mat[0] = {0,1};
    rec.mat[1] = {b,a};

    Matrix coefa = binpow(rec, n), coefb = binpow(rec, m);

    // cout << "A:\n";
    // rep(i, 0, 2) {
    //     rep(j, 0, 2) cout << coefa.mat[i][j] << ' ';
    //     cout << endl;
    // }
    // cout << "B:\n";
    // rep(i, 0, 2) {
    //     rep(j, 0, 2) cout << coefb.mat[i][j] << ' ';
    //     cout << endl;
    // }

    int f0, f1;
    if (n > 1 && m > 1) {
        int a1, a2;
        a1 = sub(vm, mul(mul(coefb.mat[0][0], vn), binpow(coefa.mat[0][0], MOD-2)));
        a2 = sub(coefb.mat[0][1], mul(mul(coefb.mat[0][0], coefa.mat[0][1]), binpow(coefa.mat[0][0], MOD-2)));
        
        f1 = mul(a1, binpow(a2, MOD-2));
        f0 = mul(binpow(coefa.mat[0][0], MOD-2), sub(vn, mul(coefa.mat[0][1], f1)));
    } else {
        f1 = vn;
        f0 = mul(binpow(coefb.mat[0][0], MOD-2), sub(vm, mul(coefb.mat[0][1], f1)));
    }

    cout << f0 << ' ' << f1 << endl;
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int t;
    cin >> t;
    while (t--)
        solve();
}