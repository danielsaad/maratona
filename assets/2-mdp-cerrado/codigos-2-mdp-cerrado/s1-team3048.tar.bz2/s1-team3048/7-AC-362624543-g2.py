def trata(s):
    if(s[:6] == "print("):  
        ans = s[6:-1]
        print("APRESENTE", ans)
    else:
        v = s.split()
        print("LEIA", v[0])


s = input().strip()

if(s[:6] == "print("):  
    ans = s[6:-1]
    print("APRESENTE", ans)

elif(s[:3] == "if "):
    if s[-1] == ':':
        s = s[:-1]
        v = s.split()
        print("SE", end=" ")
        for i in range(1, len(v)):
            print(v[i], end=" ")
        print("ENTAO", end=" ")
        s2 = input().strip()
    else:
        while(True):
            s += 'a'
    trata(s2)

elif(s[:6] == "while "):
    if s[-1] == ':':
        s = s[:-1]
        v = s.split()
        print("ENQUANTO", end=" ")
        for i in range(1, len(v)):
            print(v[i], end=" ")
        s2 = input().strip()
    else:
        while(True):
            s += 'a'
    trata(s2)
    
else:
    v = s.split()
    print("LEIA", v[0])