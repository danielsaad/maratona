primOp = input()
primOpSpace = primOp[:].split()
primOpAspas = primOp[:].split("(")

if primOpSpace[0] == "if":

    exp = ""

    for exps in primOpSpace:
        if(exps == "while"):
            continue
        if(exps[-1] == ":"):
            exp += exps[:-1]+" "
        else:
            exp += exps+" "

    print(f"SE {exp}ENTAO", end=" ")

    secOp = input()
    secOpSpace = secOp[:].split()
    secOpAspas = secOp[:].split("(")
    if(secOpSpace[1] == '='):
        print(f"LEIA {secOpSpace[0]}")
    else:
        print(f"APRESENTE {secOpAspas[1][:-1]}")
elif primOpSpace[0] == "while":

    exp = ""

    for exps in primOpSpace:
        if(exps == "while"):
            continue
        if(exps[-1] == ":"):
            exp += exps[:-1]+" "
        else:
            exp += exps+" "

    print(f"ENQUANTO {exp}", end="")
    secOp = input()
    secOpSpace = secOp[:].split()
    secOpAspas = secOp[:].split("(")
    if(secOpSpace[1] == '='):
        print(f"LEIA {secOpSpace[0]}")
    else:
        print(f"APRESENTE {secOpAspas[1][:-1]}")
else:
    if(len(primOpSpace) > 1 and primOpSpace[1] == '='):
        print(f"LEIA {primOpSpace[0]}")
    else:
        print(f"APRESENTE {primOpAspas[1][:-1]}")