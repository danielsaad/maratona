import math
n = int(input())

if n < 45:
    print("Costa")
elif n > 45:
    print("Saad")
else:
    print("Ambos")