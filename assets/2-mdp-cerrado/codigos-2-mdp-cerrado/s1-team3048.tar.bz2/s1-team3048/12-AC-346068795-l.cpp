#include <bits/stdc++.h>

using namespace std;

#define int long long
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second

signed main() {
    int n;
    cin >> n;

    int a=1, p=0, g=1, nivel=1, qg=1, ans=1, f;
    vector<int> qq;
    while(true){
        g += qg; qg++; nivel++;
        if(nivel == n+2) break;
        cout << "? " << g+p << endl;
        cin >> f;
        if(f){ 
            a = g+p;
            ans=a;
            qq = vector<int>();
        }
        else{
            qq.emplace_back(g+p+1);
            a = ++p+g;
        }
    }

    int l=0, r=sz(qq)-1, mid;
    while(l <= r){
        mid = (l+r)/2;
        cout << "? " << qq[mid] << endl;
        cin >> f;
        if(f) ans=qq[mid], l=mid+1;
        else r=mid-1;
    }
    cout << "! " << ans << endl;

}