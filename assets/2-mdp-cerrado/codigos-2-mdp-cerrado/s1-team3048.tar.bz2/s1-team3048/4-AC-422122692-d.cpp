#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second
constexpr int mod = 1e9+7;


signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int n, q;
    string s;
    cin >> n >> q >> s;
    vector<int> pos(26, n);

    rep(i, 0, n){
        rep(j, 0, 26){
            if(s[i]-'a' != j) pos[j] = min(pos[j], i);
        }
    }

    while(q--){
        string t;
        cin >> t;
        int ans=max(sz(t), n);
        rep(i, 0, sz(t)){
            ans = max(ans, (sz(t)-i)+(n-pos[t[i]-'a']));
        }
        cout << ans << endl;
    }
}