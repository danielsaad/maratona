#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int n, c;

    cin >> n >> c;

    vector<int> v(n), psum(n, 0);
    for (auto &x : v) cin >> x;

    rep(i, 0, c) {
        int m, h;
        cin >> m >> h;
        m--;
        
        if (m >= n) continue;
        psum[m] += h;
    }

    rep(i, 1, n) psum[i] += psum[i-1];

    auto comp = [&](int i, int j) -> bool {
        int hi = v[i] + psum[j] - (i ? psum[i-1] : 0);
        int hj = v[j] + psum[j] - psum[j-1];
        // cout << "comp " << i << ' ' << j << ": " << hi << ' ' << hj << endl;
        return hi <= hj;
    };

    vector<int> ans(n);
    stack<int> s;
    s.push(0);
    rep(i, 1, n) {
        int cnt = 0;
        while (sz(s) && comp(s.top(), i)) s.pop(), cnt++;

        // int prev = sz(s) ? s.top() : 0; cout << "aa " << (sz(s) ? s.top() : -1) << endl;
        ans[i] = cnt + sz(s);
        s.push(i);
    }

    rep(i, 1, n) cout << ans[i] << endl;
}