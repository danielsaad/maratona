#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
const double pi = acos(-1);

signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    string f, a;
    cin >> f >> a;

    int f1=stoi(f.substr(0, 2)), f2=stoi(f.substr(3, 2));
    int a1=stoi(a.substr(0, 2)), a2=stoi(a.substr(3, 2));

    int t1=0, t2=0;
    if(f2 < a2){
        t1--;
        t2 = f2+60-a2;
    }
    else t2 = f2-a2;
    t1 += f1-a1;
    if(t1 < 10) cout << 0 << t1 << ':';
    else cout << t1 << ':';
    if(t2 < 10) cout << 0 << t2 << endl;
    else cout << t2 << endl;
}