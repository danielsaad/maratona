#include <bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define rep(a,b,c) for(int a = (int)b ; a < (int)c ; a++)
#define all(x) x.begin(), x.end()
#define sz(x) ((int)x.size())
typedef pair<int, int> pii;
#define ff first
#define ss second

int cont=0;
string ans="", reff="ABC";

void mover(int origem, int destino){
    ans += reff[origem];
    ans += " ";
    ans += reff[destino];
    ans += endl;
    cont++;
}

void hanoi(int x, int origem, int destino, int auxiliar, vector<int>& p){
    if(x == -1) return;
    // tratar o -1
    if(p[x] == destino){
        hanoi(x-1, auxiliar, destino, origem, p);
    }
    else{
        if(origem == -1) origem = p[x], auxiliar = 3-p[x]-destino;
        if(p[x] == origem){
            hanoi(x-1, origem, auxiliar, destino, p);
            // cout << x << " " << origem << " " << destino << " " << auxiliar << endl;
            mover(origem, destino);
            p[x] = destino;
            hanoi(x-1, auxiliar, destino, origem, p);
        }
        else{
            hanoi(x-1, auxiliar, origem, destino, p);
            // cout << x << " " << auxiliar << " " << destino << endl;
            mover(auxiliar, destino);
            p[x] = destino;
            hanoi(x-1, origem, destino, auxiliar, p);
        }
    }
}


signed main() {
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int n;
    cin >> n;
    vector<int> p(n);
    rep(i, 0, 3){
        int t, x;
        cin >> t;
        while(t--){
            cin >> x;
            p[--x] = i;
        }
    }

    hanoi(n-1, -1, 1, -1, p);    
    cout << cont << endl;
    cout << ans;

}