#include <bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;

int main(){
    ll angulo;

    cin >> angulo;
    if(angulo > 45)
        cout << "Saad" << endl;
    else if(angulo < 45)
        cout << "Costa" << endl;
    else
        cout << "Ambos" << endl;
        
    return 0;
}