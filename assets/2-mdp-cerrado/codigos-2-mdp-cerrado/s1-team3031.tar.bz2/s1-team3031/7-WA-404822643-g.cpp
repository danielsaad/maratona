#include <bits/stdc++.h>
#define ll long long
using namespace std;

void identify(string line, int start);
void ler(string var) {
    cout << "LEIA " << var;
    // cout.flush();
}

void apres(string var) {
    cout << "APRESENTE " << var;
    // cout.flush();
}

void se_ent(string cond) {
    cout << "SE " << cond << " ENTAO ";
    // cout.flush();
    string newLine;
    int spaces = 0;
    getline(cin, newLine);
    while(newLine[spaces] <= 'a' || newLine[spaces] >= 'z'){
        spaces++;
    }
    identify(newLine, spaces);
}

void enq(string cond) {
    cout << "ENQUANTO " << cond << ' ';
    // cout.flush();
    string newLine;
    int spaces = 0;
    getline(cin, newLine);
    while(newLine[spaces] <= 'a' || newLine[spaces] >= 'z'){
        spaces++;
    }
    identify(newLine, spaces);
}

void identify(string line, int start){
    string fst = "\0";
    fst += line[start + 0];
    fst += line[start + 1];
    fst += line[start + 2];
    //cout << fst << '\n';

    if(fst == "if "){
        int i = start + 3;
        string cond;

        while(line[i] != ':'){
            cond += line[i];
            i++;
        }
        se_ent(cond);

    }else{
        fst += line[start + 3];
        fst += line[start + 4];
        fst += line[start + 5];
        if(fst == "while "){
            int i = start + 6;
            string cond;

            while(line[i] != ':'){
                cond += line[i];
                i++;
            }
            enq(cond);

        }else if(fst == "print("){
            int i = start + 6;
            string var;

            while(line[i] != ')'){
                var += line[i];
                i++;
            }
            apres(var);
        }else{
            int i = start;
            string var;

            while(line[i] != ' '){
                var += line[i];
                i++;
            }
            ler(var);
        }
    }
}

int main() {
    string line;
    getline(cin, line);
    //cout << line << '\n';
    identify(line, 0);
    cout << '\n';
    // cout.flush();

    return 0;
}
