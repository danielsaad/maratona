#include <bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define endl '\n'
using namespace std;


int main() {
    ll size, i, j, alt, mes, up, buildingsSeen;
    cin >> size >> alt;
    vll altura(size+1);

    altura[0] = 0;
    for(i = 1; i <= size; i++)
        cin >> altura[i];

    for(i = 0; i < alt; i++){
        cin >> mes >> up;
        for(j = 1; j <= mes; j++){
            altura[j] += up;
        }
    }
    
    /*for(i = 1; i <= size; i++)
        cout << altura[i] << ' ';
    cout << endl;
    */

    for(i = 2; i <= size; i++){
        for(j = i-1; j > 0; j--){
            if(altura[j-1] <= altura[j]){
                cout << i - j << endl;
                break;
            }
        }
    }

    return 0;
}
