#include <bits/stdc++.h>
#define ll long long
using namespace std;


int main() {
    int t, pos = 0, defesas = 0;
    cin >> t;
    string attempts;
    cin >> attempts;
    
    for (int j = 0; j < t; j++) {
        if (attempts[j] == 'C') {
            pos = 0;
            defesas ++;
        }
        else if (attempts[j] == 'E') {
            if (pos == -1)
                defesas++;
            else {
                if (pos == 0)
                    defesas ++;

                pos --;
            }
        }
        else {
            if (pos == 1)
                defesas++;
            else {
                if (pos == 0)
                    defesas ++;

                pos ++;
            }
        }
    }

    cout << defesas << '\n';

    return 0;
}