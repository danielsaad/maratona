#include <bits/stdc++.h>
#define ll long long
using namespace std;

void identify(string line, int start);
void ler(string var) {
    cout << "LEIA " << var;
}

void apres(string var) {
    cout << "APRESENTE " << var;
}

void se_ent(string cond) {
    cout << "SE " << cond << " ENTAO ";
    string newLine;
    int spaces = 0;
    getline(cin, newLine);
    while(newLine[spaces] == ' '){
        spaces++;
    }
    identify(newLine, spaces);
}

void enq(string cond) {
    cout << "ENQUANTO " << cond << ' ';
    string newLine;
    int spaces = 0;
    getline(cin, newLine);
    while(newLine[spaces] == ' '){
        spaces++;
    }
    identify(newLine, spaces);
}

void identify(string line, int start){
    string fst = "\0";
    fst += line[start + 0];
    fst += line[start + 1];
    fst += line[start + 2];

    if(fst == "if "){
        int i = start + 3;
        string cond;

        while(line[i] != ':'){
            cond += line[i];
            i++;
        }
        se_ent(cond);

    }else{
        fst += line[start + 3];
        fst += line[start + 4];
        fst += line[start + 5];
        if(fst == "while "){
            int i = start + 6;
            string cond;

            while(line[i] != ':'){
                cond += line[i];
                i++;
            }
            enq(cond);

        }else if(fst == "print("){
            int i = start + 6;
            string var;

            while(line[i] != ')'){
                var += line[i];
                i++;
            }
            apres(var);
        }else{
            int i = start;
            string var;

            while(line[i] != ' '){
                var += line[i];
                i++;
            }
            ler(var);
        }
    }
}    /*string fst = "123";
    fst[0] = line[0];
    fst[1] = line[1]; 
    fst[2] = line[2];*/

int main() {
    string line;
    getline(cin, line);
    //cout << line << '\n';
    identify(line, 0);
    cout << '\n';

    return 0;
}
