#include <bits/stdc++.h>
#define ll long long
using namespace std;


int main() {
    int n = 1, ind = 1, response;
    bool absurdo = false;

    while (!absurdo) {
        cout << "? " << ind + n << endl;
        
        cin >> response;
        if (response == 1) {
            ind += n;
        }
        else {
            cout << "? " << ind + n +1 << endl;
            cin >> response;
            
            if (response == 1) {
                ind += n +1;
            }
            else {
                absurdo = true;
                cout << "! " << ind << endl;
            }
        }
        n++;
    }

    return 0;
}
