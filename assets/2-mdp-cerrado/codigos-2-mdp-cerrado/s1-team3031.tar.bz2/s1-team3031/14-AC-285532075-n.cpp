#include <bits/stdc++.h>
#define ll long long
using namespace std;


int main() {
    ll hi, hf, mi, mf, mr = 0, hr = 0;
    char dot;

    cin >> hf >> dot >> mf;
    cin >> hi >> dot >> mi;

    mr = mf - mi;
    if(mr < 0){
        mr += 60;
        hr--;
    }
    hr += (hf - hi);

    if(hr < 10)
        cout << 0;
    cout << hr << dot;
    if(mr < 10)
        cout << 0;
    cout << mr << endl;

    return 0;
}
