#include <bits/stdc++.h>

using namespace std;
#define int long long
#define endl '\n'
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;
const int MOD = 998244353;

int32_t main()
{   
    int n,c;

    cin >> n >> c;
    vector<int> pred(n);
    for(int i = 0; i < n; i++)
    {
        cin >> pred[i];
    }
    for(int i = 0; i < c; i++)
    {
        int x,y;
        cin >> x >> y;
        pred[x-1] +=y;
    }
    set<int> aux;
    aux.insert(pred[0]);
    for(int i = 1; i < n; i++)
    {
        cout << aux.size() << endl;
        auto it2 = aux.upper_bound(pred[i]);
        int val;
        if(it2 == aux.end()) val = 2*1e9 + 1;
        else val = *it2;
        for(auto it = aux.begin(); it != aux.end() && *it < val; ) 
        {
            // cout << *it << endl;
            it = aux.erase(it);
        }
        aux.insert(pred[i]);
    }
    return 0;
}