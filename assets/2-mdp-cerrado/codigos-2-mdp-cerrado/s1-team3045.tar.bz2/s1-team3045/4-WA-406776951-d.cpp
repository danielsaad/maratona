#include <bits/stdc++.h>

using namespace std;
#define int long long
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;

vi zfnunc(string s){
    int n = s.size();
    vi z(n,0);
    z[0]=n;
    for(int i =1,l=0,r=0;i<n;i++){
        if(i<=r)z[i]=min(r-i+1,z[i-l]);
        while(i+z[i]<n && s[z[i]]==s[i+z[i]])++z[i];
        if(i+z[i]-1>r){
            l = i; r = i+z[i]-1;
        }
    }
    return z;
}
int32_t main(){
    sws

    int n,m;
    cin>>n>>m;
    string s;cin>>s;
    rep(i,0,m){
        string t;cin>>t;
        int ans = t.size()+s.size();
        string aux = s+"%"+t;
        vi z = zfnunc(aux);
        int common = z[s.size()+1];
        ans-=common;
        cout<<ans<<"\n";
    }


                                                                                                             
}