#include <bits/stdc++.h>

using namespace std;
#define int long long
#define endl '\n'
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;
const int MOD = 998244353;
const int MAXN = 1e7+5;
bool not_prime[MAXN];
vector<int> primos;
void crivo()
{
    for(int i = 2; i < MAXN; i++)
    {
        if(not_prime[i] == 0)
        {
            primos.push_back(i);
            for(int j = 2; j*i < MAXN; j++)
            {
                not_prime[j*i] = 1;
            }
        }
    }
}
int32_t main()
{   
    crivo();
    int n;
    cin >> n;
    vector<int> v;
    map<int,int> mp;
    for(int i = 0; i < n; i++)
    {
        int x;
        cin >> x;
        v.push_back(x);
        for(auto p: primos)
        {
            if(p > x) break;
            while(x%p == 0)
            {
                mp[p]++;
                x/=p;
            }
        }
    }
    vector<int> resp;
    for(auto [x,y] : mp) resp.push_back(x*y);

    sort(resp.begin(), resp.end(), greater<int>());
    int ans = 0;
    for(int i = 0; i < resp.size(); i++)
    {
        ans += ((i%2)? 0:resp[i]);
    }
    cout << ans << endl;
    return 0;
}