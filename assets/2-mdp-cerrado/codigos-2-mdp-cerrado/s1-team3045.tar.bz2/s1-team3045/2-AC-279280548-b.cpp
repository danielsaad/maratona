#include <bits/stdc++.h>

using namespace std;

int main() {
    cin.tie(0);
    cout.tie(0);

    long long a;
    cin >> a;

    if (a == 45) {
        cout << "Ambos";
    } else if (a > 45) {
        cout << "Saad";
    } else {
        cout << "Costa";
    }
    cout << '\n';

    return 0;
}