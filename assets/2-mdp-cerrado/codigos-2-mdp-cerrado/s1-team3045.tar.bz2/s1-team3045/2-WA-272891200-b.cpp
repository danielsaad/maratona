#include <bits/stdc++.h>

using namespace std;

int main() {
    cin.tie(0);
    cout.tie(0);

    long double a;
    cin >> a;

    long double sine = sin(a);
    long double cossine = cos(a);

    if (sine == cossine) {
        cout << "Ambos";
    } else if (sine > cossine) {
        cout << "Saad";
    } else {
        cout << "Costa";
    }
    cout << '\n';

    return 0;
}