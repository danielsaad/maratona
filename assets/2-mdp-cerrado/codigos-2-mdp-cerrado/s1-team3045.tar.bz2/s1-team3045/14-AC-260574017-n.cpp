#include <bits/stdc++.h>

using namespace std;
#define int long long 

int32_t main()
{
    int h1,m1,h2,m2;
    char c;
    cin >> h1 >> c >> m1;
    cin >> h2 >> c >> m2;
    if (m1 < m2)
    {
        h1--;
        m1+=60;
    } 
    m1-=m2;
    h1-=h2;
    if(h1 < 10)cout<<0;
    cout << h1 << c;
    if(m1 < 10) cout << 0;
    cout << m1;
    return 0;
}