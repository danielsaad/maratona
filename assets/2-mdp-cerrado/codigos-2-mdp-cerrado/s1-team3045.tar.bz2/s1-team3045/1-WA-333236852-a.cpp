#include <bits/stdc++.h>

using namespace std;
#define int long long
#define endl '\n'
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;
const int MOD = 998244353;

int32_t main()
{   
    sws;
    int n,c;

    cin >> n >> c;
    vector<int> pred(n);
    for(int i = 0; i < n; i++)
    {
        cin >> pred[i];
    }
    for(int i = 0; i < c; i++)
    {
        int x,y;
        cin >> x >> y;
        pred[x-1] +=y;
    }
    set<int> aux;
    aux.insert(pred[0]);
    for(int i = 1; i < n; i++)
    {
        cout << aux.size() << endl;

        while(!aux.empty())
        {
            auto it = aux.begin();
            if((*it) <= pred[i] ) aux.erase(it);   
            else break;
        }
        aux.insert(pred[i]);
    }
    return 0;
}