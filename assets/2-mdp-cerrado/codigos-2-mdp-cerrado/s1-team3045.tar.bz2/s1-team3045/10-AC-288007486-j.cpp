#include <bits/stdc++.h>

using namespace std;
#define int long long 
#define rep(i,a,b) for(int i = a;i<b;i++)
typedef vector<int> vi;
typedef vector<vi> vvi;

int get_num(char a){
    if(a=='C')return 1;
    if(a=='E')return 0;
    return 2;
}

int32_t main(){
    int n;cin>>n;
    vi v;
    string s;cin>>s;
    rep(i,0,n){
        v.push_back(get_num(s[i]));
    }
    vvi dp(n,vi(3,0));
    dp[0][get_num(s[0])]=1;
    int ans=1;
    rep(i,1,n){
        rep(j,0,3){
            rep(k,0,3){
                if(abs(k-j)==2)continue;
                dp[i][j]=max(
                    dp[i][j],
                    (v[i]==j) + dp[i-1][k]
                );
            }
            ans=max(ans,dp[i][j]);
        }
    }
    cout<<ans;
}