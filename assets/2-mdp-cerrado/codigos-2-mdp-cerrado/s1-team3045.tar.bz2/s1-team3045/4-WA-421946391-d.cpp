#include <bits/stdc++.h>

using namespace std;
#define int long long
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;

int32_t main(){
    sws

    int n,m;
    cin>>n>>m;
    string s;cin>>s;
    rep(i,0,m){
        string t;cin>>t;
        int ans = t.size()+s.size();
        int j = 0;
        for (; j < t.size() && j < s.size() && t[j] == s[j]; j++) ;
        ans-=j;
        cout<<ans<<"\n";
    }


                                                                                                             
}