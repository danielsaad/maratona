#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;
const int MOD = 998244353;
const int MAXN = 1e7+5;
bool not_prime[MAXN];
vector<int> primos;
void crivo()
{
    for(int i = 2; i*i <= (MAXN); i++) 
    {
        if(not_prime[i] == 0)
        {
            primos.push_back(i);
            for(int j = 2; j*i < MAXN; j++)
            {
                not_prime[j*i] = 1;
            }
        }
    }
}
int32_t main()        

{       
    sws
    crivo();
    int n;
    cin >> n;
    vector<int> v;
    map<int,int> mp;

    // cout<<primos.size()<<"\n";
// 
    // rep(i,0,10)cout<<primos[i]<<" ";
    // cout<<"\n";

    for(int i = 0; i < n; i++){
        int x;cin>>x;
        // cout<<"i\n";
        for(auto p:primos){
            if(p>x)break;
            while(x%p==0){
                mp[p]++;
                x/=p;
                // cout<<p<<" ";
            }
        }
        if(x>1){
            mp[x]++;
            // cout<<x<<" ";
        }
        // cout<<"\n\n";
    }

    // for(auto c:mp){
    //     cout<<c.first<<" "<<c.second<<"\n";
    // }
    vector<ll> resp;
    for(auto [x,y] : mp){
        ll xx = (ll)x*(ll)y;
        resp.push_back(xx);
    }
    sort(resp.begin(), resp.end(), greater<ll>());
    ll ans = 0;
    for(int i = 0; i < resp.size(); i++)
    {
        ans += ((i%2)? 0:resp[i]);
    }
    cout << ans << endl;
    return 0;
}