#include <bits/stdc++.h>

using namespace std;
#define int long long
#define rep(i,a,b) for(int i = a;i<b;i++)
#define sws ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef vector<int> vi;
typedef vector<vi> vvi;

int32_t main(){
    sws

    int n,m;
    cin>>n>>m;
    string s;cin>>s;

    vi first_pos(27,n);
    rep(i,0,n){
        first_pos[s[i]-'a']=min(first_pos[s[i]-'a'],i);
    }
    rep(i,0,m){
        string t;cin>>t;
        int ts = t.size();
        int ans = max(t.size(),s.size());
        rep(j,0,t.size()){
            rep(k,0,27){
                if(k==(t[j]-'a'))continue;
                ans=max(ans,
                        ts-j + n - first_pos[k]    
                );
            }
        }
        cout<<ans<<"\n";
    }


                                                                                                             
}