#include <bits/stdc++.h>

using namespace std;
#define int long long 
#define dbg(x) cout<<#x<<" "<<x<<"\n";
#define rep(i,a,b) for(int i = a;i<b;i++)

vector<string> split(string &s){
    vector<string> ans;
    string cur ="";
    for(auto &c:s){
        if(c==' '){
            ans.push_back(cur);
            cur = "";
        } else{
            cur+=c;
        } 
    }
    ans.push_back(cur);
    return ans;
}

string treat_unique(string s){
    string ans="";
    int n = s.size();
    vector<string> splitted = split(s);
    if(s[n-2]=='(' && s[n-1]==')'){
        ans=("LEIA "+splitted[0]);
    }else{
        bool accum=false;
        string add = "";
        for(auto c:s){
            if(accum){
                if(c==')'){
                    break;
                }else{
                    add+=c;
                }
            }else{
                if(c=='(')accum=true;
            }
        }
        ans = "APRESENTE "+add; 
    }
    return ans;
}
int32_t main(){
    vector<string>v;
    string x;
    while(cin>>x){
        v.push_back(x);
    }
      
    // for(auto c:v)cout<<c<<"\n";
    int l = 0;
    int n = v.size();
    while(l<n){
        // dbg(v[l])
        if(v[l]=="if"){
            cout<<"SE ";
            l++;
            while(v[l].back()!=':'){
               cout<<v[l]<<" ";
               l++;
            }
            int m = v[l].size();
            cout<<v[l].substr(0,m-1)<<" ";
            l++;
            cout<<"ENTAO ";
            continue;
        }

        if(v[l]=="while"){
            cout<<"ENQUANTO ";
            l++;
            while(v[l].back()!=':'){
               cout<<v[l]<<" ";
               l++;
            }
            int m = v[l].size();
            cout<<v[l].substr(0,m-1)<<" ";
            l++;
            continue;
        }


         
        if(v[l].substr(0,5)=="print"){
            cout<<"APRESENTE ";
            int ptr =6;
            int cnt = 0;
            while (true){
                
                if((l == v.size()-1) && (ptr == v[l].size() - 1))
                {
                    l++;
                    break;
                }
                cout<<v[l][ptr];
                ptr++;
                if(ptr>=v[l].size()){
                    cout<<" ";ptr=0;
                    l++;
                }
                if(cnt > 15) break;
                cnt++;
            }
            continue;
        }

        cout<<"LEIA "<<v[l];
        cout << '\n';
        return 0;

 
    }
    cout << '\n';
    // if(v.size()==1){
    //     cout<<treat_unique(v[0]);
    //     return 0;
    // }
    // vector<string> first_line = split(v[0]);
    
    // if(first_line[0]=="while"){
    //     int m = first_line[1].size();
    //     string condition = first_line[1].substr(0-1);
    //     cout<<"ENQUANTO "<< condition<<" ";
    //     cout<<treat_unique(first_line[1]);
    // }else{
    //     cout<<"SE ";
    //     int m = v[0].size();
    //     cout<<v[0].substr(3,m-3)<<" ";
    //     cout<<treat_unique(first_line[1]);
    // }
}