#include <bits/stdc++.h>
using namespace std;

int main(){
    int p, construcao,x;
    cin >> p >> construcao;

    vector<int> predio;
    for(int i=0; i<p; i++){
        cin >> x;
        predio.push_back(x);
    }

    int mes,altura;
    for(int i=0; i<construcao; i++){
        cin >> mes >> altura;
        predio[mes-1] += altura;
    }


    for(int i=1; i<p; i++){
        int maior=0;
        int ans=0;
        for(int j=i-1; j>=0; j--){
            if(predio[j]>=maior){ 
                maior = predio[j];
            }
        }
        if(predio[i]<maior){
            maior=0;
            for(int j=i-1; j>=0; j--){
                if(predio[j]>maior){ 
                    ans++;
                    maior = predio[j];
                }
            }
            cout << ans << '\n';
        }
        else{
            maior=0;
            for(int j=i-1; j>=0; j--){
                if(predio[j]>=maior){ 
                    ans++;
                    maior = predio[j];
                }
            }
            cout << ans << '\n';
        }
    }

    return 0;
}