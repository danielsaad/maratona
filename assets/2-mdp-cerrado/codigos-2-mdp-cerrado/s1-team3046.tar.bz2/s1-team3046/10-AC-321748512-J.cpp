#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;

    char pos = 'C';
    string s;
    cin >> s;

    int acerto=0;
    int erro=0;
    for(int i=0; i<n; i++){
        if(s[i]=='E' and pos=='D'){
            erro++;
            pos = 'C';
        } 
        else if(s[i]=='D' and pos=='E'){
            erro++;
            pos = 'C';
        } 
        else{
            acerto++;
            pos = s[i];
        } 
    }

    cout << acerto << '\n';
}