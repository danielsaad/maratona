#include <stdio.h>


int main(){
    int horaM,minM,horaF,minF;
    char pontos;
    scanf("%d %c %d %d %c %d", &horaM, &pontos, &minM, &horaF, &pontos, &minF ); 

    int marcado = horaM*60 + minM;
    int fim = horaF*60 + minF;

    int total = marcado - fim;

    int horas = total/60;
    int minutos = total%60;
    
    printf( "%.2d:%.2d\n", horas, minutos);

    return 0;       
}