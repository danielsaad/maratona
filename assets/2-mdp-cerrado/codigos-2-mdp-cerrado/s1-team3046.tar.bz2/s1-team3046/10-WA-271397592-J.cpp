#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;

    char pos = 'C';
    string s;
    cin >> s;

    int ans=0;
    for(int i=0; i<n; i++){
        if(s[i]=='E' || pos=='D') n--;
        else if(s[i]=='D' || pos=='E') n--;
        pos = s[i];
    }

    cout << n << '\n';
}