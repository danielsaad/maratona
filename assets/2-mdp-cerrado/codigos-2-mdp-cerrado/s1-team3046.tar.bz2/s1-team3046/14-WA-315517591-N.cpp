#include <bits/stdc++.h>
using namespace std;

int main(){
    int horaM,minM,horaF,minF;
    char pontos;
    cin >> horaM >> pontos >> minM >> horaF >> pontos >> minF;

    int marcado = horaM*60 + minM;
    int fim = horaF*60 + minF;

    int total = marcado - fim;

    int horas = total/60;
    int minutos = total%60;

    if(marcado < fim) cout << "00 : 00";
    else if(horas ==0 and minutos==0)cout << "00 : 00";
    else if(horas < 10 and minutos<10)cout << "0" << horas << " : 0" << minutos;
    else if(horas < 10 and minutos==0)cout << "0" << horas << " : 00";
    else if(minutos==0)cout << horas << " : 00";
    else if(minutos<10)cout << horas << " : 0" << minutos;
    else if(horas < 10)cout << "0" << horas << " : " << minutos;
    else cout << horas << " : " << minutos; 

    return 0;       
}