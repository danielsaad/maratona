#include <bits/stdc++.h>
using namespace std;

int main(){
    int a;
    cin >> a;

    if(a>45) cout << "Saad" << '\n';
    else if(a<45) cout << "Costa" << '\n';
    else cout << "Ambos" << '\n';

    return 0;
}