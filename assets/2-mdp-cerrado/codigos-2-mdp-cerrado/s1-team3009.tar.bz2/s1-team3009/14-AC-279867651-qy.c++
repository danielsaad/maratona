#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;

int main(){
    
      int hf, mf, ha, ma, h, m;
      char p;
      cin >> hf >> p  >> mf;
      cin >> ha >> p >> ma;
      
      m = mf-ma;
      h = hf-ha;

      if(m<0){
        h--;
        m+=60;
      }

      
      if(m==0){
        if(h==0){
            cout << "00" << ":" << "00" << endl;
        }
        else if(h<10){
            cout << "0" << h << ":" << "00" << endl;
        }
        else{
            cout << h << ":" << "00" << endl;
        }
        
      } 
      else if(m<10){
        if(h==0){
            cout << "00" << ":" << "0" << m << endl;
        }
        else if(h<10){
            cout << "0" << h << ":" << "0" << m << endl;
        }
        else{
            cout << h << ":" << "0" << m << endl;
        }
        
      }
      else{
        if(h==0){
            cout << "00" << ":" << m << endl;
        }
        else if(h<10){
            cout << "0" << h << ":" << m << endl;
        }
        else{
            cout << h << ":" << m << endl;
        }
        
      }
      
}
