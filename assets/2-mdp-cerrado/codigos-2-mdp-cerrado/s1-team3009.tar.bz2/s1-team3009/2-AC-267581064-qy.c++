#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;

int main(){
    FASTIO
     double x;

     cin >> x;

     if (x == 45)
      cout <<"Ambos";
    if (x < 45)
      cout << "Costa";
    if (x>45)
      cout << "Saad";
    return 0;
}
