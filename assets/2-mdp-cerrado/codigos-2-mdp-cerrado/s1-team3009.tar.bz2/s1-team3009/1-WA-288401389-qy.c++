#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;

int main(){
    
      ll n, c;
      cin >> n >> c;
      ll predio[n];
      for(int i = 0; i < n; i++){
        cin >> predio[i];
      }
      for(int i = 0; i < c; i++){
        ll m, incremento;
        cin >> m >> incremento;
        for(int j = 0; j < m; j++){
            predio[j] += incremento;
        }
      }
      ll imaior = 0, maior = predio[0];
      for(int i = 0; i < n; i++){
        if(i > 0){
            cout << i - imaior << endl;
        }
        if(maior <= predio[i]){
            maior = predio[i];
            imaior = i;
        }
      }

}
