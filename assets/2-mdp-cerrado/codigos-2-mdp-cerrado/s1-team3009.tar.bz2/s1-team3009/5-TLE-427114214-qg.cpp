#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;

vector<ll>pontos;

int main(){
    FASTIO
    ll n;
    cin >> n;
    ll vet[n], max = 0;
    for(ll i = 0; i < n; i++){
        cin >> vet[i];
        if(vet[i] > max) max = vet[i];
    }
    vector<bool> e_primo(max + 1, true);
    vector<ll> primos;
    e_primo[0] = false;
    e_primo[1] = false;
    for(ll i = 2; i <= max; i++){
        if(e_primo[i]){
            primos.pb(i);
            pontos.pb(0);
            for(ll j = i*i; j <= max; j += i){
                e_primo[j] = false;
            }
        }
    }

    for(ll j=0; j<n; j++){
        for(ll i = 0; i < primos.size(); i++){
            if(primos[i]>vet[j]) break; //nao tem como dividir vet a partir dai
                ll m = vet[j];
                while(m%primos[i]==0){
                    pontos[i]+= primos[i];
                    m=m/primos[i];
                }
        }
    }


    sort(pontos.begin(), pontos.end(), greater<>());
    ll tot=0;
    //cout << pontos.size();
    for(ll i=0; i<pontos.size(); i+=2){
        tot+=pontos[i];
        //cout << pontos[i] << ' ';
        //cout << primos[i] << ' ';
    }

    cout << tot << endl;
    

    return 0;
}