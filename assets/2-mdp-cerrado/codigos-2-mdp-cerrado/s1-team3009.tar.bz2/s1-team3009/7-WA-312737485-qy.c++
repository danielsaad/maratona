#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;
int pos, i;
char c;
string s;

int main(){
    FASTIO

    
    while(1){
    getline(cin, s);

    if (s.find("print") != string::npos) {
        cout << "APRESENTE ";
        pos = s.find ("(");
        for (i = pos+ 1; i < s.length() - 1; i++) {
            cout << s[i];
        }
        return 0;
    }

    if (s.find("input()") != string::npos) {
        cout << "LEIA ";
        pos = s.find (" = input()");
        for (i = 0; i <= pos; i++) {
            if (s[i] != ' ')
            cout << s[i];
        }
        return 0;
    }


    if (s.find("if ") != string::npos) {
        cout << "SE ";
        pos = s.find ("if ");
        for (i = 3; i < s.length() -1; i++) {
            cout << s[i];
        }
        cout << " ENTAO ";
    }

    if (s.find("while ") != string::npos) {
        cout << "ENQUANTO ";
        pos = s.find ("while ");
        for (i = 6; i < s.length() -1; i++) {
            cout << s[i];
        }
        cout << " ";
    }

    

    }

    return 0;
}