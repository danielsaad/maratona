#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;

int main(){
    
      ll n, c;
      cin >> n >> c;
      vector<pair<int, int>> obra(c);
      ll predio[n], visiveis[n];
      ll cont = 1;
      visiveis[0] = 0;
      for(int i = 0; i < n; i++){
        cin >> predio[i];
      }
      for(int i = 1; i < n; i++){
        visiveis[i] = cont;
        if(predio[i] < predio[i - 1]){
            cont++;
        }
        else{
            cont = 1;
        } 
      }
      for(int i = 0; i < c; i++){
        ll m, incremento;
        cin >> m >> incremento;
        obra.pb({m, incremento});
      }
      sort(obra.begin(), obra.end());
      for(auto a : obra){
        for(int i = 0; i < a.first; i++){
            predio[i] += a.second;
        }
        cont = 1;
        for(int i = 0; i < n; i++){
            if(i >= a.first - 1){
                visiveis[i] = cont;
            }
            if(predio[i] < predio[i - 1]){
                cont++;
            }
            else{
                cont = 1;
            } 
        }
      }
      for(int i = 1; i < n; i++){
        cout << visiveis[i] << endl;
      }

}