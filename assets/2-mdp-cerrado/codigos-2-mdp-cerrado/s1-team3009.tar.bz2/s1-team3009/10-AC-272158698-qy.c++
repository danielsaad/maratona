#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;

int main(){
    int n;
    cin >> n;
    int jacare = 0;
    int atual, defesas = 0;
    char chutes[n];
    for(int i = 0; i < n; i++){
        cin >> chutes[i];
        if(chutes[i] == 'C') atual = 0;
        else if(chutes[i] == 'D') atual = 1;
        else if(chutes[i] == 'E') atual = -1;
        if(jacare == atual) defesas++;
        if(abs(jacare - atual) == 1){
            defesas++;
            jacare = atual;
        }
        else if(abs(jacare - atual) == 2){
            jacare = 0;
        }
    }
    cout << defesas << '\n';
}
