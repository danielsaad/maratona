#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define endl "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

using namespace std;
int pos, i;
char c;
string s;

int main(){
    FASTIO
    int n;
    cin >> n;
    int vet[n], max = 0;
    for(int i = 0; i < n; i++){
        cin >> vet[i];
        if(vet[i] > max) max = vet[i];
    }
    vector<bool> e_primo(max + 1, true);
    e_primo[0] = false;
    e_primo[1] = false;
    for(int i = 2; i*i <= max; i++){
        if(e_primo[i]){
            for(int j = i*i; j <= max; j += i){
                e_primo[j] = false;
            }
        }
    }

    vector<int>pontos;

    for(int j=0; j<n; j++){
        int p=0;
        for(int i = 2; i <= max; i++){
            if(i>vet[j]) break; //nao tem como dividir vet a partir dai
            if(e_primo[i]){
                pontos.pb(0);
                int m = vet[j];
                while(m%i==0){
                    pontos[p]+=i;
                    m=m/i;
                }
                p++;
            }
        }
    }

    sort(pontos.begin(), pontos.end(), greater<>());
    int tot=0;

    for(int i=0; i<pontos.size(); i+=2){
        if(pontos[i]==0) break;
        tot+=pontos[i];
    }

    cout << tot << endl;
    

    return 0;
}