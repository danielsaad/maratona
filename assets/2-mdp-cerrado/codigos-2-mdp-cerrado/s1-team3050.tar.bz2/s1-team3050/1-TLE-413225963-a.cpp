#include <bits/stdc++.h>

using namespace std;

int main(){
   
    int N,C;
    int A;
    int M = 1;
    int aux = 0;
    
    scanf("%d %d", &N, &C);
    int AP[N];
    for(int i = 0;i<N;i++){
        scanf(" %d", &AP[i]);
    }
    for(int i = 0,j = 0;i<C;){
        if(i == aux){
            scanf("%d %d", &M, &A);
            aux++;    
        }
        if(j!=M){
            AP[j] = AP[j] + A;
            j++;
        }else if(j == M){
            j = 0;
            i++;
        }
    }
    int count = 0;
    int comp = AP[1];
    for(int i = 1,j = i-1;i<N && j >=0;){
        if(AP[j]>comp || j == i-1){
            count++;
            comp = AP[j];
        }
        if(j == 0){
            printf("%d\n", count);
            count = 0;
            i++;
            j= i;
        
        }
        j--;
    }
    

    
    return 0;
}