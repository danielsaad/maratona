#include <bits/stdc++.h>

using namespace std;

int main(){
   
    int N,C;
    int M,A;
    
    scanf("%d %d", &N, &C);
    int AP[N];
    for(int i = 0;i<N;i++){
        scanf(" %d", &AP[i]);
    }
    for(int i = 0;i<C;i++){
        scanf("%d %d", &M, &A);
        for(int j = 0;j<M;j++){
            AP[j] = AP[j] + A;
        }
    }


    for(int i = 1;i<N;i++){
        int count = 0;
        int comp = AP[i];
        for(int j = i-1;j>=0;j--){
            if(AP[j]>comp || j == i-1){
                count++;
                comp = AP[j];
            }
        }
        printf("%d\n", count);
    }
    

    
    return 0;
}