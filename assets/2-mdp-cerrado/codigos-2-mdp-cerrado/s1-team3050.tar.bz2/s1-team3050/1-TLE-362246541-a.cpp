#include <bits/stdc++.h>

using namespace std;

int main(){
   
    long long int N,C;
    long long int M,A;
    
    scanf("%lld %lld", &N, &C);
    long long int AP[N];
    for(long long int i = 0;i<N;i++){
        scanf(" %lld", &AP[i]);
    }
    for(long long int i = 0;i<C;i++){
        scanf("%lld %lld", &M, &A);
        for(long long int j = 0;j<M;j++){
            AP[j] = AP[j] + A;
        }
    }


    for(long long int i = 1;i<N;i++){
        long long int count = 0;
        long long int comp = AP[i];
        for(int j = i-1;j>=0;j--){
            if(AP[j]>comp || j == i-1){
                count++;
                comp = AP[j];
            }
        }
        printf("%lld\n", count);
    }
    

    
    return 0;
}