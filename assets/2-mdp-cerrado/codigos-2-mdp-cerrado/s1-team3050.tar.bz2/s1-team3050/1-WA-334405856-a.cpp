#include <bits/stdc++.h>

using namespace std;

int main(){
   
    int N,C;
    int M,A;
    
    scanf("%d %d", &N, &C);
    int AP[N];
    int VISTA[N-1];
    for(int i = 0;i<N;i++){
        scanf(" %d", &AP[i]);
    }
    for(int i = 0;i<C;i++){
        scanf("%d %d", &M, &A);
        for(int j = 0;j<M;j++){
            AP[j] = AP[j] + A;
        }
    }


    printf("1\n");
    for(int i = 2;i<N;i++){
        int Cont = 1;
        int comp = AP[i];
        for(int j = i-2; j>=0 ; j--){
            if(AP[j] > AP[j+1]){
                Cont++;
            }else{
                break;
            }
        }
        printf("%d\n", Cont);
        Cont = 1; 
    }
    

    
    
    
    
    return 0;
}