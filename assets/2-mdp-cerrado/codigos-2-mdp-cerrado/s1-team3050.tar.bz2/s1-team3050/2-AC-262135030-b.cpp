#include <bits/stdc++.h>

using namespace std;

int main(){
    int a;

    scanf("%d", &a);

    if(a==45){
        printf("Ambos\n");
    } else{
        if(a<45){
            printf("Costa\n");
        } else {
            printf("Saad\n");
        }
    }


    
    return 0;
}