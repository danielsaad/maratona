#include <bits/stdc++.h>

using namespace std;

int main(){

    int hi, mi, he, me;
    int minutos_inicio, minutos_fim;
    int h_restante, m_restante;

    scanf("%d:%d", &he, &me);
    scanf("%d:%d", &hi, &mi);

    minutos_inicio = hi*60 +mi;
    minutos_fim= he*60 + me; 
    h_restante = (minutos_fim - minutos_inicio)/60;
    m_restante = (minutos_fim - minutos_inicio)%60;



    if(m_restante <10 && h_restante<10){
        printf("0%d:0%d\n", h_restante, m_restante);
    }else if(m_restante<10){
        printf("%d:0%d\n", h_restante, m_restante);
    }else if(h_restante <10){
        printf("0%d:%d\n", h_restante, m_restante);
    }else{
        printf("%d:%d\n", h_restante, m_restante);
    }



    return 0;
}