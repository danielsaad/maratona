#include <bits/stdc++.h>

using namespace std;

int main(){
   
    long long int N,C;
    long long int M,A;
    
    scanf("%lld %lld", &N, &C);
    long long int AP[N];
    for(long long int i = 0;i<N;i++){
        scanf(" %lld", &AP[i]);
    }
    for(long long int i = 0;i<C;i++){
        scanf("%lld %lld", &M, &A);
        for(long long int j = 0;j<M;j++){
            AP[j] = AP[j] + A;
        }
    }


    printf("1\n");
    for(long long int i = 2;i<N;i++){
        long long int Cont = 1;
        long long int comp = AP[i];
        for(long long int j = i-2; j>=0 ; j--){
            if(AP[j] > AP[j+1]){
                Cont++;
            }else{
                break;
            }
        }
        printf("%lld\n", Cont);
        Cont = 1; 
    }
    

    
    
    
    
    return 0;
}