#include <bits/stdc++.h>

using namespace std;

int main(){
    int n, count =0;
    char posicao = 'C';
    char chutes[2000000];

    scanf("%d", &n);

    for(int i =0; i<n;i++){
        scanf(" %c", &chutes[i]);
        if((chutes[i]=='E' && posicao=='D') || (chutes[i]=='D' && posicao=='E')){
            posicao= 'C';
        }else{  
            count++;
            posicao= chutes[i];
        }
    }

    printf("%d\n", count);

    

    
    return 0;
}