from math import sin, cos

x = int(input())

s = sin(x)
c = cos(x)

if s == c:
    print("Ambos")
elif c > s:
    print("Costa")
else:
    print("Saad")

