#include <bits/stdc++.h>
using namespace std;

void solve(){
	int n, m;
	cin >> n >> m;

	string s;
	cin >> s;
	
	const int SZ = 'z' -'a' +1;
	 vector<int> prim(SZ, -1);
	for (int i= 0; i <n; i++) {
		char c = s[i]-  'a';
		if (prim[c] != -1) continue;
		prim[c] = i;
	}

	while(m--) {
		string t;
		cin >> t;


		int ans = max(s.size(), t.size()); 

		int pref = 0;
		while(pref < s.size() and pref < t.size() and s[pref] == t[pref]) pref++;

		int ta = s.size(), tb = t.size();
		ans = max(ta + tb - pref, ans);

		vector<int> primt(SZ, -1);
		for (int i= 0; i <t.size(); i++) {
			char c = t[i] - 'a';
			if (primt[c]!=-1) continue;
			primt[c] = i;
		}

		const int oo = INT_MAX;
		{
		int menorprim=oo;
		for (char c = 'a'; c <= 'z'; c++) {
			if (c == t.front()) continue;
			if (prim[c-'a'] == -1)continue;
			menorprim = min(menorprim, prim[c-'a']);
		}
		if (menorprim != oo){
			int decima = n -1 - menorprim+ 1;
			ans = max(ans, decima + (int)t.size());
		}
		}

		{
		int menorprim=oo;
		for (char c = 'a'; c <= 'z'; c++) {
			if (c == s.front()) continue;
			if (primt[c-'a'] == -1)continue;
			menorprim = min(menorprim, primt[c-'a']);
		}
		if (menorprim != oo) {
		int decima = (int)t.size() - 1 - menorprim;
		ans = max(ans, decima + (int)s.size()+1);
		}
		}
		cout << ans << '\n';
	}
	
}

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int t=1;
	// cin >> t;
	while(t--) solve();
}
