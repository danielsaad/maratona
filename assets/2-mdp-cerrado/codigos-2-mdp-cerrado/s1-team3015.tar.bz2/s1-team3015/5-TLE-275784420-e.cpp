#include <bits/stdc++.h>
using namespace std;

const int maxai = 10'000'000 + 100;

using ll = long long;
void solve(){
	ll n;
	cin >> n;

	vector<ll> hist(maxai);
	for (int i = 0; i < n; i++) {
		ll x;
		cin >> x;
		hist[x]++;
	}

	map<ll,ll> pts;
	vector<int> vis(maxai);

	for (int p = 2; p <= maxai; p++) {
		if (vis[p]) continue;

		vis[p] = 1;

		for (int j = p; j <= maxai; j += p) {
			vis[j] = 1;
			if (!hist[j]) continue;

			ll t = 0;
			ll x = j;
			while (x % p == 0) {
				x/=p;
				t++;
			}

			pts[p] += t * p;
		}
	}

	vector<ll> aa;
	for (auto &[a, b] : pts) {
		aa.push_back(b);
	}

	sort(aa.rbegin(), aa.rend());

	ll ans = 0;

	for (int i = 0; i < aa.size(); i+=2)
		ans += aa[i];


	cout << ans << '\n';
}

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int t=1;
	// cin >> t;
	while(t--) solve();
}
