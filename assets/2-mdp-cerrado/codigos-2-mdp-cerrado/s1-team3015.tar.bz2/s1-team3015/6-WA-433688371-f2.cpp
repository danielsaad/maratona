#include <bits/stdc++.h>
using namespace std;

using ll = long long;


const ll mod = 998244353;

ll sum(ll a, ll b) {
	return (a + b) % mod; // may improve this
}

ll sub(ll a, ll b) {
	return (a - b +mod+mod) % mod; // may improve this
}

ll pro(ll a, ll b) {
	return (a * b) % mod; // may improve this
}

ll fpow(ll a, ll b) {
	ll ret=  1;

	while (b) {
		if (b & 1) ret = pro(ret, a);
		b >>= 1;
		a = pro(a, a);
	}
	return ret;
}

ll divm(ll a, ll b) {
	return pro(a, fpow(b,mod-2));
}

using Matrix = vector<vector<ll>>;
Matrix prod(Matrix a, Matrix b) {
	Matrix ret = {
		{0, 0},
		{0, 0}
	};
	
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			for (int k = 0; k < 2; k++) {
				// colocar mod depois
				ret[i][j] = sum(ret[i][j], pro(a[i][k] , b[k][j]));
			}
		}
	}

	return ret;
}

Matrix fpow(Matrix a, ll b) {
	Matrix ret = {
		{1, 0},
		{0, 1}
	};

	while (b) {
		if (b & 1) ret = prod(ret, a);
		b >>= 1;
		a = prod(a, a);
	}
	return ret;
}

tuple<ll, ll, ll> extGcd(ll a, ll b) {
	if (!b) return {a, 1, 0};
	auto [d, x1, y1] = extGcd(b, a % b);
	ll x = y1, y = x1 - y1 * (a/b);
	return {d, x, y};
}

optional<pair<ll,ll>> solve(ll a, ll b, ll c) {
	if (a == 0 and b == 0) {
		if (c) return nullopt;
		else return pair<ll,ll>{0,0};
	}


	auto [g, x0, y0] = extGcd(a < 0 ? a * -1 : a, b <0 ? b*-1 :b);
	if (c % g)  return nullopt;

	x0 *= c / g;
	y0 *= c/g;
	if ( a< 0) x0 =  -x0;
	if ( b< 0) y0 =  -y0;


	pair<ll,ll> ret {x0, y0};
	return ret;
}

void solve(){
	ll A, B, N, M, VN, VM;
	cin >> A >> B >> N >> M >> VN >> VM;

	vector<vector<ll>> M0 = {
		{0, 1},
		{B, A},
	};

	// o que faz quando n ou m eh 0 ??
	auto Mn = fpow(M0, N);
	auto Mm = fpow(M0, M);

	ll C0n = Mn[1][0];
	ll C1n = Mn[1][1];
	//cerr <<  " C0n: " << C0n << " " 
	//	 <<  " C1n: " << C1n << endl;

	ll C0m = Mm[1][0];
	ll C1m = Mm[1][1];
	//cerr <<  " C0m: " << C0m << " " 
	//	 <<  " C1m: " << C1m << endl;


	{
		ll a = sum(C1n , C1m);
		ll b = sum(C0n , C0m);
		ll c = sum(VN , VM);

		//cerr <<"abc: "  << a << ' ' << b << ' ' << c << endl;

		ll up = sub(pro(VM,C0n), pro(VN,C0m));
		ll down = sub(pro(C1m,C0n), pro(C1n,C0m));
		ll f1 = divm(up , down);
		//cerr << " f1: "  << f1 << endl;


		up = sub(VN, pro(f1,C1n));
		down = C0n;
		ll f0 = divm(up, down);
		//cerr << " f0: "  << f0 << endl;

		cout << f1 << ' ' << f0 << endl;


	}
}

signed main(){
//	ios_base::sync_with_stdio(false);
//	cin.tie(0);
	int t=1;
	cin >> t;
	while(t--) solve();
}
