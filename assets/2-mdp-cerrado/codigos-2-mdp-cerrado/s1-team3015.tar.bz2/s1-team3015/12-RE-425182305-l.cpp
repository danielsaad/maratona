#include <bits/stdc++.h>
using namespace std;

const int maxn = 1002;
const int MAX = (maxn * (maxn+1)) /2; 

using ll = long long;
int totAsks=  0;
int n;
pair<bool, int> ans(int x, vector<vector<int>> &graph, vector<int> &rep, bool first) {
	bool has_one = false;
	for (auto c : graph[x]) {
		// cout << "c " << c << " " << rep[c] << "\n";
		if (rep[c] != -1) continue;
		if (has_one and not first) return make_pair(false, x);

		int r;
		if (totAsks >= n + 10-2) {
			assert(false);
		}
		cout << "? " << c << endl; 
		totAsks++;
		cin >> r; 

		has_one |= r;

		rep[c] = r;
		if (r) {
			auto [found, res] = ans(c, graph, rep, false);

			if (found)
				return make_pair(found, res);
		}

	}

	return make_pair(true, x);
}
				
void solve(){
	cin >> n;

	n += 2;

	int qt = 0, curr = 1;
	queue<pair<int, int>> q;
	vector<vector<int>> graph(MAX, vector<int>());
	vector<int> rep(MAX, -1);
	rep[1] = 1;

	for(int i = 1; i <= n; i++) {
		++qt;
		vector<int> later;
		for(int j = 0; j < qt; j++) {
			if(q.size()) {
				auto &[fi, fq] = q.front();
				++fq;

				graph[fi].emplace_back(curr);
				 //cout << "emplace " << fi << " " << curr << "\n";
				if(fq >= 2) {
					q.pop();
					
					if (q.size()) {
						auto &[a, b] = q.front();

						 //cout << "emplace " << a << " " << curr << "\n";
						graph[a].emplace_back(curr);
						b++;
					}
				}
			}

			if (i == n) rep[curr] = 0;
			later.emplace_back(curr);
			curr++;
		}

		for(auto x : later)
			q.emplace(x, 0);
	}

	for(int i = 1; i <= MAX; i++) {
		auto [found, res] = ans(1, graph, rep, true);

		if (found) {
			cout << "! " << res << endl;
			break;
		}
	}
}

signed main(){
	/*
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	*/
	int t=1;
	// cin >> t;
	while(t--) solve();
}
