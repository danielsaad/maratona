#include <bits/stdc++.h>
using namespace std;

void solve(){
	int n, m;
	cin >> n >> m;

	string s;
	cin >> s;
	
	while(m--) {
		string t;
		cin >> t;
		int ans = max(s.size(), t.size()); 

		int pref = 0;
		while(pref < s.size() and pref < t.size() and s[pref] == t[pref]) pref++;

		int ta = s.size(), tb = t.size();
		ans = max(ta + tb - pref, ans);
		cout << ans << '\n';
	}
	
}

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int t=1;
	// cin >> t;
	while(t--) solve();
}
