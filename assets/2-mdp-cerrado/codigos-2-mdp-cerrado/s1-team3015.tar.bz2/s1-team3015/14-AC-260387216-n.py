ha, ma = map(int, input().split(":"))
hb, mb = map(int, input().split(":"))

ta = (ha * 60) + ma
tb = (hb * 60) + mb

ht = (ta - tb) // 60
mt = (ta - tb) % 60

print(f"{ht:02}:{mt:02}")
