#include <bits/stdc++.h>
using namespace std;

void solve(){
	int n, m;
	cin >> n >> m;

	string s;
	cin >> s;
	
	map<char,int> prim;
	for (int i= 0; i <n; i++) {
		char c = s[i];
		if (prim.count(c)) continue;
		prim[c] = i;
	}

	while(m--) {
		string t;
		cin >> t;

		map<char,int> primt;
		for (int i= 0; i <t.size(); i++) {
			char c = t[i];
			if (primt.count(c)) continue;
			primt[c] = i;
		}

		int ans = max(s.size(), t.size()); 

		int pref = 0;
		while(pref < s.size() and pref < t.size() and s[pref] == t[pref]) pref++;

		int ta = s.size(), tb = t.size();
		ans = max(ta + tb - pref, ans);


		const int oo = INT_MAX;
		{
		int menorprim=oo;
		for (char c = 'a'; c <= 'z'; c++) {
			if (c == t.front()) continue;
			if (!prim.count(c))continue;
			menorprim = min(menorprim, prim[c]);
		}
		if (menorprim != oo){
			int decima = n -1 - menorprim+ 1;
			ans = max(ans, decima + (int)t.size());
		}
		}

		{
		int menorprim=oo;
		for (char c = 'a'; c <= 'z'; c++) {
			if (c == s.front()) continue;
			if (!primt.count(c))continue;
			menorprim = min(menorprim, primt[c]);
		}
		if (menorprim != oo) {
		int decima = (int)t.size() - 1 - menorprim;
		ans = max(ans, decima + (int)s.size()+1);
		}
		}
		cout << ans << '\n';
	}
	
}

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int t=1;
	// cin >> t;
	while(t--) solve();
}
