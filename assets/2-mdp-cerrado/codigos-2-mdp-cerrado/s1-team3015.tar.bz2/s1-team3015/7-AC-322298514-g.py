from re import match 
ans = []

while True:
    try:
        s = input().strip()
        
        r = match(r'(.*) = input\(\)', s)
        
        if r is not None:
            ans.append(f"LEIA {r.group(1)}")

        r = match(r'print\((.*)\)', s)
        
        if r is not None:
            ans.append(f"APRESENTE {r.group(1)}")

        r = match(r'if (.*):', s)
        
        if r is not None:
            ans.append(f"SE {r.group(1)} ENTAO")

        r = match(r'while (.*):', s)
        
        if r is not None:
            ans.append(f"ENQUANTO {r.group(1)}")

    except EOFError:
        print(' '.join(ans))
        break
