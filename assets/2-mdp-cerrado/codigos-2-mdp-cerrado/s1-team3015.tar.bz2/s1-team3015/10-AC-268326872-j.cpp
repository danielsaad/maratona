#include <bits/stdc++.h>
using namespace std;

void solve(){
	int n;
	cin >> n;
	string s;
	cin >> s;
	vector<int> dp(3, -900000);
	dp[1]=0;
	for(int i=0; i<n; ++i){
		vector<int> nxt_dp = dp;
		// esquerda
		nxt_dp[0]=max(dp[0], dp[1]);
		// centro
		nxt_dp[1]=max({dp[1],dp[0],dp[2]});
		// direita
		nxt_dp[2]=max(dp[2],dp[1]);
		if(s[i]=='C') nxt_dp[1]++;
		if(s[i]=='E') nxt_dp[0]++;
		if(s[i]=='D') nxt_dp[2]++;
		swap(dp,nxt_dp);
	}
	cout << *max_element(dp.begin(),dp.end()) << endl;
}

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int t=1;
	// cin >> t;
	while(t--) solve();
}
