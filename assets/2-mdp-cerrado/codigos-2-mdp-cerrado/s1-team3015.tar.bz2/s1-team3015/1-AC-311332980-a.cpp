#include <bits/stdc++.h>
using namespace std;

using ll = long long;

template <typename T = ll,
	 	auto cmp = [](T& src1, T& src2, T& dst) { dst = max(src1, src2); }>
struct Sparse {
	int sz;
	vector<int> logs;
	vector<vector<T>> st;
	Sparse(const vector<T>&v) : sz(v.size()), logs(sz+1) {
		for (int i = 2; i < sz + 1; i++) logs[i] = logs[i>>1] + 1;
		st.resize(logs[sz] + 1, vector<T>(sz));

		for (int i = 0; i < sz; i++) st[0][i] = v[i];
		for (int k = 1; (1<<k) <= sz; k++) {
			for (int i = 0; i + (1<<k) <= sz; i++) {
				cmp(st[k-1][i], st[k-1][i+(1<<(k-1))], st[k][i]);
			}
		}
	}

	T query(int l, int r) {
		r++;
		const int k = logs[r-l];
		T ret;
		cmp(st[k][l], st[k][r-(1<<k)], ret);
		return ret;
	}

};
void solve(){
	int n, q;
	cin >> n >> q;

	vector<ll> xs(n); for (auto & xi : xs) cin >> xi;

	vector<vector<ll>> qs(n);
	for (int i = 0; i < q; i++) {
		ll ts, v;
		cin >> ts >> v;
		
		// rever se isso faz sentido mesmo
		if (ts >= n) continue;

		qs[ts].push_back(v);

	}

	ll acc = 0;
	for (int i = 0; i < n; i++) {
		for (auto x : qs[i]) acc += x;
		xs[i] -= acc;
	}


	Sparse st(xs);

	vector<int> psum(n+2);

	for (int i = 0; i < n; i++) {
		ll xi = xs[i];
		int i2 = i;

		int l = i + 1, r=  n -1;
		for (l = i+1, r = n - 1; l <= r; ) {
			int m = midpoint(l, r);

			ll mx = st.query(i+1, m);
			//cerr << " qry:  " << l << ' ' << r << ' '  << mx << endl;
			if (mx < xi) {
				i2 = max(i2, m);
				l = m + 1;
			}
			else r =  m - 1;
			//cerr << " after:  " << l << ' ' << r << ' '  << endl;
		}


		//cerr << i << ' '   << i2 << '\n';

		psum[i+1]++;
		psum[i2+2]--;
	}


	for (int i = 1; i < n; i++) {
		psum[i] += psum[i-1];
	}

	for (int i = 1; i < n; i++) {
		cout << psum[i] << '\n';
	}


}

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int t=1;
	// cin >> t;
	while(t--) solve();
}
