from math import sin, cos

x = int(input())


if x == 45:
    print("Ambos")
elif x < 45:
    print("Costa")
else:
    print("Saad")

