#include <bits/stdc++.h>
using namespace std;

int main(){
    int a; cin >> a;
    double cose = cos(a); 
    double seno = sin(a);

    if(seno > cose){
        cout << "Saad" << endl;
    } else if (cose > seno){
        cout << "Costa" << endl;
    } else if (seno == cose) {
        cout << "Ambos";
    }

    return 0;
}