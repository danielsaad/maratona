angle=int(input())
if angle<45:
    print('Costa')
elif angle>45:
    print('Saad')
else:
    print('Ambos')