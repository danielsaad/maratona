position='C'
kick_count=int(input())
kicks=input()
wrongs_count=0
for it in range(kick_count):
    if kicks[it]=='C':
        if position=='C':
            continue
        elif position=='D':
            position='C'
        elif position=='E':
            position='C'
    elif kicks[it]=='D':
        if position=='C':
            position='D'
        elif position=='D':
            continue
        elif position=='E':
            position='C'
            wrongs_count+=1
    elif kicks[it]=='E':
        if position=='C':
            position='E'
        elif position=='D':
            position='C'
            wrongs_count+=1
        elif position=='E':
            continue
print(str(kick_count-wrongs_count))

