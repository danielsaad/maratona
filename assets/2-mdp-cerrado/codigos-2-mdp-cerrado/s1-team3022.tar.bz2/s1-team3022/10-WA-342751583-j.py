count=int(input())
moves=input()
defense_count=0
major_count=False
for it in range(len(moves)-1):
    if major_count:
        if moves[it]=='D' and moves[it+1]=='E':
            defense_count+=1
        elif moves[it]=='E' and moves[it+1]=='D':
            defense_count+=1
    major_count=True
print(str(count-defense_count))