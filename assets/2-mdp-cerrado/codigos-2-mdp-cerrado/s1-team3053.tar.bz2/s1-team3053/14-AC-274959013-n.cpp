#include <bits/stdc++.h>

using namespace std;
#define endl '\n'

int get(string t){
    int v0 = t[0] - '0';
    int v1 = t[1] - '0';
    return v0 * 10 + v1; 
}

string ss(int x) {
    if (x >= 10) return to_string(x);
    else return "0" + to_string(x);
}
void solve() {
    string f;
    cin >> f;
    string a;
    cin >> a;
    int ff = get(f.substr(0, 2)) * 60 + get(f.substr(3, 2));
    int aa = get(a.substr(0, 2)) * 60 + get(a.substr(3, 2));
    int d = ff - aa;
    cout << ss(d / 60) << ":" << ss(d%60) << endl;
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}