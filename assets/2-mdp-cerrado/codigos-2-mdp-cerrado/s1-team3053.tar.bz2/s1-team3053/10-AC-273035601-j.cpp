#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define pb push_back

void solve() {
    int N; cin >> N;
    string s; cin >> s;
    vector<int> v;
    for(auto c : s) {
        if(c == 'E') v.pb(0);
        else if(c == 'C') v.pb(1);
        else v.pb(2);
    }
    int ans = N;
    bool b = 1;
    for(int i = 1; i < N; i++) {
        if(b and (abs(v[i] - v[i-1]) > 1)) {
            b = 0;
            ans--;
        } else {
            b = 1;
        }
    }
    cout << ans << endl;
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}