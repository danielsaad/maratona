#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define ll long long
#define rep(i, a, b) for(int i = (a); i < (b); i++)
#define sz(s) (int)s.size()

constexpr ll oo = ((unsigned ll)-1) >> 1;

#define vi vector<int>
vi Z(const string & s){
    int n = sz(s);
    vi z(n); int l = -1, r = -1;
    rep(i,1,n){
        z[i] = i >= r ? 0 : min(r-i, z[i-l]);
        while(i + z[i] < n and s[i+z[i]] == s[z[i]])z[i]++;
        if (i + z[i] > r)l = i, r = i + z[i];
    }
    return z;
}

void solve() {
    string sb, s, t; cin >> sb >> t;
    s = sb;
    vi w(sz(s));
    for(int& x : w)cin >> x;
    while(sz(s) < sz(t))for(char c : sb)s.push_back(c);
    int n = sz(s), m = sz(t);
    auto wb = w;
    while(w.size() < s.size())for(int x : wb)w.push_back(x);
    string comp = t + "#" + s + s;
    int k = m + 1 + n + n;
    auto z = Z(comp);
    vector ans(k+1, 0ll);
    vector mat(k+1, 0);
    for(int i = k-1; i > m; i--){
        if (z[i] == m){
            int pos = (i-m-1)%n;
            ans[i] = w[pos] + ans[i+m];
            mat[i] = m + mat[i+m];
        }
        else {
            mat[i] = z[i];
        }
    }
    int mx_mat = 0;
    ll mx_ans = 0;
    rep(i,0,k)mx_mat = max(mx_mat, mat[i]), mx_ans = max(mx_ans, ans[i]);
    if (mx_mat >= n)cout << -1 << endl;
    else cout << mx_ans << endl;
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}