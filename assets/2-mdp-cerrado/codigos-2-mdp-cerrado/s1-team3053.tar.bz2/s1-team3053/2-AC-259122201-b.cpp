#include <bits/stdc++.h>

using namespace std;
#define endl '\n'

void solve() {
    int a; cin >> a;
    if (a == 45)cout << "Ambos" << endl;
    else if (a < 45)cout << "Costa" << endl;
    else cout << "Saad" << endl;
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}