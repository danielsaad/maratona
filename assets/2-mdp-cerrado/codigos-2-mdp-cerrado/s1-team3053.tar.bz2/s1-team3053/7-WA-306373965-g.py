def ler(s):
    s = s.strip()
    v, e, i = s.split()
    print("LEIA", v)

def escrever(s):
    s = s.strip()
    print("APRESENTE", s[6:-1])

def cond(s):
    s = s.strip()
    i, v1, e, v2 = s.split()
    v2 = v2[:-1]
    print("SE", v1, e, v2, "ENTAO", end=" ")

def loop(s):
    s = s.strip()
    w, v1, e, v2 = s.split()
    v2 = v2[:-1]
    print("ENQUANTO", v1, e, v2, end=" ")

def handle():
    try:
        l = input()
        if 'input' in l:
            ler(l)
        elif 'print' in l:
            escrever(l)
        elif 'while' in l:
            loop(l)
        else:
            cond(l)
    except:
        pass

handle()
handle()