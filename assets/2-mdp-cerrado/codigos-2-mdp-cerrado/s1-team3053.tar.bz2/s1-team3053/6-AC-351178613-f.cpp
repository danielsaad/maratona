#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define ll long long
#define rep(i, a, b) for(int i = (a); i < (b); i++)

constexpr ll oo = ((unsigned ll)-1) >> 1;
constexpr int MOD = 998244353;

int mul(int a, int b){return (int)((ll)a*b%MOD);}
int add(int a, int b){return a+b < MOD ? a+b : a+b-MOD;}
int sub(int a, int b){return a < b ? a+MOD-b : a-b;}

using mat = array<int, 4>;
mat mul(mat a, mat b){
    mat res;
    res[0] = add(mul(a[0], b[0]), mul(a[1], b[2]));
    res[1] = add(mul(a[0], b[1]), mul(a[1], b[3]));
    res[2] = add(mul(a[2], b[0]), mul(a[3], b[2]));
    res[3] = add(mul(a[2], b[1]), mul(a[3], b[3]));
    return res;
}

int fexp(int a, int b){
    int res = 1;
    while(b){
        if (b&1) res = mul(res, a);
        a = mul(a, a);
        b >>= 1;
    }
    return res;
}

int inv(int a){return fexp(a, MOD-2);}

mat fexp(mat a, int b){
    mat res = {1, 0, 0, 1};
    while(b){
        if (b&1) res = mul(res, a);
        a = mul(a, a);
        b >>= 1;
    }
    return res;
}


void solve() {
    int a, b, n, m, vn, vm; cin >> a >> b >> n >> m >> vn >> vm;
    mat m1 = {0, 1, b, a};

    mat m1_a_m_menos_1 = fexp(m1, m-1);
    int g_m_menos_1 = m1_a_m_menos_1[1], g_m = m1_a_m_menos_1[3];

    mat m1_a_n_menos_1 = fexp(m1, n-1);
    int g_n_menos_1 = m1_a_n_menos_1[1], g_n = m1_a_n_menos_1[3];

    mat m1_a_m_menos_n = fexp(m1, m-n);
    int g_m_menos_n = m1_a_m_menos_n[1];

    int f1 = mul(sub(mul(vn, g_m_menos_1), mul(vm, g_n_menos_1)), inv(mul(g_m_menos_n, fexp(sub(0, b), n-1))));
    int f0 = mul(sub(mul(vn, g_m), mul(vm, g_n)), inv(mul(g_m_menos_n, fexp(sub(0, b), n))));
    cout << f0 << ' ' << f1 << endl;
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
}