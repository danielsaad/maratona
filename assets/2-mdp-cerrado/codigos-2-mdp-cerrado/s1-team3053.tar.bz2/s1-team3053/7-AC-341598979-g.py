def ler(s):
    print("LEIA", s[:-10])

def escrever(s):
    print("APRESENTE", s[6:-1])

def cond(s):
    c = s[3:-1]
    print("SE", c, "ENTAO", end=" ")

def loop(s):
    c = s[6:-1]
    print("ENQUANTO", c, end=" ")

def handle():
    l = input().strip()
    if l[-7:] == 'input()':
        ler(l)
    elif l[:6] == 'print(' and l[-1] == ')':
        escrever(l)
    elif l[:5] == 'while' and l[-1] == ':':
        loop(l)
        handle()
    elif l[:2] == 'if' and l[-1] == ':':
        cond(l)
        handle()
    else:
        assert False

handle()