#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define ll long long
#define rep(i, a, b) for(int i = (a); i < (b); i++)

constexpr ll oo = ((unsigned ll)-1) >> 1;

vector<pair<int, int>> ans;

void move(int o, int d){
    ans.emplace_back(o, d);
}

void hanoi(vector<int> l1, vector<int> l2, vector<int> l3, int d){
    int m1 = l1.back(), m2 = l2.back(), m3 = l3.back();
    int o = -1, n = -1;
    if (m1 > max(m2, m3)){
        o = 1;
        n = m1;
    }
    else if (m2 > max(m1, m3)){
        o = 2;
        n = m2;
    }
    else if (m3 > max(m1, m2)){
        o = 3;
        n = m3;
    }
    else return; // todas sao -1
    if (o == 1)l1.pop_back();
    else if (o == 2)l2.pop_back();
    else l3.pop_back();
    if (o == d){
        hanoi(l1, l2, l3, d);
    }
    else {
        int s = 6-o-d;
        hanoi(l1, l2, l3, s);
        move(o, d);
        vector<int> nl = {-1};
        rep(i,1,n)nl.push_back(i);
        if (s == 1)l1 = nl, l2 = {-1}, l3 = {-1};
        if (s == 2)l2 = nl, l1 = {-1}, l3 = {-1};
        if (s == 3)l3 = nl, l2 = {-1}, l1 = {-1};
        hanoi(l1, l2, l3, d);
    }
}

void solve() {
    int n; cin >> n;
    vector<int> l1 = {-1}, l2 = {-1}, l3 = {-1};
    int t, x;
    cin >> t;
    rep(i,0,t)cin >> x, l1.push_back(x);
    cin >> t;
    rep(i,0,t)cin >> x, l2.push_back(x);
    cin >> t;
    rep(i,0,t)cin >> x, l3.push_back(x);
    hanoi(l1, l2, l3, 2);
    cout << ans.size() << endl;
    for(auto [a, b] : ans){
        char o = 'A' + a - 1, d = 'A' + b - 1;
        cout << o << ' ' << d << endl;
    }
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}