#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define ll long long
#define rep(i, a, b) for(int i = (a); i < (b); i++)

constexpr ll oo = ((unsigned ll)-1) >> 1;

void solve() {
    int n, q; cin >> n >> q;
    vector a(n, 0ll), s(n, 0ll);
    for(ll& x : a)cin >> x;
    while(q--){
        int m, h; cin >> m >> h;
        s[min(n, m)-1] += h;
    }
    ll v = 0;
    for(int i = n-1; i >= 0; i--)v += s[i], a[i] += v;
    vector<ll> st = {oo, a[0]};
    rep(i,1,n){
        ll cur = a[i];
        //cout << cur << ' ' << v << ' ' << st.back() << endl;
        cout << st.size()-1 << endl;
        while(st.back() <= cur)st.pop_back();
        st.push_back(cur);
    }
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}