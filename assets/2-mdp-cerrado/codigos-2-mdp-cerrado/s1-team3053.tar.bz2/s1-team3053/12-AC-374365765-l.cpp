#include <bits/stdc++.h>

using namespace std;
#define endl '\n'

int ask(int a) {
    cout << "? " << a << endl;
    int res;
    cin >> res;
    return res;
}

void solve() {
    int n;
    cin >> n;
    n += 2;
    vector<int> v;
    int cur = 1;
    for (int i = 2; i < n; i++) {
        v.push_back(cur);
        int l = cur + i-1;
        int r = ask(l);
        if (r) {
            cur = l;
        } else {
            cur = l + 1;
        }
    }
    v.push_back(cur);
    int l = 0, r = (int)v.size();
    while (l + 1 < r) {
        int mid = (l+r)/2;
        if (ask(v[mid])) {
            l = mid;
        } else r = mid;
    }
    cout << "! " << v[l] << '\n';
}

int main() {
    //cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}