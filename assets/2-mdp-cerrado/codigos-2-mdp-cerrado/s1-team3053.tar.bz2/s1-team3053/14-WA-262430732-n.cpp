#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define int long long
string ss(int x) {
    if (x > 10) return to_string(x);
    else return "0" + to_string(x);
}
void solve() {
    string f;
    cin >> f;
    string a;
    cin >> a;
    int ff = stoll(f.substr(0, 2)) * 60 + stoll(f.substr(3, 2));
    int aa = stoll(a.substr(0, 2)) * 60 + stoll(a.substr(3, 2));
    int d = ff - aa;
    cout << ss(d / 60) << ":" << ss(d%60) << endl;
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}