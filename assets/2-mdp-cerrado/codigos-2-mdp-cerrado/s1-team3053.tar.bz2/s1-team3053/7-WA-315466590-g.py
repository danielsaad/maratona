def ler(s):
    s = s.strip()
    print("LEIA", s[:-10])

def escrever(s):
    s = s.strip()
    print("APRESENTE", s[6:-1])

def cond(s):
    s = s.strip()
    c = s[3:-1]
    print("SE", c, "ENTAO", end=" ")

def loop(s):
    s = s.strip()
    c = s[6:-1]
    print("ENQUANTO", c, end=" ")

def handle():
    try:
        l = input()
        if 'input' in l:
            ler(l)
        elif 'print' in l:
            escrever(l)
        elif 'while' in l:
            loop(l)
        else:
            cond(l)
    except:
        pass

handle()
handle()