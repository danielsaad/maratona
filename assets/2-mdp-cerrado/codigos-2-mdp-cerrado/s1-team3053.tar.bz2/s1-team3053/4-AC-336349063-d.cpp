#include <bits/stdc++.h>

using namespace std;
#define endl '\n'


void solve() {
    int n, q;
    cin >> n >> q;
    string s;
    cin >> s;
    vector<int> f(26, 1e9);
    for (int i = n-1; i >= 0; i--) {
        f[s[i]-'a'] = i;
    }
    while (q--) {
        string t;
        cin >> t;
        int l = 0;
        int ans = 0;
        for (auto u : t) {
            int fst = 1e9;
            for (int i = 0; i < 26; i++) {
                if (i != u-'a') fst = min(fst, f[i]);
            }
            if (fst < (int)1e9) ans = max(ans, n-fst + (int)t.size() - l);

            l++;
        }
    ans = max({ans,(int)t.size(), (int)s.size()});  

        cout << ans << '\n';
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}