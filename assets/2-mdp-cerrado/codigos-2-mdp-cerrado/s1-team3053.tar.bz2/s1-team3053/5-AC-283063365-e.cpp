#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
#define int long long

constexpr int MAX = 1e7+1;
int sieve[MAX];
void init() {
    sieve[0] = sieve[1] = 1;
    for (int i = 2; i < MAX; i++) {
        if (sieve[i]) continue;
        for (int j = i; j < MAX; j+=i) {
            sieve[j] = i;
        }
    }
}
int app[MAX];
void solve() {
    int n;
    cin >> n;
    vector<int> x;
    for (int i = 0; i < n; i++) {
        int a;
        cin >> a;
        while (a > 1) {
            app[sieve[a]]++;
            a /= sieve[a];
        }
    }
    for (int i = 2; i < MAX; i++) {
        if (sieve[i] == i && app[i]) {
            x.push_back(i * app[i]);
        }
    }
    sort(x.begin(), x.end());
    int ans = 0;
    for (int i = (int)x.size()-1; i >= 0; i-=2) ans += x[i];
    cout << ans << endl;
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    init();
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}