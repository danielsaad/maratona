#include <bits/stdc++.h>
#define f first
#define s second
#define pb push_back
#define dbg(x) cout << #x << " - " << x << endl;
#define el '\n';
const int MAX = 2e5 + 100;
using namespace std;
typedef long long ll;
ll pref[MAX];
vector<int> v;
int INF = 1e9;
map<ll, int> rec;
ll ans[MAX];
ll seg[4 * MAX];
void build(int l, int r, int node){
    if(l == r){
        seg[node] = v[l];
        return;
    }
    int mid = l + ((r - l) /2);
    build(l, mid, 2 * node);
    build(mid + 1, r, (2 * node) + 1);
    seg[node] = max(seg[node*2], seg[(node * 2) +1]);
}
int query(int node,ll v, int a, int b, int l, int r){
    if(seg[node] <= v){
        return -1;
    }
    if(l == r){
        return seg[node];
    }
    int mid = l + (r-l)/2;
    auto f1 = -1;
    if(seg[2*node+1] > v && b > mid){
        f1 = query(2* node +1, v, a, b, mid+1, r);
    }
    if(f1 != -1 && b>= mid){
        return f1;
    }else{
        return query(2* node , v, a, b, l, mid);
    }
}
void test()
{
    int n, k, a, b;
    cin >> n >> k;
    v.resize(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    for (int i = 0; i < k; i++)
    {
        cin >> a >> b;
        pref[1] += b;
        pref[a + 1] -= b;
    }
    for (int i = 0; i < n; i++)
    {
        pref[i + 1] += pref[i];
        v[i] += pref[i + 1];
    }
    build(0, n-1, 1);
    rec[INF] = -1;
     for (int i = 1; i < n; i++)
    {
        auto x  = query(1, v[i], 0, i-1, 0, n-1);
        if (x != -1)
        {
            
            ans[i] = rec[x] + 1;
            rec[v[i]] = ans[i];
        }
    }
     for(int i = 1; i < n; i++){
        cout << ans[i-1]+1 << '\n';
    }
}

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int tt = 1;
    while (tt--)
    {
        test();
    }
    return 0;
}