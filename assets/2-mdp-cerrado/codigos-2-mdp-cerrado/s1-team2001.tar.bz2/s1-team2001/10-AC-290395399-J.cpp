#include <bits/stdc++.h>
#define f first
#define s second
#define pb push_back
#define dbg(x) cout << #x << " - " << x << endl;
#define el '\n';
const int MAX = 2e5+100;
using namespace std;
typedef long long ll;
int n;
char x;
void test()
{
    cin >> n;
    int p = 1;
    int ans = 0;
    for(int i = 0; i < n; i++){
        cin >> x;
        if(x == 'C'){
            p = 1;
            ans++;
        }
        if(x == 'E' && p == 2){
            p = 1;
        }else if(x == 'E'){
            p = 0;
            ans++;
        }
        if(x == 'D' && p == 0){
            p = 1;
        }else if(x == 'D'){
            p = 2;
            ans++;
        }

    }
    cout << ans << '\n';
}

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int tt = 1;
    while (tt--)
    {
        test();
    }
    return 0;
}