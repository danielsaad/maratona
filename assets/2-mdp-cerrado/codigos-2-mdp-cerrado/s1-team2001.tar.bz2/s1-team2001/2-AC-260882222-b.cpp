#include <bits/stdc++.h>
#define f first
#define s second
#define pb push_back
#define dbg(x) cout << #x << " - " << x << endl;
#define el '\n';
const int MAX = 2e5+100;
using namespace std;
typedef long long ll;

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int ang;
    cin >> ang;


    if (ang < 45) {
        cout << "Costa" << "\n";
    } else if(ang > 45) {
        cout << "Saad" << "\n";
    }else{
        cout << "Ambos\n";
    }

    return 0;
}