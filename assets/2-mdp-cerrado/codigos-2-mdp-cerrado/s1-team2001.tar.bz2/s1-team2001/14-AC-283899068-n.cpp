#include <bits/stdc++.h>
#define f first
#define s second
#define pb push_back
#define dbg(x) cout << #x << " - " << x << endl;
#define el '\n';
const int MAX = 2e5+100;
using namespace std;
typedef long long ll;
void test()
{
    char c;
    int s1, s2, e1, e2;
    cin >> s1 >> c >> s2;
    cin >> e1 >> c >> e2;
    int t1 = s1 * 60 + s2;
    int t2 = e1 * 60 + e2;
    int ans = t1 - t2;
    int h = ans / 60;
    int m = ans - (h * 60);
    if(h <= 9){
        cout << "0";
    }
    cout << h << ":";
    if(m <= 9){
        cout << "0";
    }
    cout << m << '\n';

}

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int tt = 1;
    while (tt--)
    {
        test();
    }
    return 0;
}