S = input().strip()

def IO(remaining):
    if remaining.startswith("print"):
        content = remaining[6:-1]
        return "APRESENTE " + content.strip()
    elif remaining.endswith("input()"):
        var, _ = remaining.split("=")
        return "LEIA " + var.strip()


if (S.startswith("if")):
    content = S[3:-1]
    S2 = input().strip()
    print("SE", content, "ENTAO", IO(S2))
elif (S.startswith("while")):
    content = S[6:-1]
    S2 = input().strip()
    print("ENQUANTO", content, IO(S2))
else:
    print(IO(S))