#include <bits/stdc++.h>

using namespace std;

#define endl '\n'
#define DEBUG false
#define debugf if (DEBUG) printf
#define pb push_back
#define MAXN 10000009
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long long ll;

vector<long long> primes;
bitset<MAXN> bs;
vector<ll> primes_map;

void sieve (long long n) {
    ll sievisize = n +1 ;
    bs.set();
    bs[0] = bs[1] = 0;
    for (long long i = 2; i <= sievisize; i++) {
        if (bs[i]) {
            for (long long j = i * i; j <= (long long)sievisize; j+= i) {
                bs[j] = 0;
            }
            primes.push_back(i);
        }
    }
}

void primeFactors(ll N) {
    // vector<ll> factors;
    ll PF_idx = 0, PF = primes[PF_idx];
    while (PF * PF <= N) {
        while (N % PF == 0) {
            N /= PF;
            primes_map[PF]++;
            // factors.push_back(PF);
        }
        PF = primes[++PF_idx];
    }
    if (N != 1) primes_map[N]++; // factors.push_back(N);
    // return factors;
}




int main(){
    ios_base::sync_with_stdio(0);
    int n; cin >> n;
    sieve(MAXN);
    primes_map.resize(primes.size() + 1, 0);
    vi a(n);
    for (int i =0; i < n; i++) {
        cin >> a[i];
        primeFactors(a[i]);
    }

    priority_queue<ll> pq;
    for (int i = 2; i <= primes_map.size(); i++) {
        if (primes_map[i] != 0) {
            pq.push(primes_map[i]*i);
        }
    }

    int score = 0, k = 0;
    while (!pq.empty()) {
        if (k == 0) score += pq.top(); 
        pq.pop();
        k = k == 0 ? 1 : 0;
    }

    cout << score << endl;

    return 0;
}