F = input("")
A = input("")

Hf, Mf = map(int, F.split(":"))
Ha, Ma = map(int, A.split(":"))

Mf += Hf*60
Ma += Ha*60

Mr = Mf - Ma

Hr = Mr // 60
b = Mr % 60

print(f"{Hr:02}:{b:02}")