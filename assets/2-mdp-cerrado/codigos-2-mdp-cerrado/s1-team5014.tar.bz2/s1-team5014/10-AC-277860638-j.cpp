#include <bits/stdc++.h>

using namespace std;

#define endl '\n'
#define DEBUG false
#define debugf if (DEBUG) printf
#define pb push_back
typedef vector<int> vi;
typedef pair<int, int> pii;

int main(){
    ios_base::sync_with_stdio(0);
    int a; cin >> a;
    string s; cin >> s;

    int d = 0;
    char pos = 'C';
    for (int i = 0; i < s.size(); i++) {
        if (s[i] == pos) {
            d++;
        } else {
            if (pos == 'C' || s[i] == 'C') {
                pos = s[i];
                d++;
            } else {
                pos = 'C';
            }
        }
    }

    cout << d << endl;


    return 0;
}