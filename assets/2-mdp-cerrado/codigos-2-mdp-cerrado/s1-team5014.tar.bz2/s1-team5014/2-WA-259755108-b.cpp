#include <bits/stdc++.h>

using namespace std;

#define endl '\n'
#define DEBUG false
#define debugf if (DEBUG) printf
#define pb push_back
typedef vector<int> vi;
typedef pair<int, int> pii;

int main(){
    ios_base::sync_with_stdio(0);
    int a; cin >> a;
    double senA = sin(a);
    double cosA = cos(a);

    if (a == 45) {
        cout << "Ambos" << endl;
        return 0;
    }

    if (senA > cosA) {
        cout << "Saad" << endl;
    } else {
        cout << "Costa" << endl;
    }
    return 0;
}