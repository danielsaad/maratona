def func(S3):
    if S3.startswith("print"):
        content = S3[6:-1]
        return "APRESENTE " + content
    elif S3.endswith("input()"):
        var, _ = S3.split(" = ")
        return "LEIA " + var

S = input("").strip()

if (S.startswith("if")):
    content = S[3:-1]
    S2 = input("").strip()
    print("SE", content, "ENTAO", func(S2))
elif (S.startswith("while")):
    content = S[6:-1]
    S2 = input("").strip()
    print("ENQUANTO", content, func(S2))
else:
    print(func(S))
    