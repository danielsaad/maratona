#include <bits/stdc++.h>

using namespace std;

#define endl '\n'
#define DEBUG false
#define debugf if (DEBUG) printf
#define pb push_back
typedef vector<int> vi;
typedef pair<int, int> pii;

int main(){
    ios_base::sync_with_stdio(0);
    int n; cin >> n;
    int c; cin >> c;
    vector<long long> p(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> p[i];
    }
    vector<long long> t(100009, 0);
    for (int i = 0; i < c; i++) {
        int m, h; cin >> m >> h;
        t[m] = h;
    }

    long long count = 0;
    for (int i = n; i >= 1; i--) {
        count += t[i];
        p[i] += count;
    }

    // for (int i = 1; i <= n; i++) {
    //     cout << p[i] << " ";
    // }cout << endl;
    stack<long long> JK;
    JK.push(p[1]);
    for (int i = 2; i <= n; i++) {
        cout << JK.size() << endl;
        while (!JK.empty() && JK.top() <= p[i]) {
            JK.pop();
        }
        JK.push(p[i]);
    }


    return 0;
}