def IO(S3):
    if S3.startswith("print"):
        content = S3[6:-1]
        content = content.replace("'", "\"")
        return "APRESENTE " + content.strip()
    elif S3.endswith("input()"):
        var, _ = S3.split(" = ")
        return "LEIA " + var.strip()

S = input("").strip()

if (S.startswith("if")):
    content = S[3:-1]
    S2 = input("").strip()
    print("SE", content, "ENTAO", IO(S2))
elif (S.startswith("while")):
    content = S[6:-1]
    S2 = input("").strip()
    print("ENQUANTO", content, IO(S2))
else:
    print(IO(S))