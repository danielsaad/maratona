#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)


int main() {
    int n, c;
    cin >> n >> c;

    vector<int> heights(n);
    vector<int> canView(n);
    for(auto &i : heights) {
        cin >> i;
    }

    int i, v;
    while(c--) {
        cin >> i >> v;
        heights[i-1] += v;
    }

    stack<int> buildings;
    for(int i = 0; i < n; i++) {
        canView[i] = buildings.size();
        while(!buildings.empty() && buildings.top() <= heights[i]) {
            buildings.pop();
        }
        buildings.emplace(heights[i]);
    }

    for(int i = 1; i < n; i++) {
        cout << canView[i] << endl;
    }
}