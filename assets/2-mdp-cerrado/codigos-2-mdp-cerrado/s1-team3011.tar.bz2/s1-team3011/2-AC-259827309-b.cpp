#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)


int main() {
    int a;
    cin >> a;

    if(a  < 45) {
        cout << "Costa" << endl;
    } else if(a > 45) {
        cout << "Saad" << endl;
    } else {
        cout << "Ambos" << endl;
    }
}