#include <bits/stdc++.h>
#define endl '\n'
#define int ll

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)
using pi = pair<int, int>;

int32_t main() {
    int n;
    cin >> n;

    vector<int> nums(n);
    for(auto &i : nums) cin >> i;

    int maxElement = *max_element(nums.begin(), nums.end());
    bitset<10000000> notPrime;
    vector<ll> primes;
    for(ll i = 2; i < maxElement; i++){
        if(notPrime[i])
            continue;
        primes.emplace_back(i);
        for(ll j = i+i; j <= maxElement; j+=i)
            notPrime[j] = true;
    }

    unordered_map<int, int> qtdPowerOf;
    for(auto &v : nums) {
        for(auto p : primes) {
            if(v == 1) break;

            int qtdPower = 0;
            while(v % p == 0) {
                v/=p;
                qtdPower++;
            }
            if(qtdPower) {
                qtdPowerOf[p] += qtdPower;
            }
        }
    }


    vector<int> toChoose;
    for(auto &[p, qtd] : qtdPowerOf) {
        toChoose.emplace_back(p*qtd);
    }
    sort(toChoose.rbegin(), toChoose.rend());

    int maxPoints = 0;
    for(int i = 0; i < toChoose.size(); i+=2) {
        maxPoints += toChoose[i];
    }

    cout << maxPoints << endl;
}