#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)


int main() {
    int n;
    string s;
    cin >> n >> s;

    int state = 0;
    int defesas = 0;
    for(char c : s) {
        int chute = (c == 'D' ? 1 : (c == 'E' ? -1 : 0));
        if(chute == state) {
            defesas++;
        } else {
            if(abs(chute - state) <= 1) {
                defesas++;
                state = chute;
            }
        }
    }

    cout << defesas << endl;
}