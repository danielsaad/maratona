#include <bits/stdc++.h>

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)
using pi = pair<int, int>;
#define left(x, n) (x + n)
#define right(x, n) (x + n + 1)

int ask(ll node) {
    int v;
    cout << "? " << node << endl;
    cin >> v;
    return v;
}

void answer(ll node) {
    cout << "! " << node << endl;
    exit(0);
}

void solve(ll node, ll level, ll n){
    ll l = ask(left(node, level));
    if(l)
        solve(left(node, level), level+1, n);
    else if(level + 2 <= n){
        ll lr = ask(right(left(node, level), level+1));
        if(lr)
            solve(right(left(node, level), level+1), level+2, n);
        else{
            ll rr = ask(right(right(node, level), level+1));
            if(rr)
                solve(right(right(node, level), level+1), level + 2, n);
            else{
                if(ask(right(node, level)))
                    answer(right(node, level));
                else
                    answer(node);
            }
        }
    }
    else{
        answer(node);
    }
}

int main() {
    ll n, begin = 1;
    cin >> n;
    solve(1, 1, n);


}