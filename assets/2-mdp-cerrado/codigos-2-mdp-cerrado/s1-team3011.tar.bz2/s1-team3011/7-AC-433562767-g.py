while True:
    try:
        line = input().strip()
    except:
        print()
        break

    if line.startswith("if"):
        print(f'SE {line[3:-1]} ENTAO ', end="")
    elif line.startswith("while"):
        print(f'ENQUANTO {line[6:-1]} ', end="")
    elif line.startswith("print("):
        print(f'APRESENTE {line[6:-1]}', end="")
    else:
        print(f'LEIA {line.split(" ")[0]}', end="")