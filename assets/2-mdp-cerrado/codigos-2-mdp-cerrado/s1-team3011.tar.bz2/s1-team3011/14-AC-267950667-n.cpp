#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)


int main() {
    int hh1, mm1, hh2, mm2;
    scanf("%d:%d", &hh1, &mm1);
    scanf("%d:%d", &hh2, &mm2);

    int remainingmm = hh1*60 + mm1 - hh2*60 - mm2;

    printf("%02d:%02d\n", remainingmm/60, remainingmm%60);
}