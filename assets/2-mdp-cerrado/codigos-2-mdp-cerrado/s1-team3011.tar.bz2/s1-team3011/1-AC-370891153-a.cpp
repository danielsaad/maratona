#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
using ll = long long;
#define rep(a, b) for(auto i = a; i < b; i++)
#define int ll

int32_t main() {
    int n, c;
    cin >> n >> c;

    vector<int> heights(n);
    vector<int> canView(n);
    for(auto &i : heights) {
        cin >> i;
    }

    vector<int> windowSum(n);
    while(c--) {
        int i, v;
        cin >> i >> v;
        windowSum[i-1] += v;
    }
    for(int i = n-2; i >= 0; i--) {
        windowSum[i] += windowSum[i+1];
        heights[i] += windowSum[i];
    }

    stack<int> buildings;
    for(int i = 0; i < n; i++) {
        canView[i] = buildings.size();
        while(!buildings.empty() && buildings.top() <= heights[i]) {
            buildings.pop();
        }
        buildings.emplace(heights[i]);
    }

    for(int i = 1; i < n; i++) {
        cout << canView[i] << endl;
    }
}