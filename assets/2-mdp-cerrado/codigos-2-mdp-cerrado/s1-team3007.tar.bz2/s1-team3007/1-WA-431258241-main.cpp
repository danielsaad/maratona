#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios::sync_with_stdio(false);
	cin.tie(nullptr);

    int num;
    int constr;
    int count =1;
    cin>>num;
    cin>>constr;
    vector<int> alturas(num);
    for(int i =0; i < num; i++){
        int altura;
        cin>>altura;
        alturas[i] = altura;
    }


    for(int i =0; i<constr; i++){
        int mes;
        int hsoma;
        cin>>mes;
        cin>>hsoma;

        alturas[mes-1] += hsoma;
    }
    for(int i=1; i<num; i++){
        if(i==1) cout<<count<<endl;
    else{
        if(alturas[i-1]<alturas[i-2]){
            count++;
            cout<<count<<endl;
        }
        else{

        count =1;
        cout<<count<<endl;
        }
    }

    }

        return 0;
}
