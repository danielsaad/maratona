#include <stdio.h>

int main() { 
	int  a, b, c, d;
	int hh, mm;
	char hh1[5]; char hh2[5];

	scanf("%d:%d", &a, &b);
	scanf("%d:%d", &c, &d);
	
	hh = a - c;
        mm = b - d;	
	
	if ( mm < 0 ){ 
		mm += 60;
		hh--;
	}

	if ( hh < 10 ) 
		printf("0%d:", hh);
	else 
		printf("%d:", hh);

	if ( mm < 10 ) 
		printf("0%d\n", mm );
	else
		printf("%d\n", mm);

	return 0;
}
