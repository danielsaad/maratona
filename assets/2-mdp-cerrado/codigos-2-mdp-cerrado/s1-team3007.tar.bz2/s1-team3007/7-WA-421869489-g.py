n = []
frase = input()
frase1 = ""
comp = frase[3:]
if frase[-1] == ")" and frase[-2] == "(":
    frase = frase.split(" ")
    print(f"LEIA {frase[0]}")
elif frase[-1] == ":" and frase[0] == "i":
    comp = input()
    frase = frase[3:]
    frase = frase.split(":")
    if comp[-1] == ")" and comp[-2] == "(":
        comp = comp.split(" ")
        comp[0] = comp[0].split("\t")
        print(f"SE {frase[0]} ENTAO LEIA {comp[0][1]}")
    else:
        comp = comp[7:]
        tamanho = len(comp)
        comp = comp.removesuffix(")")
        print(f"SE {frase[0]} ENTAO APRESENTE {comp}")
elif frase[-1] == ":" and frase[0] == "w":
    comp = input()
    frase = frase[6:]
    frase = frase.split(":")
    if comp[-1] == ")" and comp[-2] == "(":
        comp = comp.split(" ")
        comp[0] = comp[0].split("\t")
        print(f"ENQUANTO {frase[0]} LEIA {comp[0][1]}")
    else:
        comp = comp[7:]
        tamanho = len(comp)
        comp = comp.removesuffix(")")
        print(f"ENQUANTO {frase[0]} APRESENTE {comp}")
else:
    
    frase = frase[6:]
    tamanho = len(frase)
    frase = frase.removesuffix(")")
    
    print(f"APRESENTE {frase}")
