#include <bits/stdc++.h>
#define ll long long 
#define endl '\n'

using namespace std;

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	ll n;
	string s;
	vector<ll> pos(3, 0);
	pos[1] = 1;
	cin >> n;
	cin >> s;

	ll atual= 1;
	ll count = 0;

	for( int i = 0; i < n; i++ ) { 
		if ( s[i] == 'D' && atual == 0 ) {
			atual++;	
		} else if (s[i] == 'E' && atual == 2 ) 
			atual--;	
		 else if ( s[i] == 'D' && atual == 1 ){
			count++;
			atual++;
		 } else if ( s[i] == 'E' && atual == 1) {
			count++;
			atual--;	
		 } else if ( s[i] == 'C' && atual == 1)
			count++;
		else if ( s[i] == 'E' && atual == 0 )
		      count++;
		else if ( s[i] == 'C' && atual == 0 ) {
			atual++;
			count++;
		} else if ( s[i] == 'D' && atual == 2 ) 
			count++;
		else if ( s[i] == 'C' && atual == 2 ) {
			atual--;
			count++;
		}	

	}

	cout << count << endl;


	return 0;
}

