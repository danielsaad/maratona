#include <bits/stdc++.h>
#define ll long long 
#define endl '\n'

using namespace std;

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	double a;
	double s, c;
	double aux;
	cin >> a;

	aux = a;

	a *= 3.14;
	a /= 180;	

	s = sin(a);
	c = cos(a);

	if ( aux == 45 ) 
		cout << "Ambos" << endl;
	else if ( s > c ) 
		cout << "Saad" << endl;
	else if ( c > s ) 
		cout << "Costa" << endl;

	return 0;
}

