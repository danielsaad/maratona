#include <bits/stdc++.h>
#include <math.h>
using namespace std;

#define endl "\n"
#define long long ll

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int n,c; cin >> n >> c;
    vector<pair<int,int>>v;
    vector<int>s;
    multimap<int>vv;
    for(int i = 0; i<n;i++) {
        int x; cin >> x;
        v.push_back({x,i+1});
        vv.insert(x);
    }

    
    int prev(vv.end());
    cout << m << endl;

    int aux;
    for(int i = n; i>=1;i--) {
        if(v[i].first == m) {
            aux=i+1;
            cout << aux << endl;
            break;
    }
}
    for(int i = n-1; i>=0;i--) {
        int y=v[i].second-aux;
        s.push_back(y);
        v.pop_back();
        cout << "v " << v[i].second << endl;
        cout << y << endl;
    }

    

    return 0;
}

