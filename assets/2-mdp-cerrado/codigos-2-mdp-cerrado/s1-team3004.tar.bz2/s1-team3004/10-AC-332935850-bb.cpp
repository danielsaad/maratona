#include <bits/stdc++.h>
#include <math.h>
using namespace std;

#define endl "\n"
#define long long ll

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int n; cin >> n;
    string s; cin >> s;
    int cc=0;
    char g=s[0];

    
    for (int i=0;i<s.size();i++){
        if (s[i]=='C') {
            cc++;
            g='C';
        }

        else if (s[i]=='E'){
            if (g!='D'){
                
                g='E';
                cc++;
            }
            else {
                g='C';
            }
        }
        else if (s[i]=='D'){
            if (g!='E'){
                g='D';
                cc++;
            }
            else {
                g='C';
            }
           
    }

}
cout << cc << endl;

    return 0;
}

