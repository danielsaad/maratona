#include <bits/stdc++.h>
using namespace std;

#define endl "\n"
#define long long ll

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    double n; cin >> n;

    n=abs((n*3.1415926)/180);
    double s= sin(n);
    double c= cos(n);

    if (s>c) cout << "Saad" << endl;

    else if (s<c) cout << "Costa" << endl;

    else cout << "Ambos" << endl;

    

    

    return 0;
}

