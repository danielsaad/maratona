#include <stdio.h>
#include <stdlib.h>

int main(){

    int a,b,c,d;
    scanf("%d:%d",&a,&b);
    scanf("%d:%d",&c,&d);
    int s=a-c;
    
    int m=60-b+d;
    int y=m/60;
    s=s+y;
    m=m%60;

   
    printf("%.2i:%.2i\n",s,m);
    

}