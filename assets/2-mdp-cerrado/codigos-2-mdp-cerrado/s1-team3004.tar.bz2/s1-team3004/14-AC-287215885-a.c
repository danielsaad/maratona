#include <stdio.h>
#include <stdlib.h>

int main(){

    int a,b,c,d;
    scanf("%d:%d",&a,&b);
    scanf("%d:%d",&c,&d);
    int x=a*60+b;
    int y=c*60+d;

    int w=x-y;

    int h=w/60;
    int m=w-(60*h);
   

   
    printf("%.2i:%.2i\n",h,m);
    

}