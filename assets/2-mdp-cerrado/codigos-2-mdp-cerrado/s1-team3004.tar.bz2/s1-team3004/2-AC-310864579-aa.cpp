
    #include <bits/stdc++.h>
    #include <math.h>
    using namespace std;
    
    #define endl "\n"
    #define long long ll
    
    int main(){
        ios::sync_with_stdio(0);
        cin.tie(0);
    
        int n; cin >> n;
    
        if (n<45){
            cout << "Costa" << endl;
        }
        else if (n>45){
            cout << "Saad" << endl;
        }
        else {
            cout << "Ambos" << endl;
        }
    
        return 0;
    }
    
    
    

