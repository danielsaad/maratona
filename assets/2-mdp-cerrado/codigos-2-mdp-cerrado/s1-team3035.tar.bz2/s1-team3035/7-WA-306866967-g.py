def parse(linha):
    tokens = linha.strip().split()
    if len(tokens) == 3 and tokens[1] == '=' and tokens[2] == "input()":
        return f'LEIA {tokens[0]}'
    elif tokens[0].startswith("print("):
        return f'APRESENTE {linha.split("(")[1][:-1]}'
    elif tokens[0] == "if":
        dentro = parse(input())
        return f'SE {linha[3:-1]} ENTAO {dentro}'
    elif tokens[0] == "while":
        dentro = parse(input())
        return f'ENQUANTO {linha[6:-1]} {dentro}'

while True:
    try:
        linha = input()
    except:
        break
    print(parse(linha))

