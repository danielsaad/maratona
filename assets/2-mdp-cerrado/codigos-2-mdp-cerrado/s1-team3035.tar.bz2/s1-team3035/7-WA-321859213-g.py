def parse(linha):
    tokens = linha.strip().split()
    if len(tokens) == 3 and tokens[1] == '=' and tokens[2] == "input()":
        return f'LEIA {tokens[0]}'
    elif tokens[0].startswith("print("):
        return f'APRESENTE {linha.split("(")[1][:-1]}'
    elif tokens[0] == "if":
        partes = linha.split(':')
        dentro = parse(partes[1])
        return f'SE {partes[0][3:]} ENTAO {dentro}'
    elif tokens[0] == "while":
        partes = linha.split(':')
        dentro = parse(partes[1])
        return f'ENQUANTO {partes[0][6:]} {dentro}'

codigo = ""
while True:
    try:
        codigo += input()
    except:
        break

print(parse(codigo))

