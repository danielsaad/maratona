#include <bits/stdc++.h>

using namespace std;

#define int long long 
#define vi vector<int>

void solve(){
    int n, m; cin >> n >> m;
    vi a(n); for(auto &x: a) cin >> x;
    while(m--){
        int i, x; cin >> i >> x; i--;
        a[i] += x;
    }
    stack<int> s; s.push(a[0]);
    for(int i=1; i<n; i++){ 
        cout << (int)s.size() << "\n";
        if(!s.empty() and s.top() < a[i]){
            while(!s.empty()) s.pop();
        } 
        s.push(a[i]);
    }
    
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
}