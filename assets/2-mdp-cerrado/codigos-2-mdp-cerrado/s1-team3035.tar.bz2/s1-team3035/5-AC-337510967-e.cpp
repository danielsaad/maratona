#include <bits/stdc++.h>

using namespace std;

#define int long long 
#define vi vector<int>

vi primes(1e5 + 1);

vi findPrimes(int n){
    vector<bool> isPrime(n+1, true);
    isPrime[0] = isPrime[1] = false;
    for(int i=2; i*i <= n; i++){
        for(int j = i*i; j <= n; j+=i){
            isPrime[j] = false;
        }
    }
    vi primes;
    for(int i=2; i<=n; i++){
        if(isPrime[i]) primes.push_back(i);
    }
    return primes;
}

vi getFactors(int x){
    vi factors;
    for(int p: primes){
        while(x%p == 0){
            factors.push_back(p);
            x /= p;
        }
        if(p*p > x) break;
    }

    if(x > 1) factors.push_back(x);
    return factors;
}

void solve(){

    int n; cin >> n;
    vi a(n); for(auto &x: a) cin >> x;
    map<int, int> pont;
    for(int x: a){
        vi fact = getFactors(x);
        for(int f: fact) pont[f] += f;
    }
    vi pontuacoes;
    for(const auto [ind, val]: pont){
        pontuacoes.push_back(val);
    }
    sort(pontuacoes.begin(), pontuacoes.end(), greater<int>());

    int res = 0;
    for(int i=0; i<(int)pontuacoes.size(); i++){
        if(i%2 == 0) res += pontuacoes[i];
    }
    cout << res << "\n";
}

signed main(){
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);
    primes = findPrimes(1e5+1);
    solve();
}