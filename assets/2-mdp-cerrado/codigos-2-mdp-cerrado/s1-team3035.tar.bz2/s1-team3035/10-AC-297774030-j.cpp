#include <bits/stdc++.h>

using namespace std;

#define int long long 

void solve(){
    int n; cin >> n;
    string s; cin >> s;
    int res = 0; char posg = s[0];
    for(int i=0; i<n; i++){
        if(posg == s[i]) res++;
        if(i+1 < n){
            char next_pos = s[i+1];
            if((next_pos == 'E' and posg == 'D') or (next_pos == 'D' and posg == 'E')){
                posg = 'C';
            } else {
                posg = next_pos;
            }
        }
    }
    cout << res << "\n";
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
}