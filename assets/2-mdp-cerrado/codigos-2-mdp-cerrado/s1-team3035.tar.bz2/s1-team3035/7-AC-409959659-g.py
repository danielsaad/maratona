def parse(codigo):
    i = 0
    while i < len(codigo): 
        if codigo[i].startswith("print("):
            if len(codigo[i]) == 6:
                i+= 1
                return f'APRESENTE {codigo[i]}'
            else:
                return f'APRESENTE {codigo[i][6:-1]}'
        elif codigo[i] == "if":
            resultado = 'SE'

            i += 1
            while not codigo[i].endswith(":"):
                resultado += " " + codigo[i]
                i += 1
            if codigo[i] != ':':
                resultado += " " + codigo[i][:-1]
            i += 1

            resultado += " ENTAO "
            resultado += parse(codigo[i:])
            return resultado

        elif codigo[i] == "while":
            resultado = "ENQUANTO"

            i += 1
            while not codigo[i].endswith(":"):
                resultado += " " + codigo[i]
                i += 1
            if codigo[i] != ':':
                resultado += " " + codigo[i][:-1]
            i += 1

            resultado += " " + parse(codigo[i:])
            return resultado

        else:
            return f'LEIA {codigo[i]}'
        i += 1

codigo = []
linhas = ""
while True:
    try:
        linhas += input().strip()
        linhas += ' '
    except:
        break

word = ''
i = 0
while i < len(linhas):
    if linhas[i] == '"':
        if word:
            codigo += [word]
            word = ''
        value = '"'
        while True:
            i += 1
            if linhas[i] == '"':
                codigo += [value + '"']
                i += 1
                break
            value += linhas[i]

    if linhas[i] == "'":
        if word:
            codigo += [word]
            word = ''
        value = "'"
        while True:
            i += 1
            if linhas[i] == "'":
                codigo += [value + "'"]
                i += 1
                break
            value += linhas[i]

    word += linhas[i]
    if linhas[i] == " ":
        if word and word[:-1]:
            codigo += [word[:-1]]
        word = ''

    i += 1

print(parse(codigo))
