#include <bits/stdc++.h>

using namespace std;

#define int long long 

void solve(){
    int n, q; cin >> n >> q;
    string s; cin >> s;
    int si = n;
    for(int i=0; i<n; i++){
        if(s[i] != s[0]){
            si = i; break;
        }
    }
    while(q--){
        string t; cin >> t;
        int m = (int)t.size(), ti = m;
        for(int i=0; i<m; i++){
            if(t[i] != t[0]){
                ti = i; break;
            }
        }
        if(s[0] != t[0]) cout << n + m << "\n";
        else cout << max((n - si) + m, n + (m - ti)) << "\n";
    }
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
}