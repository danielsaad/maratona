h1, m1 = input().split(":")
h1 = int(h1)
m1 = int(m1)

h0, m0 = input().split(":")
h0 = int(h0)
m0 = int(m0)

minutos = m1 - m0
horas = h1 - h0

if minutos < 0:
    minutos += 60
    horas -= 1

print(f'{horas:02}:{minutos:02}')
