#include <bits/stdc++.h>

using namespace std;

#define int long long 
#define vi vector<int>

void solve(){

    int n, m; cin >> n >> m;
    vi a(n); for(auto &x: a) cin >> x;

    vi delta(n+1, 0);
    while(m--){
        int m, x; cin >> m >> x; m--;
        delta[0] += x;
        delta[m+1] -= x;
    }
    for(int i=1; i<=n; i++) delta[i] += delta[i-1];
    for(int i=0; i<n; i++) a[i] += delta[i]; 
    
    stack<int> s; s.push(a[0]);
    for(int i=1; i<n; i++){ 
        cout << (int)s.size() << "\n";
        while(!s.empty() and s.top() <= a[i]) s.pop();
        s.push(a[i]);
    }
    
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
}