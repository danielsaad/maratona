#include <bits/stdc++.h>

using namespace std;

#define int long long 

void solve(){
    int a; cin >> a;
    if(a == 45) cout << "Ambos\n";
    else if(a < 45) cout << "Costa\n";
    else cout << "Saad\n";
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
}