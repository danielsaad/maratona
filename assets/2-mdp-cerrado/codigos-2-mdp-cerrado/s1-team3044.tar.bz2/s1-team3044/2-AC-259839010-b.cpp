#include <bits/stdc++.h>
using namespace std;

int main(){
    int a;
    cin >> a;

    if(a==45){
        cout << "Ambos" << endl;
        return 0;
    }

    if(a>45){
        cout << "Saad" << endl;
    }else{
        cout << "Costa" << endl;
    }
}
