#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ii = array<int,2>;
template <typename T> using V = vector<T>;

#define pb push_back
#define sz(v) (int) size(v)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()

const int maxn = 1e7 + 1;

int np[maxn];

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    for (int i = 2; i < maxn; ++i) {
        if (np[i]) continue;
        np[i] = i;
        for (int j = i + i; j < maxn;j += i)
            np[j] = i;
    }
    int n; cin >> n;
    V<int> a(n);
    map<int,int> seen;
    for (auto & x : a) {
        cin >> x;
        while (x > 1) {
            seen[np[x]] += 1;
            x /= np[x];
        }
    }
    V<ll> tot;
    for (auto [x, y] : seen) {
        tot.pb((ll)x * y);
    } 
    sort(rall(tot));
    ll res = 0;
    for (int i = 0; i < sz(tot); i += 2) res += tot[i];
    cout << res << '\n';
}
