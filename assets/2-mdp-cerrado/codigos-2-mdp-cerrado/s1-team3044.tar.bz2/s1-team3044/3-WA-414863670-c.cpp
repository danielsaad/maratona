#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ii = array<int,2>;
template <typename T> using V = vector<T>;

#define pb push_back
#define sz(v) (int) size(v)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define vi vector<int>

vi Z(const string&s){
    vi z(sz(s));
    int l = -1, r =-1;
    for(int i = 1; i< sz(s); i++){
        z[i]= i >= r ? 0 : min(r-i,z[i-l]);
        while(i+ z[i] < sz(s) && s[i+ z[i]] == s[z[i]]){
            z[i]++;
        }
        if(i+z[i]>r) l = i, r= i+z[i];
    }
    return z;
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    

    string s, t;
    cin >> s;
    cin >> t;
    vi a(sz(s));
    for(auto&x : a) cin >> x;
    int n = sz(s), m = sz(t);
    string ns = s;

    s = s + s;
    while(sz(s) < 2*m){
        s += ns;
    }
    s = t + '#' + s;

    // cout << s << endl;

    vi v = Z(s);
    vi ans(n,-1);

    vi vec;
    vi seen(n,0);

    for(int i = sz(t)+1; i< sz(v); i++ ){
        if(i>=n+ sz(t) + 1) break;
        // cout << v[i] << " ";
        if(v[i]<m){
            ans[i-sz(t)-1]=0;
        }
    }
    // cout << endl;

    bool b = 0;

    
    auto dfs = [&](auto rc, int x)->int{
        if(seen[x]==1){
            return -1;
        }
        if(seen[x]==2){
            return ans[x];            
        }
        seen[x]=1;
        if(ans[x]==0){
            seen[x]=2; 
            return ans[x];
        }
        int sla = rc(rc,(x + m)%n);
        ans [x] = ans[(x+m)%n]+1;

        if(sla==-1){
            b = 1;
            return 0;
        }
        seen[x] =2 ;
        return ans[x];
    };
    for(int i =0; i<n; i++){
        if(seen[i]==0){
            dfs(dfs,i);
        }
    }


    int res =0;


    for(int i = 0; i<n; i++){
        res = max(res, ans[i]*a[i]);
    }
    if(b){
        cout << -1 << endl;
    }
    else
    cout << res << endl;

}
