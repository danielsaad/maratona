#include <bits/stdc++.h>
using namespace std;

#define all(a) a.begin(), a.end()

int main(){
    string s1; cin >> s1;
    string s2; cin >> s2;

    int h1, m1;
    h1 = (s1[0] - '0') * 10;
    h1 += (s1[1] - '0');
    m1 = (s1[3] - '0') * 10;
    m1 += (s1[4] - '0');
    int h2, m2;
    h2 = (s2[0] - '0') * 10;
    h2 += (s2[1] - '0');
    m2 = (s2[3] - '0') * 10;
    m2 += (s2[4] - '0');

    // cout << h1 << ' ' << m1 << '\n';
    // cout << h2 << ' ' << m2 << '\n';

    int t1 = h1*60 + m1;
    int t2 = h2*60 + m2;

    if(t2 < t1) t2 += 24*60;

    int diff = t2 - t1;

    if(diff/60 < 10) cout << "0";
    cout << diff/60;
    cout << ":";
    if(diff%60 < 10) cout << "0";
    cout << diff%60;
    cout << "\n";
}
