res = []
a = ''
twice = False
while True:
    try:
        B = input()
        a = [x for x in B.split()]
        if a[0] == 'if':
            construir = ['SE']
            for i in range(1, len(a)):
                construir.append(a[i])
            construir[-1] = construir[-1][0:-1]
            construir.append('ENTAO')
            res.append(construir)
        elif a[0] == 'while':
            construir = ['ENQUANTO']
            for i in range(1, len(a)):
                construir.append(a[i])
            construir[-1] = construir[-1][0:-1]
            res.append(construir)
        elif a[-1] == 'input()':
            construir = ['LEIA']
            construir.append(a[0])
            res.append(construir)
        else:
            construir = ['APRESENTE']
            if twice:
                construir.append(B[10:-1])
            else:
                construir.append(B[6:-1])
            res.append(construir)
        twice = True
    except:
        for x in res:
            print(*x, end=' ')
        print()
        exit()
