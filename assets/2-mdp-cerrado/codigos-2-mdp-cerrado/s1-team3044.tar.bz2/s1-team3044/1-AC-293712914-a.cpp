#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ii = array<int,2>;
template <typename T> using V = vector<T>;

#define pb push_back
#define sz(v) (int) size(v)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define int long long

signed main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, c; cin >> n >> c;
    V<int> v(n);
    for(auto &x : v) cin >> x;


    vector<int> ps(n,0);
    for(int i =0; i<c; i++){
        int x,a; cin >> x >> a;
        ps[x-1]+=a;
    }   
    for(int i =1 ; i<sz(ps); i++){
        ps[i]+=ps[i-1];
    }
    stack<int> st;
    st.push(v[0]);
    for(int i=1; i<n; i++){
        int x = v[i]-ps[i-1];
        cout << st.size() << '\n';
        while(!st.empty() and st.top()<=x){
            st.pop();
        }
        st.push(x);
    }

}
