#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ii = array<int,2>;
template <typename T> using V = vector<T>;
#define int long long

#define pb push_back
#define sz(v) (int) size(v)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define matrix vector<vector<int>>


const int mod = 998244353;



matrix mult(matrix& a, matrix& b){
    matrix c = {{0,0},{0,0}};
    c[0][0]= (a[0][0]*b[0][0]%mod + a[0][1]*b[1][0]%mod)%mod;
    c[0][1] = (a[0][0]*b[0][1]%mod + a[0][1]*b[1][1]%mod)%mod;
    c[1][0] = (a[1][0]*b[0][0]%mod+ a[1][1]*b[1][0]%mod)%mod;
    c[1][1] = (a[1][0]*b[0][1]%mod + a[1][1]*b[1][1]%mod)%mod;

    return c;
}

matrix exp(matrix a, int b){
    matrix ans = {{1,0},{0,1}};
    while(b){
        if(b&1){
            ans = mult(ans,a);
        }

         a= mult(a,a);
         b >>=1;
    }
    return ans;
}


int inv(int a){
    int b = mod-2;
    int ans =1 ;
    while(b){
        if(b&1){
            ans = (ans*a)%mod;
        }
        a = (a*a)%mod;
        b >>=1;
    }
    return ans;
}

void solve(){
    int b1,b2,n,m,X,Y;
    //fn = X, fm = Y;
    cin >> b1 >> b2 >> n >> m >> X >> Y;


    matrix base = {{b1,b2},{1,0}};

    matrix fn = exp(base,n-1);
    matrix fm = exp(base,m-1);

    // for(int i = 0; i<2; i++){
    //     for(int j = 0; j<2; j++){
    //         cout << fn[i][j] << " ";
    //     }
    //     cout << "\n";
    // }
    // for(int i = 0; i<2; i++){
    //     for(int j = 0; j<2; j++){
    //         cout << fm[i][j] << " ";
    //     }
    //     cout << "\n";
    // }


    int f1;

    int a,b,x,y;
    x = fn[0][0], y = fn[0][1];
    a = fm[0][0], b = fm[0][1];

    f1 = ((((X*inv(x))%mod)  + mod- ((Y*inv(a))%mod))      *inv((y*inv(x)%mod) + mod - (b*inv(a)%mod)))%mod;
    int f0 = ((X+ (mod - y*f1%mod))*(inv(x))%mod + mod)%mod;
    f0 = (f0+mod)%mod;
    cout << (f1) << " ";
    cout << f0 << "\n";
}


int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);

    int t; cin >> t;
    while(t--)solve();


}
