#include <bits/stdc++.h>
using namespace std;

#define int long long

int32_t main()
{
    cin.tie(0)->sync_with_stdio(0);

    int n, q; cin >> n >> q;

    string s; cin >> s;

    vector<int> frst(26, -1);
    for(int i = 0; i < n; i++)
    {
        if(frst[s[i] - 'a'] == -1)
            frst[s[i] - 'a'] = i;
    }

    // for(int x : frst) cout << x << ' ';
    // cout << '\n';

    while (q--)
    {
        string t; cin >> t;
        int m = t.size();

        vector<int> frst2(26, -1);
        for(int i = 0; i < m; i++)
        {
            if(frst2[t[i] - 'a'] == -1)
                frst2[t[i] - 'a'] = i;
        }

        int resp = max(n, m);

        int best = -1;
        for(int c = 0; c < 26; c++)
        {
            if(c + 'a' == s[0]) continue;
            if(frst2[c] == -1) continue;
            if(best == -1 or best > frst2[c])
                best = frst2[c];
        }

        if(best != -1)
        {
            resp = max(resp, n + m-best);
        }

        best = -1;
        for(int c = 0; c < 26; c++)
        {
            if(c + 'a' == t[0]) continue;
            if(frst[c] == -1) continue;
            if(best == -1 or best > frst[c])
                best = frst[c];
        }

        if(best != -1)
        {
            resp = max(resp, m + n-best);
        }

        cout << resp << '\n';
    }
    
}
