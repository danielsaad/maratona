#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ii = array<int,2>;
template <typename T> using V = vector<T>;

#define pb push_back
#define sz(v) (int) size(v)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()


int main(){
    int n; cin >> n;

    int cont =1;
    int atual =1;

    V<int> pos;
    map<int,int> pai;
    while(cont<=n){
        int p1 = atual + cont, p2 = p1+1;
        cout << "? " << p1 << endl;
        int x; cin >> x ;
        if(x==0){
            pos.pb(p2);
            pai[p2]= atual;
            atual = p2;
        }
        else{
            pos = {};
            atual = p1;
        }
        cont++;
    }
    int l = 0, r = sz(pos)-1;
    if(sz(pos)==0){
        cout << "! ";
        cout << atual << endl;
        return 0;
    }
    int ans = pos[sz(pos)-1];
    while(l<=r){
        int m = (l+r)/2;
        cout << "? " << pos[m] << endl;
        int x; cin >> x;
        if(x==0){
            ans = pai[pos[m]];
            r = m-1;
        }else{
            l = m+1;
        }
    }
    cout << "! ";
    cout << ans << endl;
}
