#include <bits/stdc++.h>
using namespace std;

#define all(a) a.begin(), a.end()

int main(){

    int n; cin >> n;

    int ans = 0;

    string s; cin >> s;

    for(int i = 0; i < n-1; i++)
    {
        if((s[i] == 'E' and s[i+1] == 'D') or (s[i] == 'D' and s[i+1] == 'E'))
        {
            ans++;
            i++;
            continue;
        }
    }

    ans = n - ans;

    cout << ans << '\n';
}
