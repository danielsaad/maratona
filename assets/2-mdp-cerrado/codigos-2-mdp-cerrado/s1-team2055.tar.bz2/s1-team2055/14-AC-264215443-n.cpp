#include <bits/stdc++.h>
using namespace std;

// #define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

void solve() {
    char c;

    int h1, m1;
    cin >> h1 >> c >> m1;

    int h2, m2;
    cin >> h2 >> c >> m2;

    int s1 = h1 * 60 + m1;
    int s2 = h2 * 60 + m2;

    int r = s1 - s2;

    int h = r / 60;
    int m = r % 60;

    cout << (h <= 9 ? "0" : "") << h << ':' << (m <= 9 ? "0" : "") << m << '\n';
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}