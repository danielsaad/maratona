#include <bits/stdc++.h>
using namespace std;

// #define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

void solve() {
    int n; cin >> n;
    string s; cin >> s;
    vector<int> dp(n + 1);
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        if (s[i - 1] != s[i - 2] && s[i - 1] != 'C' && s[i - 2] != 'C') {
            dp[i] = max(dp[i - 1], (i - 2 >= 0 ? dp[i - 2] : 0)) + 1;
        }
        else dp[i] = dp[i - 2] + 1;
        ans = max(ans, dp[i]);
    }
    cout << ans << el;
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}