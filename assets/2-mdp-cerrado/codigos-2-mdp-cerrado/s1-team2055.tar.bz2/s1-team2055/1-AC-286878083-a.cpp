#include <bits/stdc++.h>
using namespace std;

#define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'


void solve() {
    int n, m;
    cin >> n >> m;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    vector<int> up(n + 1, 0);
    for (int i = 1; i <= m; i++) {
        int c, h;
        cin >> c >> h;
        up[c] += h;
    }
    int sum = 0;
    for (int i = n; i >= 1; i--) {
        sum += up[i];
        a[i] += sum;
    }
    stack<int> q;
    vector<int> ans(n + 1);
    q.push(a[1]);
    for (int i = 2; i <= n; i++) {
        ans[i] = q.size();
        while(q.size() and a[i] >= q.top()) {
            q.pop();
        }
        q.push(a[i]);
    }
    for (int i = 2; i <= n; i++) cout << ans[i] << '\n';
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}