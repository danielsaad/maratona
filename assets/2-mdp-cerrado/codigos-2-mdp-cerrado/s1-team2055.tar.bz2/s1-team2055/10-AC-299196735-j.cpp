#include <bits/stdc++.h>
using namespace std;

// #define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

void solve() {
    int n; cin >> n;
    string s; cin >> s;
    vector<int> dp(n + 1,0), maximo(n + 1, 0);
    int ans = 0;
    dp[1] = 1;
    maximo[1] = 1;
    for (int i = 2; i <= n; i++) {
        if (s[i - 1] != s[i - 2] && s[i - 1] != 'C' && s[i - 2] != 'C') {
            dp[i] = maximo[i - 2] + 1;
        }
        else dp[i] = maximo[i - 1] + 1;
        maximo[i] = max(maximo[i - 1], dp[i]);
        ans = max(ans, dp[i]);
    }
    cout << maximo[n] << el;
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}