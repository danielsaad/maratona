#include <bits/stdc++.h>
using namespace std;

// #define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

void processa(vector<string> tk) {
    if (tk[0] == "if") {
        cout << "SE ";
        tk[tk.size() - 1].pop_back();
        for (int i = 1; i < tk.size(); i++) {
            cout << tk[i] << ' ';
        }
        cout << "ENTAO ";
    }
    else if (tk[0] == "while") {
        cout << "ENQUANTO ";
        tk[tk.size() - 1].pop_back();
        for (int i = 1; i < tk.size(); i++) {
            cout << tk[i] << ' ';
        }
    }
    else if (tk[0].substr(0, 6) == "print(") {
        cout << "APRESENTE ";
        tk[tk.size() - 1].pop_back();
        int it = 6;
        reverse(tk[0].begin(), tk[0].end());
        while(it--) tk[0].pop_back();
        reverse(tk[0].begin(), tk[0].end());
        for (int i = 0; i < tk.size(); i++) {
            cout << tk[i] << ' ';
        }
    } else {
        cout << "LEIA " << tk[0] << ' ';
    }
}

vector<string> line(string s) {
    vector<string> ret;
    ret.push_back("");
    for (int i = 0; i < s.size(); i++) {
        if (s[i] == ' ') ret.push_back("");
        else ret.back().push_back(s[i]);
    }
    return ret;
}

void solve() {
    vector<string> a;
    string s;
    while(getline(cin, s)) a.push_back(s);
    if (a.size() == 2) {
        reverse(a[1].begin(), a[1].end());
        while(a[1].back() == ' ') a[1].pop_back();
        reverse(a[1].begin(), a[1].end());
    }
    for (int i = 0; i < a.size(); i++) processa(line(a[i]));
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}