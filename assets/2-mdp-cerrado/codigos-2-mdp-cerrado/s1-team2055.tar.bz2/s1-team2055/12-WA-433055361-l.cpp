#include <bits/stdc++.h>
using namespace std;

// #define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

int ask(int x) {
    cout << "? " << x << el;
    cout.flush();
    int y; cin >> y;
    return y;
}

void solve() {
    int n;
    cin >> n;

    n += 2;

    vector<tuple<int, int, int, int>> a(n + 1);

    for (int i = 2; i < n; i += 2)
    {
        int sum = (i - 1) * i / 2;

        int v1 = ask(sum + i / 2);
        int i1 = sum + i / 2;


        int v2 = ask(sum + i / 2 + 1);
        int i2 = sum + i / 2 + 1;
        
        a[i] = {v1, i1, v2, i2};
    }

    int j = 1;
    for (int i = 2; i <= n; i += 2)
    {
        auto [v1, i1, v2, i2] = a[i];

        if (v1 == 1 || v2 == 1)
            j = i;
    }

    
    if (j == 1)
    {
        cout << "! 1" << endl;
        return;
    }

    auto [v1, i1, v2, i2] = a[j];

    int i3 = i1 + j, i4 = i1 + j + 1, i5 = i1 + j + 2;
    int v3 = ask(i3), v4 = ask(i4), v5 = ask(i5);
    
    if (v3 == 1)
    {
        cout << "! " << i3 << endl;
        return;
    }

    if (v4 == 1)
    {
        cout << "! " << i4 << endl;
        return;
    }

    if (v5 == 1)
    {
        cout << "! " << i5 << endl;
        return;
    }


    if (v1 == 1)
    {
        cout << "! " << i1 << endl;
        return;
    }

    if (v2 == 1)
    {
        cout << "! " << i2 << endl;
        return;
    }
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}