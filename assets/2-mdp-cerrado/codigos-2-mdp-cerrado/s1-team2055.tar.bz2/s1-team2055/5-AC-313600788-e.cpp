#include <bits/stdc++.h>
using namespace std;

// #define ll long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

const ll MAXN = 2e5L + 1;
const ll MAX = 1e7L + 1;

ll divi[MAX];
vector<ll> primes;

void crivo(ll lim) {
    divi[1] = 1;
    for (ll i = 2; i < lim; i++) {
        if (divi[i] == 0) divi[i] = i,primes.pb(i);
        for (ll j : primes) {
            if(j > divi[i] or i * j >= lim) break;
            divi[i * j] = j;
        }
    }
}


void solve() {
    vector<ll> soma(1e7 + 1);
    vector<ll> ans;
    ll n; cin >> n;
    for (ll i = 1; i <= n; i++) {
        ll x; cin >> x;
        while (x != 1) {
            soma[divi[x]] -= divi[x];
            x /= divi[x];
        }
    }

    for (ll i = 2; i <= MAX; i++) {
        if (soma[i] != 0) ans.pb(soma[i]);
    }
    sort(ans.begin(), ans.end());
    ll fim = 0;
    for (ll i = 0; i < ans.size(); i += 2) {
        fim -= ans[i];
    }
    cout << fim << el;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    crivo(MAX);
    ll t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}