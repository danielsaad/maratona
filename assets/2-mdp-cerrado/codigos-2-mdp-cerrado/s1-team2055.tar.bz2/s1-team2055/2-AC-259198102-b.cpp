#include <bits/stdc++.h>
using namespace std;

#define mp make_pair

void solve() {
    int a;
    cin >> a;
    if(a < 45) cout << "Costa\n";
    else if(a == 45) cout << "Ambos\n";
    else cout << "Saad\n";
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}