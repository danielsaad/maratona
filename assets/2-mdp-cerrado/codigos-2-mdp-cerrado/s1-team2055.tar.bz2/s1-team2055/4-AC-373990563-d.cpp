#include <bits/stdc++.h>
using namespace std;

// #define int long long // tiagopio

#define mp make_pair
#define pb push_back
using ll = long long;
using ld = long double;
#define el '\n'

void solve() {
    int n, q;
    cin >> n >> q;

    string s;
    cin >> s;

    vector<int> a(26, n);
    for (int c = 0; c < 26; c++)
    {
        for (int i = 0; i < n; i++)
            a[c] = min(a[c], (s[i] == c + 'a' ? n : i));
    }

    while (q--)
    {
        string t;
        cin >> t;

        int m = t.size();
        int ans = n;

        for (int i = 0; i < m; i++)
            ans = max(ans, (n - a[t[i] - 'a']) + (m - i));

        cout << ans << '\n';
    }
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}