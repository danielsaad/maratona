#include <bits/stdc++.h>

using namespace std;


int main(){
    ios_base::sync_with_stdio(0);
    int a;
    cin >> a;
    a == 45 ? (cout << "Ambos\n") : a < 45 ? (cout << "Costa\n"): cout << "Saad\n";     

    return 0;
}