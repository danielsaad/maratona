n = int(input())
cobrancas = input()
print(n - (cobrancas.count("ED") + cobrancas.count("DE")) + cobrancas.count("DED") + cobrancas.count("EDE"))