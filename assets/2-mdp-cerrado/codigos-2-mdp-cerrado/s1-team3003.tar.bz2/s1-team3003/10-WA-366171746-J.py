n = int(input())
cobrancas = input()
#print(n - (cobrancas.count("ED") + cobrancas.count("DE")) + cobrancas.count("DED") + cobrancas.count("EDE"))
resultado = cobrancas.count("C")
for i in cobrancas.split("C"):
    resultado += max(i.count("D"), i.count("E"))
print(resultado)