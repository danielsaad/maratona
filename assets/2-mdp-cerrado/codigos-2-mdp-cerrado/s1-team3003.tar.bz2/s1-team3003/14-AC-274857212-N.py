F = list(map(int, input().split(":")))
A = list(map(int, input().split(":")))

F_min = F[0] * 60 + F[1]
A_min = A[0] * 60 + A[1]

x_min = F_min - A_min
x_hora = x_min // 60
x_min %= 60
x_hora = str(x_hora)
x_min = str(x_min)
if len(x_hora) == 1:
    x_hora = "0"+x_hora

if len(x_min) == 1:
    x_min = "0"+x_min
print(f"{x_hora}:{x_min}")