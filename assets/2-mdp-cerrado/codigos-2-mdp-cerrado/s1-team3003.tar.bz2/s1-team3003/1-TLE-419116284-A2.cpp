#include <bits/stdc++.h>

using namespace std;


int main(){
    ios_base::sync_with_stdio(0);

    long long N, C, h, m, a, p = 1;

    cin >> N >> C;
    
    vector<long long> H;
    //pair<int, int> A; //index, apartamentos visíveis

    for(int g = 0; g < N; g++){
        cin >> h;
        H.emplace_back(h);
    }

    for(int k = 0; k < C; k++){
        cin >> m >> a;
        //MA.emplace_back(m, a);

        while(m > 0){
            H[m-1] += a;
            m--;
        }
    }

    // for (size_t l = 0; l < N; l++)
    // {
    //     cout << H[l] << " <- elemento de H\n";
    // }
    

    // while(N > 0){
    //     if(H[N-1] < H[N-2]) p++;

    //     N--;
    // }
    cout << 1 << '\n';
    //A.first = 1;
    //A.second = 1;

    for(int i = 2; i < N; i++){
        int j = i - 2;
        p = 1;
        int comparado = i-1;
        while(j >= 0){
            //cout << "j: " << H[j] << "\n";
            //cout << "comparado: " << H[comparado] << "\n";
            if(H[j] > H[comparado]){
//                cout << "comparado: " << comparado << "\n";
                comparado = j;
                p++;
            }
            j--;
        }
        //A.first = j;
        //A.second = p+A.second;
        cout << p << '\n';
    }

    return 0;
}